<?php die();

/**
 * Add you custom models here that you are loading in your controllers
 *
 * <code>
 * $this->site_model->get_records()
 * </code>
 * Where site_model is the model Class
 *
 * ---------------------- Models to Load ----------------------
 * <examples>
 *
 * @property user_model $um
 * @property common_model $cm
 * @property setting_model $sm
 * @property admin_model $admin_model
 * @property material_model $material_model
 * @property seller_model $seller_model
 * @property invoice_model $invoice_model
 * @property invoice_item_model $invoice_item_model
 *
 *
 */
class my_models
{
}

// End my_models.php
