/**
 * Created by rajesh bamroteeya  on 10/01/17.
 */
$(document).ready(function(){
var timer;
    // To make Pace works on Ajax calls
    /*$('.content-wrapper').css('min-height:','100%');*/
    $(document).ajaxStart(function(e) {
        if (typeof Pace != 'undefined'){
            Pace.restart();
        }
    });
	/*input style */
	$(document).on('click', '.file-input-browse', function(){
		var file = $(this).parent().parent().parent().find('.file-input');
		file.trigger('click');
	});
	$(document).on('change', '.file-input', function(){
		readURL(this);
		$(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
	});
	function readURL(input){
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				closestImg = $(input).closest('.input-group');
				closestImg = closestImg.find('.file-input-img-span img');
				closestImg.attr('src', e.target.result);
            };
			reader.readAsDataURL(input.files[0]);
		}
	}
	/*end input style */
	// notfiy js fucntion for alert
    function sucessAlert($msg) {
        if (typeof $msg !== "undefined") {
            // argument passed and not undefined
        } else {
            // argument not passed or undefined
            $msg = 'Data saved successfully.';
        }
        $.notify({
            title: '<strong>Success!</strong>',
            message: $msg
        },{
            type: 'success',
            newest_on_top: true,
            animate: {
                enter: 'animated fadeInRight',
                exit: 'animated fadeOutRight'
            }
        });
    }
    function errormsg($error,delay) {
        if (typeof delay !== "undefined") {
            // argument passed and not undefined
        } else {
            // argument not passed or undefined
            delay = 0;
        }
        $.notify({
            title: '<strong>Error!</strong>',
            message: $error,
        },{
            type: 'danger',
            newest_on_top: true,
            animate: {
                enter: 'animated fadeInRight',
                exit: 'animated fadeOutRight'
            },
            delay : delay,
        });
    }
    // end of notfiy js fucntion for alert

	/*DELETE RECORD FROM LISTING*/
	var currDeleteRowId = '';
	var currDeleteRowThat = '';
	$(document).on('click', '.delete', function(){
        currDeleteRowId = $(this).closest('tr').attr('id').replace('data-','');
        currDeleteRowThat = $(this);
		$('#delete_popup').modal('show');
	});
    $('#delete_popup .confirm').on("click", function()
    {
        form_data = new FormData();
        form_data.append('id', currDeleteRowId);
        form_data.append('tbl', $("#hdn").val());
        form_data.append('csrf_token', $('#csrf_token').val());
        form_data.append('csrf_name', $('#csrf_name').val());
        $.ajax({
            dataType: 'json',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            url: siteUrl+'ajax/ajax_delete',
            success: function(obj){
                if(obj.code==1)
                {
                    currDeleteRowThat.closest('.data').remove();
                    //sucessAlert();
                }
                else
                {
                    errormsg(obj.error,5000);
                }
            },
            error: function(obj){
                errormsg(csrf_error);
            },
            complete: function(obj){
                obj=obj.responseJSON;
                $('#csrf_token').val(obj.csrf_token);
                $('#csrf_name').val(obj.csrf_name);
            },
        });
        $('#delete_popup').modal('hide');
    });
		
	$(document).on('click', '.switch', function(){					  
		window.clearTimeout(timer);
		ele=$(this);
		id =	$(this).closest('tr').attr('id').replace('data-','');
		checked = $(ele).find('.switch-radio').removeAttr("checked");
        form_data = new FormData();
        form_data.append('id', id);
        form_data.append('tbl', $("#hdn").val());
        form_data.append('csrf_token', $('#csrf_token').val());
        form_data.append('csrf_name', $('#csrf_name').val());
        $.ajax({
            dataType: 'json',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            url: siteUrl+'ajax/ajax_status',
            success: function(obj){
                if(obj.code==1)
                {
                    if($(ele).hasClass('on')){
                        $(ele).removeClass('on');
                    }else{
                        $(ele).addClass('on');
                    }
                    //sucessAlert();
                }
                else
                {
                    errormsg(obj.error,5000);
                }
            },
            error: function(obj){
                errormsg(csrf_error);
            },
            complete: function(obj){
                obj=obj.responseJSON;
                $('#csrf_token').val(obj.csrf_token);
                $('#csrf_name').val(obj.csrf_name);
            },
        });
			
	});

    /*
     Scorll to div top code

        var offset = $(this).find('.collapse.in').prev('.panel-heading');
        if(offset) {
            $('html,body').animate({
                scrollTop: $(offset).offset().top -$('.main-header').height() -5
            },200);
        }
   */

    /* sample for ajax form submit
    $('#form_id').submit(function(e) {
    	e.preventDefault();
        $that = $(this);
        var save = $(this).attr("value_save");
    	if ($("#BasicInformationForm").valid()) {
			var data = new FormData($("#BasicInformationForm")[0]);
			data.append('userid', $('#abstract_id').val());
			data.append('csrf_token', $('#csrf_token').val());
			data.append('csrf_name', $('#csrf_name').val());
			$.ajax({
				dataType: 'json',  // what to expect back from the PHP script, if anything
				cache: false,
				contentType: false,
				processData: false,
				data: data,
				type: "post",
				url: siteUrl+'manage/lease_abstract_form/insert_basicinfo',
				success: function(obj){
					if(obj.code == 1) {
						if(save=='save'){sucessAlert();}
						else{nextCollapseOpen($that);}
					}
					else{
						errormsg(obj.error);
					}
				},
                error: function(obj){
                    errormsg(csrf_error);
                },
                complete: function(obj){
                    obj=obj.responseJSON;
                    $('#csrf_token').val(obj.csrf_token);
                    $('#csrf_name').val(obj.csrf_name);
                },
			});
		}
	});*/

    /*Start: Invoice module js code */
    $(document).on('click', '.add-more-minimum-invoice-item-row', function (e) {
        $that = $(this);
        $('.main_div_invoice_item').append($('#invoice_item_row_template').html());
        $that.closest('.invoice_item_row').find('.remove-this-minimum-invoice-item-row').removeClass('hide');
        $that.addClass('hide');
        //rentNoLable();
    });
    $(document).on('click', '.remove-this-minimum-invoice-item-row', function (e) {
        $that = $(this);
        $that.closest('.invoice_item_row').remove();
    });

    $(document).on('change','.main_div_invoice_item .InputQtyOfMaterial,.main_div_invoice_item .InputPriceOfUnit',function (e) {
        invoice_item_row = $(this).closest('.invoice_item_row');
        InputQtyOfMaterial = parseFloat(invoice_item_row.find('.InputQtyOfMaterial').val()).toFixed(3);
        InputPriceOfUnit = parseFloat(invoice_item_row.find('.InputPriceOfUnit').val()).toFixed(2);
        InputII_Amount = InputQtyOfMaterial * InputPriceOfUnit;
        InputII_Amount = parseFloat(InputII_Amount).toFixed(2);
        invoice_item_row.find('.InputII_Amount').val(InputII_Amount);
        //.InputII_Amount
    });
    /*End: Invoice module js code */
});