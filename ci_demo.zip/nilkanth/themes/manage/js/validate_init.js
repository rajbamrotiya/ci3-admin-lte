$(function(){
    jQuery.validator.setDefaults({
        highlight: function(element) {
            //$(element).closest('.form-group').addClass('has-error');
            $(element).parent().addClass('has-error');
        },
        unhighlight: function(element) {
            //$(element).closest('.form-group').removeClass('has-error');
            $(element).parent().removeClass('has-error');
        },
        errorElement: 'span',
        errorClass: 'help-block',
        errorPlacement: function(error, element) {
            if(element.parent('.input-group').length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        },
        onfocusout: false,
        invalidHandler: function(form, validator) {
            if (!validator.numberOfInvalids())
                return;

            $('html, body').animate({
                scrollTop: $(validator.errorList[0].element).offset().top -$('.main-header').height() - 50
            }, 2000);
            setTimeout(function () {
                validator.errorList[0].element.focus();
            },2000);
        }
    });
	$("#login_form").validate({
		rules: {
			email: {
				required: true,
				email:true		
			},
			password: {
				required: true,
			}
		},
		messages: {
			email: {
				required: js_required,
				email:js_email
			},
			password: {
				required: js_required,
			}
		}
	}),
	$("#forgot_form").validate({
		rules: {
			forgot_email: {
				required: true,
				email:true		
			},
		},
		messages: {
			forgot_email: {
				required: js_required,
				email:js_email
			},
		}
	}),
	$("#setting_form").validate({
		rules: {
			title: {
				required: true,
				maxlength:200		
			},
			keytext: {
				required: true,
				maxlength:200		
			},
			setting_type: {
				required: true,
			},
			value: {
				required: true,
				
			},
		},
		messages: {
			title: {
				required: js_required,
				maxlength:maxlengths.replace("%s",200)
			},
			keytext: {
				required: js_required,
				maxlength:maxlengths.replace("%s",200)
			},
			setting_type: {
				required: js_required,
			},
			value: {
				required: js_required,
				
			},
		}
	}),
	$('#recover_form').validate({
		rules: {
			recover_pass: {
				required: true,
				minlength:6,
				maxlength:15,
			},
			conf_recover_pass:{
				equalTo: "#recover_pass",
			},
		},
		messages: {
			recover_pass:{
				required: js_required,
				minlength:js_passlength,
				maxlength:js_passmax,
			},
			conf_recover_pass: {
				equalTo:js_pwmismatch
			},
		}
	}),
	$("#admin_form").validate({
		rules: {
			name:{
				required: true,
			},
			email: {
				required: true,
				email:true		
			},
			password:{
				required: true,
				minlength:6,
				maxlength:15,
			},
			confirm_password:{
				required: true,
				equalTo: "#password",
			},
		},
		messages: {
			name: {
				required: js_required,
			},
			email: {
				required: js_required,
				email:js_email
			},
			password: {
				required: js_required,
				minlength:js_passlength,
				maxlength:js_passmax,
			},
			confirm_password: {
				required: js_required,
				equalTo:js_pwmismatch
			},
		}
	}),
	$("#admin_form1").validate({
			rules: {
				name:{
					required: true,
				},
				email: {
					required: true,
					email:true
				},
				password:{
					minlength:6,
					maxlength:15,
				},
				confirm_password:{
					equalTo: "#password",
				},
			},
			messages: {
				name: {
					required: js_required,
				},
				email: {
					required: js_required,
					email:js_email
				},
				password: {
					minlength:js_passlength,
					maxlength:js_passmax,
				},
				confirm_password: {
					equalTo:js_pwmismatch
				},
			}
		}),
	$("#re_firm_form").validate({
			rules: {
				name:{
					required: true,
				},
				add: {
					required: true,
				},
				contact:{
					required: true,
				},
			},
			messages: {
				name:{
					required: js_required,
				},
				add: {
					required: js_required,
				},
				contact:{
					required: js_required,
				},
			}
		}),
	$("#re_advisor_form").validate({
			rules: {
				firm_id:{
					required: true,
				},
				name:{
					required: true,
				},
				email: {
					required: true,
					email:true
				},
				password:{
					required: true,
					minlength:6,
					maxlength:15,
				},
				confirm_password:{
					required: true,
					equalTo: "#password",
				},
			},
			messages: {
				firm_id:{
					required: js_required,
				},
				name: {
					required: js_required,
				},
				email: {
					required: js_required,
					email:js_email
				},
				password: {
					required: js_required,
					minlength:js_passlength,
					maxlength:js_passmax,
				},
				confirm_password: {
					required: js_required,
					equalTo:js_pwmismatch
				},
			}
		}),
	$("#re_advisor_form1").validate({
			rules: {
				firm_id:{
					required: true,
				},
				name:{
					required: true,
				},
				email: {
					required: true,
					email:true
				},
				password:{
					minlength:6,
					maxlength:15,
				},
				confirm_password:{
					equalTo: "#password",
				},
			},
			messages: {
				firm_id:{
					required: js_required,
				},
				name: {
					required: js_required,
				},
				email: {
					required: js_required,
					email:js_email
				},
				password: {
					minlength:js_passlength,
					maxlength:js_passmax,
				},
				confirm_password: {
					equalTo:js_pwmismatch
				},
			}
		}),
	$("#re_staff_form").validate({
		rules: {
			firm_id:{
				required: true,
			},
			name:{
				required: true,
			},
			email: {
				required: true,
				email:true
			},
			/*'company[]': {
				required:true,
			},*/
			password:{
				required: true,
				minlength:6,
				maxlength:15,
			},
			confirm_password:{
				required: true,
				equalTo: "#password",
			},
		},
		messages: {
			firm_id:{
				required: js_required,
			},
			name: {
				required: js_required,
			},
			email: {
				required: js_required,
				email:js_email
			},
			/*'company[]': {
				required: "You must check at least 1 box",
			},*/
			password: {
				required: js_required,
				minlength:js_passlength,
				maxlength:js_passmax,
			},
			confirm_password: {
				required: js_required,
				equalTo:js_pwmismatch
			},
		}
	}),
	$("#company_staff_form1").validate({
		rules: {
			company_id:{
				required: true,
			},
			name:{
				required: true,
			},
			email: {
				required: true,
				email:true
			},
			password:{
				minlength:6,
				maxlength:15,
			},
			confirm_password:{
				equalTo: "#password",
			},
		},
		messages: {
			company_id:{
				required: js_required,
			},
			name: {
				required: js_required,
			},
			email: {
				required: js_required,
				email:js_email
			},
			password: {
				minlength:js_passlength,
				maxlength:js_passmax,
			},
			confirm_password: {
				equalTo:js_pwmismatch
			},
		}
	}),
	$("#company_staff_form").validate({
		rules: {
			company_id:{
				required: true,
			},
			name:{
				required: true,
			},
			email: {
				required: true,
				email:true
			},
			password:{
				required: true,
				minlength:6,
				maxlength:15,
			},
			confirm_password:{
				required: true,
				equalTo: "#password",
			},
		},
		messages: {
			company_id:{
				required: js_required,
			},
			name: {
				required: js_required,
			},
			email: {
				required: js_required,
				email:js_email
			},
			password: {
				required: js_required,
				minlength:js_passlength,
				maxlength:js_passmax,
			},
			confirm_password: {
				required: js_required,
				equalTo:js_pwmismatch
			},
		}
	}),
	$("#re_staff_form1").validate({
		rules: {
			firm_id:{
				required: true,
			},
			name:{
				required: true,
			},
			/*'company[]': {
				required:true,
			},*/
			email: {
				required: true,
				email:true
			},
			password:{
				minlength:6,
				maxlength:15,
			},
			confirm_password:{
				equalTo: "#password",
			},
		},
		messages: {
			firm_id:{
				required: js_required,
			},
			name: {
				required: js_required,
			},
			/*'company[]': {
				required: "You must check at least 1 box",
			},*/
			email: {
				required: js_required,
				email:js_email
			},
			password: {
				minlength:js_passlength,
				maxlength:js_passmax,
			},
			confirm_password: {
				equalTo:js_pwmismatch
			},
		}
	}),
	$("#company_form").validate({
		rules: {
			Firm_id:{
				required: true,
			},
			CompanyName:{
				required: true,
			},
			CompanyUrl:{
				required: true,
				url: true
			},
			CompanyAddress:{
				required: true,
			},
			ContactName1:{
				required: true,
			},
			ContactPhone1:{
				required: true,
			},
			ContactEmail1:{
				required: true,
				email:true
			},
			ContactEmail2:{
				email:true
			},
			email: {
				required: true,
				email:true
			},
			password:{
				required: true,
				minlength:6,
				maxlength:15,
			},
			confirm_password:{
				required: true,
				equalTo: "#password",
			},
		},
		messages: {
			Firm_id: {
				required: js_required,
			},
			CompanyName:{
				required: js_required,
			},
			CompanyUrl:{
				required: js_required,
			},
			CompanyAddress:{
				required: js_required,
			},
			ContactName1:{
				required: js_required,
			},
			ContactPhone1:{
				required: js_required,
			},
			ContactEmail1:{
				required: js_required,
				email:js_email
			},
			ContactEmail2:{
				email:js_email
			},
			email: {
				required: js_required,
				email:js_email
			},
			password: {
				required: js_required,
				minlength:js_passlength,
				maxlength:js_passmax,
			},
			confirm_password: {
				required: js_required,
				equalTo:js_pwmismatch
			},
		}
	}),
	$("#company_form1").validate({
			rules: {
				Firm_id:{
					required: true,
				},
				CompanyName:{
					required: true,
				},
				CompanyUrl:{
					required: true,
					url: true
				},
				CompanyAddress:{
					required: true,
				},
				ContactName1:{
					required: true,
				},
				ContactPhone1:{
					required: true,
				},
				ContactEmail1:{
					required: true,
					email:true
				},
				ContactEmail2:{
					email:true
				},
				email: {
					required: true,
					email:true
				},
				password:{
					minlength:6,
					maxlength:15,
				},
				confirm_password:{
					equalTo: "#password",
				},
			},
			messages: {
				Firm_id: {
					required: js_required,
				},
				CompanyName:{
					required: js_required,
				},
				CompanyUrl:{
					required: js_required,
				},
				CompanyAddress:{
					required: js_required,
				},
				ContactName1:{
					required: js_required,
				},
				ContactPhone1:{
					required: js_required,
				},
				ContactEmail1:{
					required: js_required,
					email:js_email
				},
				ContactEmail2:{
					email:js_email
				},
				email: {
					required: js_required,
					email:js_email
				},
				password: {
					minlength:js_passlength,
					maxlength:js_passmax,
				},
				confirm_password: {
					equalTo:js_pwmismatch
				},
			}
	}),
	$("#webpage_form").validate({
		rules: {
			type:{
				required:true,
			},
			heading:{
				required:true,
				maxlength:100
			},
			title:{
				required:true,
				maxlength:50
			},	
			meta_key:{required:true, maxlength:100},
			meta_desc:{required:true, maxlength:200}
		},
		messages: {
			type: {required:js_required},
			heading: {required:js_required, maxlength:maxlengths.replace("%s",50)},
			title: {required:js_required, maxlength:maxlengths.replace("%s",100)},
			meta_key: {required:js_required, maxlength:maxlengths.replace("%s",100)},
			meta_desc :{required:js_required, maxlength:maxlengths.replace("%s",200),},
		},
		success: function(label) {
			label.html('&nbsp;').removeClass('error').addClass('ok');
		},
	}),
	$("#mail_form").validate({
		rules: {
			title:{
				required:true,
				maxlength:100
			},	
			email: {
				required: true,
				email:true	
			},
			password:{
				required:true,
				maxlength:20,
			},
			from_text:{required:true, maxlength:100},
			subject:{required:true, maxlength:100}
		},
		messages: {
			title: {required:js_required, maxlength:maxlengths.replace("%s",100)},
			email: {
				required: js_required,
				email:js_email
			},
			password: {
				required: js_required,
				maxlength:maxlengths.replace("%s",20)
			},
			from_text: {required:js_required, maxlength:maxlengths.replace("%s",100)},
			subject :{required:js_required, maxlength:maxlengths.replace("%s",100),},
		},
		success: function(label) {
			label.html('&nbsp;').removeClass('error').addClass('ok');
		},
	}),
	$("#mailsetting_form").validate({
		rules: {
			title:{
				required:true,
				maxlength:100
			},	
			email: {
				required: true,
				email:true	
			},
			slug:{
				required:true,
			},
			from_text:{required:true, maxlength:100},
			subject:{required:true, maxlength:100}
		},
		messages: {
			title: {required:js_required, maxlength:maxlengths.replace("%s",100)},
			email: {
				required: js_required,
				email:js_email
			},
			slug: {
				required: js_required,
			},
			from_text: {required:js_required, maxlength:maxlengths.replace("%s",100)},
			subject :{required:js_required, maxlength:maxlengths.replace("%s",100),},
		}
	}),
	$("#mailsetting_form1").validate({
		rules: {
			title:{
				required:true,
				maxlength:100
			},	
			email: {
				required: true,
				email:true	
			},
			from_text:{required:true, maxlength:100},
			subject:{required:true, maxlength:100}
		},
		messages: {
			title: {required:js_required, maxlength:maxlengths.replace("%s",100)},
			email: {
				required: js_required,
				email:js_email
			},
			from_text: {required:js_required, maxlength:maxlengths.replace("%s",100)},
			subject :{required:js_required, maxlength:maxlengths.replace("%s",100),},
		}
	}),
	$("#primary_data").validate({
		rules: {
			Address1: {
				required: true,	
			},
			CityName: {
				required: true,
			},
			ZipCode: {
				required: true,	
			},
			StateName: {
				required: true,
			},
			LocationInfo: {
				required: true,	
			},
			TenantName: {
				required: true,
			},
			ManagerInfo: {
				required: true,	
			},
			LandlordName: {
				required: true,
			}
		},
		messages: {
			Address1: {
				required: js_required,
			},
			CityName: {
				required: js_required,
			},
			ZipCode: {
				required: js_required,
			},
			StateName: {
				required: js_required,
			},
			LocationInfo: {
				required: js_required,
			},
			TenantName: {
				required: js_required,
			},
			ManagerInfo: {
				required: js_required,
			},
			LandlordName: {
				required: js_required,
			}
		}
	}),
	$("#BasicInformationForm").validate({
		rules: {
			LeaseDate: {
				required: true,	
			},
			Rental: {
				required: true,
			},
			Pro_Rata_Share: {
				required: true,	
			},
			Premises: {
				required: true,
			},
		},
		messages: {
			LeaseDate: {
				required: js_required,
			},
			Rental: {
				required: js_required,
			},
			Pro_Rata_Share: {
				required: js_required,
			},
			Premises: {
				required: js_required,
			},
		}
	}),
	$("#TermForm").validate({
			rules: {
				Lease_Commencement_date: {
					required: true,	
				},
				Rate_Commencement_Date: {
					required: true,
				},
				Lease_Expiration_Date: {
					required: true,	
				},
				Term: {
					required: true,
				},
			},
			messages: {
				Lease_Commencement_date: {
					required: js_required,
				},
				Rate_Commencement_Date: {
					required: js_required,
				},
				Lease_Expiration_Date: {
					required: js_required,
				},
				Term: {
					required: js_required,
				},
			}
	}),
	$("#RentForm").validate({
			rules: {
				Min_Rent: {
					required: true,	
				},
				Operating: {
					required: true,
				},
				Real_Estate_Tax: {
					required: true,	
				},
				Insurance: {
					required: true,
				},
				Base_Year_Expense: {
					required: true,
				},
			},
			messages: {
				Min_Rent: {
					required: js_required,
				},
				Operating: {
					required: js_required,
				},
				Real_Estate_Tax: {
					required: js_required,
				},
				Insurance: {
					required: js_required,
				},
				Base_Year_Expense: {
					required: js_required,
				},
			}
	}),
	$("#TenantOptionsForm").validate({
			rules: {
				Renewal: {
					required: true,	
				},
				Renewal_Start_Date: {
					required: true,
				},
				Renewal_End_Date: {
					required: true,	
				},
				Renewal_Effective_Date: {
					required: true,
				},
			},
			messages: {
				Renewal: {
					required: js_required,
				},
				Renewal_Start_Date: {
					required: js_required,
				},
				Renewal_End_Date: {
					required: js_required,
				},
				Renewal_Effective_Date: {
					required: js_required,
				},
			}
	}),
	$("#LandlordOptionsForm").validate({
			rules: {
				Relocation: {
					required: true,	
				},
				Landlord_Termination: {
					required: true,
				},
			},
			messages: {
				Relocation: {
					required: js_required,
				},
				Landlord_Termination: {
					required: js_required,
				},
			}
	}),
	$("#LegalFinancialForm").validate({
		rules: {
			Assignment: {
				required: true,
			},
			Subordination: {
				required: true,
			},
			Landlord: {
				required: true,
			},
			Tenant_Notices: {
				required: true,
			},
			Tenant_Copy: {
				required: true,
			},
			Liability: {
				required: true,
			},
			Property: {
				required: true,
			},
			Tenant_Improvements: {
				required: true,
			},
			Tenant_Improvements_Terms: {
				required: true,
			},
		},
		messages: {
			Assignment: {
				required: js_required,
			},
			Subordination: {
				required: js_required,
			},
			Landlord: {
				required: js_required,
			},
			Tenant_Notices: {
				required: js_required,
			},
			Tenant_Copy: {
				required: js_required,
			},
			Liability: {
				required: js_required,
			},
			Property: {
				required: js_required,
			},
			Tenant_Improvements: {
				required: js_required,
			},
			Tenant_Improvements_Terms: {
				required: js_required,
			},
		}
	}),
	$("#current_market_rate").validate({
		rules: {
			city: {
				required: true,		
			}
		},
		messages: {
			city: {
				required: js_required,
			}
		}
	}),
	$("#file_check").validate({
		rules: {
			file_value: {
				required: true,		
			}
		},
		messages: {
			file_value: {
				required: js_required,
			}
		}
	})
});