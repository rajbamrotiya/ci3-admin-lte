<?php
class User_model extends CI_Model {

	public function __construct()
	{
		if(!in_array($this->router->fetch_class(),array('ifanypage','payment_page')))
		{
            if ($this->sm->ss->live_test == 0 && !$this->session->userdata('admin_logged_in'))
			{
				$this->load->view("maintenance_view");
				echo $this->output->get_output(); 
				exit;
			}
		}
	}
	function convert_date_UTC($time_zone,$date)
	{
		date_default_timezone_set($time_zone);
		return strtotime($date);
	}
	function convert_UTC_date($date)
	{
		return gmdate("Y-m-d H:i:s",$date);
	}
}
