<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Invoice_item_model extends CI_Model
{
    public $Id = 'Id';
    public $InvoiceId = 'InvoiceId';
    public $MaterialId = 'MaterialId';
    public $PriceOfUnit = 'PriceOfUnit';
    public $QtyOfMaterial = 'QtyOfMaterial';
    public $CgstPre = 'CgstPre';
    public $CgstAmount = 'CgstAmount';
    public $SgstPre = 'SgstPre';
    public $SgstAmount = 'SgstAmount';
    public $IgstPre = 'IgstPre';
    public $IgstAmount = 'IgstAmount';
    public $Amount = 'Amount';
    public $TotalAmount = 'TotalAmount';

    public $Status = 'Status';
    public $CreatedDate = 'CreatedDate';
    public $CreatedIp = 'CreatedIp';
    public $CreatedBy = 'CreatedBy';
    public $ModifiedDate = 'ModifiedDate';
    public $ModifiedIp = 'ModifiedIp';
    public $ModifiedBy = 'ModifiedBy';
    public $table_nm = 'invoice_item';
    protected $login_id;

    /**
     * Material_model constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->login_id = $this->session->userdata('adminid');
    }

    /**
     * @param $id
     * @return mixed
     */
    public function get($id)
    {
        $this->db->select($this->table_nm . '.*,b.Name as ModifiedByUserName, b.Name as CreatedByUserName');
        $this->db->join('users b', $this->table_nm . '.ModifiedBy = b.Id', 'left');
        $this->db->join('users c', $this->table_nm . '.CreatedBy = c.Id', 'left');
        $this->db->where(array($this->table_nm . '.id' => $id));
        return $this->db->get($this->table_nm)->row();
    }

    /**
     * @param string $InvoiceId
     * @param string $order_by
     * @return array
     */
    public function get_all($InvoiceId = '', $order_by = 'Id DESC')
    {
        $where_arr = ['Status !=' => 'Delete'];
        if ($InvoiceId != '' && is_numeric($InvoiceId)) {
            $where_arr['InvoiceId'] = $InvoiceId;
        }
        $this->db->order_by($order_by);
        $query = $this->db->get_where($this->table_nm, $where_arr);
        return $query->result();
    }


    public function get_all_with_join($InvoiceId = '', $order_by = 'invoice_item.Id DESC')
    {
        $where_arr = [$this->table_nm.'.Status !=' => 'Delete'];
        if ($InvoiceId != '' && is_numeric($InvoiceId)) {
            $where_arr['InvoiceId'] = $InvoiceId;
        }

        $this->db->select($this->table_nm . '.*,b.Name as MaterialName,b.HsnCode');

        $this->db->join('material b', $this->table_nm . '.MaterialId = b.Id', 'left');

        $this->db->order_by($order_by);
        $this->db->where($where_arr);
        return $this->db->get($this->table_nm)->result();
        
    }

    /**
     * @param array $insert_arr
     * @return mixed
     */
    public function insert(array $insert_arr)
    {
        $date_ip = $this->cm->get_date_ip();
        $insert_arr[$this->ModifiedDate] = $insert_arr[$this->CreatedDate] = $date_ip->cur_date;
        $insert_arr[$this->ModifiedIp] = $insert_arr[$this->CreatedIp] = $date_ip->ip;
        $insert_arr[$this->ModifiedBy] = $insert_arr[$this->CreatedBy] = $this->login_id;
        $this->db->insert($this->table_nm, $insert_arr);
        $insert_id = $this->db->insert_id();

        //Insert Modified log
        $value_array = array(
            'TableId' => $insert_id,
            'TableName' => $this->db->dbprefix($this->table_nm)
        );
        $this->cm->insert_modified($value_array);
        return $insert_id;
    }

    /**
     * @param array $insert_arrs
     * @return mixed
     */
    public function insert_batch(array $insert_arrs)
    {
        $date_ip = $this->cm->get_date_ip();

        foreach ($insert_arrs as $key=>$insert_arr) {
            $insert_arr[$this->ModifiedDate] = $insert_arr[$this->CreatedDate] = $date_ip->cur_date;
            $insert_arr[$this->ModifiedIp] = $insert_arr[$this->CreatedIp] = $date_ip->ip;
            $insert_arr[$this->ModifiedBy] = $insert_arr[$this->CreatedBy] = $this->login_id;
            $insert_arrs[$key] = $insert_arr;
        }
        $this->db->insert_batch($this->table_nm, $insert_arrs);
    }


    /**
     * @param $where_or_id
     * @param array $update_arr
     */
    public function update($where_or_id, array $update_arr)
    {
        if(is_array($where_or_id)){
            $where = $where_or_id;
        }else{
            $where = array($this->Id => $where_or_id);
        }
        $date_ip = $this->cm->get_date_ip();
        $update_arr[$this->ModifiedDate] = $date_ip->cur_date;
        $update_arr[$this->ModifiedIp] = $date_ip->ip;
        $update_arr[$this->ModifiedBy] = $this->login_id;
        $this->db->update($this->table_nm, $update_arr, $where);

        if(!is_array($where_or_id)){
            $value_array = array(
                'TableId' => $where_or_id,
                'TableName' => $this->db->dbprefix($this->table_nm)
            );
            $this->cm->insert_modified($value_array);
        }
    }

    /**
     * @param array $update_arrs
     * @param $index
     */
    public function update_batch(array $update_arrs, $index='Id')
    {
        $date_ip = $this->cm->get_date_ip();

        foreach ($update_arrs as $key=>$update_arr) {
            $update_arr[$this->ModifiedDate] = $date_ip->cur_date;
            $update_arr[$this->ModifiedIp] = $date_ip->ip;
            $update_arr[$this->ModifiedBy] = $this->login_id;
            $update_arrs[$key] = $update_arr;
        }
        $this->db->update_batch($this->table_nm, $update_arrs,$index);
    }

}
