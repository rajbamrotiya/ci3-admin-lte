<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Material_model extends CI_Model
{
    public $Id = 'Id';
    public $Name = 'Name';
    public $HsnCode = 'HsnCode';
    public $UnitRate = 'UnitRate';
    public $OtherInfo = 'OtherInfo';
    public $Status = 'Status';
    public $CreatedDate = 'CreatedDate';
    public $CreatedIp = 'CreatedIp';
    public $CreatedBy = 'CreatedBy';
    public $ModifiedDate = 'ModifiedDate';
    public $ModifiedIp = 'ModifiedIp';
    public $ModifiedBy = 'ModifiedBy';
    public $table_nm = 'material';
    protected $login_id;

    /**
     * Material_model constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->login_id = $this->session->userdata('adminid');
    }

    /**
     * @param $id
     * @return mixed
     */
    public function get($id)
    {
        $this->db->select($this->table_nm . '.*,b.Name as ModifiedByUserName, b.Name as CreatedByUserName');
        $this->db->join('users b', $this->table_nm . '.ModifiedBy = b.Id', 'left');
        $this->db->join('users c', $this->table_nm . '.CreatedBy = c.Id', 'left');
        $this->db->where(array($this->table_nm . '.id' => $id));
        return $this->db->get($this->table_nm)->row();
    }

    /**
     * @param string $order_by
     * @return array
     */
    public function get_all($order_by = 'Id DESC')
    {
        $where_arr = ['Status !=' => 'Delete'];
        $this->db->order_by($order_by);
        $query = $this->db->get_where($this->table_nm, $where_arr);
        return $query->result();
    }

    /**
     * @param array $insert_arr
     * @return mixed
     */
    public function insert(array $insert_arr)
    {
        $date_ip = $this->cm->get_date_ip();
        $insert_arr[$this->ModifiedDate] = $insert_arr[$this->CreatedDate] = $date_ip->cur_date;
        $insert_arr[$this->ModifiedIp] = $insert_arr[$this->CreatedIp] = $date_ip->ip;
        $insert_arr[$this->ModifiedBy] = $insert_arr[$this->CreatedBy] = $this->login_id;
        $this->db->insert($this->table_nm, $insert_arr);
        $insert_id = $this->db->insert_id();

        //Insert Modified log
        $value_array = array(
            'TableId' => $insert_id,
            'TableName' => $this->db->dbprefix($this->table_nm)
        );
        $this->cm->insert_modified($value_array);
        return $insert_id;
    }

    /**
     * @param $id
     * @param array $update_arr
     */
    public function update($id, array $update_arr)
    {
        $date_ip = $this->cm->get_date_ip();
        $update_arr[$this->ModifiedDate] = $date_ip->cur_date;
        $update_arr[$this->ModifiedIp] = $date_ip->ip;
        $update_arr[$this->ModifiedBy] = $this->login_id;
        $this->db->update($this->table_nm, $update_arr, array($this->Id => $id));

        $value_array = array(
            'TableId' => $id,
            'TableName' => $this->db->dbprefix($this->table_nm)
        );
        $this->cm->insert_modified($value_array);
    }
}
