<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Setting_model extends CI_Model
{
    var $ss;
    function __construct()
    {
        parent::__construct();      
		$site_setting = array();
		//setting model data
        $this->db->select("fieldName,keytext,value,setting_type");
        $pr = $this->db->get("setting")->result();
        foreach ($pr as $setting) {
            $site_setting[$setting->keytext] = addslashes($setting->value);

        }
        $this->ss = (object)$site_setting;
        //$this->sm->ss
    } 	
}
