<h1 style="font-size:18px;font-weight:bold;"> Future Care Costs Calculation - Schedule1 </h1>

<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Claimant : </div>
    <div style="font-size:14px;float:left;"> <?php echo $first_name.'&nbsp;'.$last_name; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Claim Number : </div>
    <div style="font-size:14px;float:left;">  <?php echo $claim_no; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Details :</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Description :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $CalcDescription; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Gender :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $gender; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Of Birth :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo ($appdob!="") ? date('F d, Y',strtotime($appdob)) : ''; ?>  </div>
</div>
<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Of Incident : </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($Date_incident)) ?>  </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Of Trial : </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($trialdate)) ?>  </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Discount Rate - first 15 years :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo number_format($Discount15,2).' % '; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Discount Rate -from 16 years :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo  number_format($Discount16,2).' % '; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Injury Factors :</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Mortality Adjustment Factor  :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;"> <?php echo ($adjustfactor!="") ? sprintf("%.2f", $adjustfactor).' %' : ''; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Estimated Age at Trial Date :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $ageest; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;margin-top:3%;"> Present Value of Future Care Costs at the Trial Date :</div>

<div style="padding:2px;">
    <div style="float:left;width:50%;margin-left:5%;font-size:14px;font-weight:100;">  Standard Life Expectancy  </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;"> <?php echo ($API_result->standard!="") ? ($API_result->standard!="N/A") ? '$'.number_format ($API_result->standard,0): 'N/A' : ''; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:50%;margin-left:5%;font-size:14px;font-weight:100;">  Reduced Life Expectancy - Relative Risk Approach </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;"> <?php echo ($API_result->relative!="") ? ($API_result->relative!="N/A") ?  '$'.number_format ($API_result->relative,0):'N/A' : ''; ?></div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:50%;margin-left:5%;font-size:14px;font-weight:100;"> Reduced Life Expectancy - Rating Up Approach </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;"> <?php  echo ($API_result->rateup!="") ? ($API_result->rateup!="N/A") ? '$'.number_format ($API_result->rateup,0):'N/A' : ''; ?> </div>
</div>


<div style="width:100%;float:left;padding:2px;font-size:12px;font-weight:bold;float:left;margin-top:5%;">Notes :</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;"> 
	<div style="width:3%;min-height:30px;float:left;"> <b> [1]  </b>  </div>
    <div style="float:left;">
	 This calculation represents the present value 	at the Trial Date of the Future Care Costs summarized on Schedule 2. Adjustments for mortality rates based on the Canada Life Table (2000 - 2002) have been considered.
     </div>
</div>

<!---- SECOND PAGE  ---->
<h1 style="font-size:18px;font-weight:bold;page-break-before:always"> Future Care Cost Calculation - Schedule 2 </h1>
<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>


<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Claimant : </div>
    <div style="font-size:14px;float:left;"> <?php echo $first_name.'&nbsp;'.$last_name; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Claim Number : </div>
    <div style="font-size:14px;float:left;">  <?php echo $claim_no; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Details :</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Description :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $CalcDescription; ?> </div>
</div>

<div style="margin-top:2%;padding:1% 0;font-size:14px;font-weight:bold;"> Summary Of Future Care Costs from the Trial Date: </div>
<table class="table_style" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;border: 1px solid #000;
width: 100%;">

<tbody>
	<tr>
    	<th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> Description</th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> One Time Amount</th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> From(Dats/Years)  </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> To(Dats/Years) </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> Annual Amount</th>
      </tr>
    <?php foreach($cell_ExpenseType as $key=>$val){ ?>
	 <tr>
     	<?php 
			($cell_onetimeAmt[$key]=="" || $cell_onetimeAmt[$key]==0) ? $cell_onetimeAmt[$key] = ""  :'';
			($cell_annualamt[$key]==""  || $cell_annualamt[$key]==0)  ? $cell_annualamt[$key]  = ""  :'';
		?>
    	<th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo $cell_calcDesc[$key]; ?> </th>
        <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo ($cell_onetimeAmt[$key]!="")?'$'.number_format($cell_onetimeAmt[$key],2):'&nbsp;'; ?> </th>
        <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo $cell_FromDateYears[$key]; ?> </th>
        <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo $cell_ToDateYears[$key]; ?> </th>
        <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo ($cell_annualamt[$key]!="")?'$'.number_format($cell_annualamt[$key],2):'&nbsp;'; ?> </th>
	</tr>
        	
    <?php } ?>
</tbody>                                    

</table>	