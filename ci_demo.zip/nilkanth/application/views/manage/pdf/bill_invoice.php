<!--- FIRST PAGE --->
<?php $top_hegiht = '210px'; ?>
<div style="height: <?=$top_hegiht;?>;">&nbsp;</div>
<!-- BILL START -->
<!--FIRST TABLE STRAT-->
<table style="" width="100%">
    <tr>
        <td width="40%;"></td>
        <td width="20%;" style="font-size: 18px;font-weight:bold;margin: 0px;text-align: center;">TAX INVOICE</td>
        <td width="40%;" align="right" valign="bottom" style="font-size: 14px;"><!--ORIGINAL /--> DUPLICATE / TRIPLICATE</td>
    </tr>
</table>
<!--FIRST TABLE END-->

<!--2nd TABLE STRAT-->
<table  class="table_style" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;border: 1px solid #000;
width: 100%;">
    <tbody>
    <tr>
        <td style="width:50%;float:left;border-right:1px solid #000;text-align:left;padding: 3px;" rowspan="6" valign="top">
            Bill to,<br>
            <b><?= $result->SellerName; ?></b><br>
            <?= $result->SellerAddress; ?><br>
            State : <b><?= html_escape($state_table[$result->SellerState][0]); ?></b>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;State Code : <b><?= html_escape($state_table[$result->SellerState][2]); ?></b>
        </td>
        <td style="width:50%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:left;padding: 3px;">
            Invoice No. : <b><?= $result->InvoiceNo; ?></b>
        </td>
    </tr>

    <tr>
        <td style="width:50%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:left;padding: 3px;">
            Invoice Date. : <b><?= human_date($result->InvoiceDate,'d F Y'); ?></b>
        </td>
    </tr>

    <tr>
        <td style="width:50%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:left;padding: 3px;">
            Transportation Mode : <b><?= html_escape($result->TransportationMode); ?></b>
        </td>
    </tr>

    <tr>
        <td style="width:50%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:left;padding: 3px;">
            Vehicle Number : <b><?= html_escape($result->VehicleNumber); ?></b>
        </td>
    </tr>

    <tr>
        <td style="width:50%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:left;padding: 3px;">
                Date & Time of Supply :
            <?php if($result->SupplyFromDate !=''){ ?>

                <?php if($result->SupplyFromDate != $result->SupplyToDate){ ?>
                    <b><?= human_date($result->SupplyFromDate,'d M'); ?></b>
                    to
                    <b><?= human_date($result->SupplyToDate,'d M Y'); ?></b>
                <?php }else{ ?>
                    <b><?= human_date($result->SupplyFromDate,'d M Y'); ?></b>
                <?php }/*end of if-else*/ ?>
            <?php }/*end of if*/ ?>
        </td>
    </tr>
    <tr>
        <td style="width:50%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:left;padding: 3px;">
            Place of Supply :   <b><?= html_escape($result->SupplyPlace); ?></b>
        </td>
    </tr>
    <tr>
        <td style="width:50%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:left;padding: 3px;">
            GSTIN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;&nbsp;<b><?= $result->SellerGstNo; ?></b><br>
            PAN No. &nbsp;: &nbsp;&nbsp;&nbsp;<b><?= $result->SellerPanNo; ?></b>
        </td>
        <td style="width:50%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:left;padding: 3px;">
            GSTIN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;&nbsp;<b><?= $this->sm->ss->gstin; ?></b><br>
            PAN No. &nbsp;: &nbsp;&nbsp;&nbsp;<b><?= $this->sm->ss->pan; ?></b>
        </td>
    </tr>
    </tbody>
</table>
<!--2nd TABLE END-->

<!--3rd TABLE STRAT-->
<table  class="table_style" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;border: 1px solid #000;
width: 100%;margin-top: 10px;">

    <thead>
    <tr>
        <th style="width:4%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:center;padding: 3px;">
            Sr.
        </th>
        <th style="width:35%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:center;padding: 3px;">
            Description of Goods
        </th>

        <th style="width:11%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:center;padding: 3px;">
            HSN
        </th>
        <th style="width:15%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:center;padding: 3px;">
            Qty./Ton
        </th>
        <th style="width:14%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:center;padding: 3px;">
            Rate (Rs.)
        </th>
        <th style="width:20%;float:left;border-right:1px solid #000;border-bottom:1px solid #000;text-align:center;padding: 3px;">
            Amount (Rs.)
        </th>
    </tr>
    </thead>
    <tbody>
    <?php $i = 1; ?>
    <?php foreach ($invoice_items as $row){ ?>
        <tr>
            <td style="float:left;border-right:1px solid #000;text-align:left;padding: 3px;">
                <?= $i; ?>
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:left;padding: 3px;">
                <?= html_escape($row->MaterialName); ?>
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:center;padding: 3px;">
                <?= html_escape($row->HsnCode); ?>
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;">
                <?= number_format($row->QtyOfMaterial,3); ?>
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;">
                <?= number_format($row->PriceOfUnit,2); ?>
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;">
                <?= number_format($row->Amount,2); ?>
            </td>
        </tr>
        <?php $i++; ?>
    <?php } ?>
    <?php for ($i=$i;$i<=10;$i++){ ?>
        <tr>
            <td style="float:left;border-right:1px solid #000;text-align:left;padding: 3px;">
                &nbsp;
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:left;padding: 3px;">
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:center;padding: 3px;">
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;">
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;">
            </td>
            <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;">
            </td>
        </tr>
    <?php } ?>
    <!--</tbody>
    <tfoot>-->
    <tr>
        <td style="float:left;border-right:1px solid #000;text-align:left;padding: 3px;">
        </td>
        <td style="float:left;border-right:1px solid #000;text-align:left;padding: 3px;">
        </td>
        <th style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:center;padding: 3px;">
            Total Qty
        </th>
        <th style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:right;padding: 3px;">
            <?= number_format($result->TotalQty,3); ?>
        </th>
        <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;">
        </td>
        <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;">
        </td>
    </tr>
    <tr>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:center;padding: 3px;" colspan="3" rowspan="1" valign="top">
            <b>Total Invoice amount in words</b>
        </td>
        <th style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:left;padding: 3px;" colspan="2">
            Total Amount Before Tax
        </th>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:right;padding: 3px;">
            <?= number_format($result->Amount,2); ?>
        </td>
    </tr>
    <tr>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:left;padding: 3px;" colspan="3" rowspan="4" valign="top">
            <b><?= get_indian_currency($result->TotalAmount); ?></b>
        </td>
        <th style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:left;padding: 3px;" colspan="2">
           Add: CGST (<?= $result->CgstPre; ?> %)
        </th>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:right;padding: 3px;">
            <?= number_format($result->CgstAmount,2); ?>
        </td>
    </tr>
    <tr>
        <th style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:left;padding: 3px;" colspan="2">
            Add: SGST (<?= $result->CgstPre; ?> %)
        </th>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:right;padding: 3px;">
            <?= number_format($result->SgstAmount,2); ?>
        </td>
    </tr>

    <tr>
        <th style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:left;padding: 3px;" colspan="2">
            Total Tax Amount
        </th>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:right;padding: 3px;">
            <?= number_format($result->SgstAmount+$result->CgstAmount,2); ?>
        </td>
    </tr>

    <tr>
        <th style="float:left;border-right:1px solid #000;border-top:2px solid #000;text-align:left;padding: 3px;" colspan="2">
            Total Amount after Tax:
        </th>
        <td style="float:left;border-right:1px solid #000;border-top:2px solid #000;text-align:right;padding: 3px;">
            <b><?= number_format($result->TotalAmount,2); ?></b>
        </td>
    </tr>

    <tr>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:left;padding: 3px;" colspan="4">
            <b>Bank Detail:</b>
            <?=$this->sm->ss->bank_name; ?><br>
            A/C No. : <?=$this->sm->ss->bank_account; ?> /
            IFSC Code : <?=$this->sm->ss->bank_ifsc; ?>
        </td>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:left;padding: 3px;" colspan="2" valign="top">
            For, NILKANTH STONE CRUSHER
        </td>
    </tr>

    <tr>
        <td style="float:left;border-right:1px solid #000;border-top:1px solid #000;text-align:left;padding: 3px;" colspan="4">
            <b>TERMS & CONDITIONS</b><br>
            <ol style="font-size: 12px;">
                <li>Interest @ 24% P.A. will be charged if Payment is not received with agreed credit period.</li>
                <li>We reserve our right to demand and recover the full or part amount of the bill anytime.</li>
                <li>Our risk and responsibility ceases as soon as goods leave our factory godown.</li>
                <li>We are not responsible for any transit damage/losses.</li>
                <li>Subject to BHARUCH jurisdiction only in case of any disputes. </li>
            </ol>
        </td>
        <td style="float:left;border-right:1px solid #000;text-align:right;padding: 3px;" colspan="2" valign="bottom">
            Authorized Signatory
        </td>
    </tr>
    </tbody>
</table>
<!--3rd TABLE END-->

