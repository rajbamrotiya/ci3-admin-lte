<!---- 2nd PAGE  ---->
<h1 style="font-size:18px;font-weight:bold;"> Present Value Schedule </h1>
<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>


<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Claimant :</div>
    <div style="font-size:14px;float:left;"> <?php echo $first_name . '&nbsp;' . $last_name; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Reference Number :</div>
    <div style="font-size:14px;float:left;">  <?php echo $referenceNumber; ?> </div>
</div>

<div style="margin-top:2%;padding:1% 0;font-size:14px;font-weight:bold;"> Present Value Schedule Details:</div>
<table repeat_header="1" class="table_style" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;border: 1px solid #000;
width: 100%;">
    <thead>
    <tr class="table_header" style="background-color:#eeebeb; ">
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">From
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">To
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">No. of Week
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">
            Age At Period End
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">
            Mortality Adjustment
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">
            Disability Adjustment
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">
            Unemployment Adjustment
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">Real Discount Rate
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">
            Gross Projected Income
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">
            Multiplier
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">
            Present Value
        </th>
        <th scope="col"
            style="border-right:1px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;">
            Cumulative Present Value
        </th>
    </tr>
    </thead>
    <tbody>
    <?php if(!empty($present_value_schedule)){
        $i=1;
        foreach(@$present_value_schedule as $row){
            if(($i%2) == 0){
                $tr_class ='background-color: #f8f6f6;';
            }else{
                $tr_class ="";
            }
            $i++;
            ?>
            <tr style="<?php echo $tr_class;?>">
                <!--<td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:center;" rowspan="2">
                    <?php /*echo $i; $i++;*/?>
                </td>-->
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:center;">
                    <?php echo ($row['From'] !='')?date('m/d/Y',strtotime($row['From'])):''; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:center;">
                    <?php echo ($row['To'] !='')?date('m/d/Y',strtotime($row['To'])):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['NumberOfWeeks']!="") ? number_format($row['NumberOfWeeks'],2):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['AgeAtPeriodEnd']!="") ? number_format($row['AgeAtPeriodEnd'],2):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['MortalityAdjustment']!="") ? number_format($row['MortalityAdjustment'],4):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['DisabilityAdjustment']!="") ? number_format($row['DisabilityAdjustment'],4):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['UnemploymentAdjustment']!="") ? number_format($row['UnemploymentAdjustment'],4):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['RealDiscountRate']!="") ? number_format($row['RealDiscountRate'],2).'%':'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['GrossProjectedIncome']!="") ? '$'.number_format($row['GrossProjectedIncome'],0):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['Multiplier']!="") ? number_format($row['Multiplier'],4):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['PresentValue']!="") ? '$'.number_format($row['PresentValue'],0):'&nbsp;'; ?>
                </td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;">
                    <?php echo ($row['CumulativePresentValue']!="") ? '$'.number_format($row['CumulativePresentValue'],0):'&nbsp;'; ?>
                </td>
            </tr>
        <?php }
    } ?>

    <!----- ONLY ONCE ------>
    <!--<tr>
        <td scope="col" style="border-top:1px solid #000;font-size:12px;font-weight:normal;padding:4px;" colspan="7"></td>
    </tr>-->
    </tbody>
</table>


<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;margin-top:5%;">The following assumptions are applied to the present value calculations presented here in :</div>
<div style="width:100%;float:left;margin-left:2%; font-size:14px;float:left;">
    <ul>
        <li>This calculation is based on the information provided to ADS Forensics Inc.</li>
        <?php if(in_array(1,$contingencies)){ ?>
        <li>If applied, the individual’s life expectancy and annual probability of survival is based on the Statistics Canada Life Tables, Canada and Provinces, 2009 - 2011.</li>
        <?php }else{ ?>
            <li>If applied, the individual’s life expectancy is based on the Statistics Canada Life Tables, Canada and Provinces, 2009 - 2011.</li>
        <?php } ?>
        <?php if(in_array(1,$contingencies)){ ?>
            <li>If applied, the disability adjustment is based on the "Ultimate disability incidence rates" from Table 78 in the Actuarial Report (26th) on the Canada Pension Plan dated November 21, 2013.</li>
        <?php }else{ ?>
            <li>If applied, the unemployment adjustment is based on the Labour Force Survey, per Statistics Canada,Table 282-0004.</li>
        <?php } ?>
        <li>If applied, the unemployment adjustment is based on the number of unemployed persons expressed as a percentage of the labour force by gender and educational attainment level, per the Labour Force survey per Statistics Canada, Table 282-0004.</li>
        <li>The future income stream is limited to the individual’s life expectancy.</li>
    </ul>
</div>