<h1 style="font-size:18px;font-weight:bold;"> Calculation of Income Replacement Benefits </h1>

<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Claimant : </div>
    <div style="font-size:14px;float:left;"> <?php echo $claimant; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Claim Number : </div>
    <div style="font-size:14px;float:left;">  <?php echo $claim_no; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Date of Motor Vehicle Accident: </div>
    <div style="font-size:14px;float:left;">  <?php echo date('F d, Y',strtotime($date_incident)); ?> </div>
</div>

<div style="width:98%;padding:1%"> </div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Period :</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  From </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;"> <?php echo date('F d, Y',strtotime($IRB_POST_FROMDATE)); ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  To </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($IRB_POST_TODATE)); ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  No. of Weeks </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo number_format($IRB_POST_OFWEEKS,2); ?> </div>
</div>

<div style="width:98%;padding:1%"> </div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Calculation Input :</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Claimant's Date of Birth </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($date_birth)); ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Claimant is 65 </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php  $date_birth65 = new DateTime($date_birth65);
		  echo $date_birth65->format('F d, Y') .""; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Employment Status </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $employment_status; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Indexation </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo ($index_option==1) ? 'True' :'False'; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  IRB Limit </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;"><?php echo '$'.number_format($irb_limit,2); ?>
    </div>
   <div style="float:right;margin-left:5%;font-size:14px;font-weight:100;"> per Week </div>
 </div>  

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;"> Date of Disability </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php //echo $date_disability; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  SABS </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $SABS; ?> </div>
</div>

<div style="width:98%;padding:1%"> </div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Pre Accident Input : </div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Employment Income </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;"> <?php echo ($pre_emp_income==='N/A') ? $pre_emp_income : '$'.number_format($pre_emp_income,2); ?>  </div>
    <div style="float:right;margin-left:5%;font-size:14px;font-weight:100;"> per Year </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Employer Paid Benefits </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;">  <?php echo ($pre_emp_benefits==='N/A') ? $pre_emp_benefits : '$'.number_format($pre_emp_benefits,2); ?> </div>
    <div style="float:right;margin-left:5%;font-size:14px;font-weight:100;"> per Year </div>
</div>


<div style="width:98%;padding:1%"> </div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Post Accident Input	:</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Employment Income </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;">  <?php echo ($post_emp_income==='N/A') ? $post_emp_income : '$'.number_format($post_emp_income,2); ?> </div>
    <div style="float:right;margin-left:5%;font-size:14px;font-weight:100;"> per Week </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Employer Paid Benefits </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;">  <?php echo ($post_emp_benefits==='N/A') ? $post_emp_benefits :'$'.number_format($post_emp_benefits,2); ?> </div>
    <div style="float:right;margin-left:5%;font-size:14px;font-weight:100;"> per Week </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;"> Collateral Benefits</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;">  <?php echo ($post_collateral_benefits==='N/A') ? $post_collateral_benefits : '$'.number_format($post_collateral_benefits,2); ?> </div>
    <div style="float:right;margin-left:5%;font-size:14px;font-weight:100;"> per Week </div>
</div>

<div style="width:98%;padding:1%"> </div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Calculation Warnings :</div>


<?php  $i=1; foreach($warn as $warn_msg) { if($warn_msg!=""){?>

<div style="padding:2px;">
    <div style="float:left;width:4%;margin-left:5%;font-size:14px;font-weight:100;">  [<?php echo $i; ?>] </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:80%;">  <?php echo $warn_msg; ?> </div>
</div>

<?php $i++;} } ?>

<?php if($i<5) { for($j=$i;$j<=5;$j++) {?>
<div style="padding:2px;">
    <div style="float:left;width:4%;margin-left:5%;font-size:14px;font-weight:100;">  [<?php echo $j; ?>] </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">   </div>
</div>
<?php } } ?>




<div style="width:98%;padding:1%"> </div>

<div style="margin-top:2%;padding:1% 0;font-size:14px;font-weight:bold;"> Income Replacement Benefit Payable Summary : </div>
<table class="table_style" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;border: 1px solid #000;
width: 100%;">

<tbody>
	<tr>
    	<th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> From Date </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> To Date </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> Weeks </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> Weekly Benefit Payable </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> Total Benefit Payable </th>
       
	</tr>
	 <tr>
    	<th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo date('m/d/Y',strtotime($IRB_POST_FROMDATE)); ?> </th>
        <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo date('m/d/Y',strtotime($IRB_POST_TODATE)); ?> </th>
        <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo number_format($IRB_POST_OFWEEKS,2);  ?> </th>
        <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo '$'.number_format($result1,2); ?> </th>
        <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo '$'.number_format($result2,2); ?> </th>
	</tr>
</tbody>                                    

</table>

<div style="width:100%;float:left;padding:2px;font-size:12px;font-weight:bold;float:left;margin-top:5%;">Notes :</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;"> 
	<div style="width:3%;min-height:30px;float:left;"> <b> [1]  </b>  </div>
    <div style="float:left;">
	 <b>Calculated based on Ontario Regulation 34/10 (Statutory Accident Benefits Schedule)</b>
     <br />Prepared using ADS Forensics Inc. IRB Calculator.
     </div>
</div>

