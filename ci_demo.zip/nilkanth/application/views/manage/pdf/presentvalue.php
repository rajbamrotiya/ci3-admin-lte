<h1 style="font-size:18px;font-weight:bold;"> Present Value Calculation </h1>

<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Claimant : </div>
    <div style="font-size:14px;float:left;"> <?php echo $first_name.'&nbsp;'.$last_name; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Reference number : </div>
    <div style="font-size:14px;float:left;">  <?php echo $referenceNumber; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Details :</div>

<!--<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Description :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php /*echo $CalcDescription; */?> </div>
</div>-->

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Gender :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $gender; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Of Birth :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo ($appdob!="") ? date('F d, Y',strtotime($appdob)) : ''; ?>  </div>
</div>
<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Of Incident : </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($Date_incident)) ?>  </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Valuation Date : </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($trialdate)) ?>  </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Discount Rate - first 15 years :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo number_format($Discount15,2).' % '; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Discount Rate -from 16 years :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo number_format($Discount16,2).' % '; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Estimated Age at Valuation Date :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $ageest; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Projected Income Details :</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Type of Income Stream :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;"> <?php echo ($Type==1)?'Indexed':'Non-indexed'; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Projected Annual Income :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;"> <?php echo '$'.number_format($Income,2); ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Projected Income Starts :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($CalcStartDate)); ?> </div>
</div>
<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Projected Income Ends :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($CalcEndDate)); ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;">Apply Contingencies:</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Mortality :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;"> <?php echo (in_array(1,$contingencies))?'Yes':'No'; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Disability :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;"> <?php echo (in_array(2,$contingencies))?'Yes':'No'; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Unemployment :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;"> <?php echo (in_array(3,$contingencies))?'Yes':'No'; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;margin-top:3%;"> Present Value Calculation Results at the Trial Date :</div>

<!--<div style="padding:2px;">
    <div style="float:left;width:50%;margin-left:5%;font-size:14px;font-weight:100;">  Total Mortality Adjustment  </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;">
        <?php
/*        echo ($calculate_total['MortalityAdjustment']!="") ?number_format($calculate_total['MortalityAdjustment'],4): ''; */?>
    </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:50%;margin-left:5%;font-size:14px;font-weight:100;">  Total Disability Adjustment  </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;">
        <?php
/*        echo ($calculate_total['DisabilityAdjustment']!="") ?number_format($calculate_total['DisabilityAdjustment'],4): ''; */?>
    </div>
</div>-->

<div style="padding:2px;">
    <div style="float:left;width:50%;margin-left:5%;font-size:14px;font-weight:100;">  Total Multiplier  </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;">
        <?php
        echo ($calculate_total['Multiplier']!="") ?number_format($calculate_total['Multiplier'],4): ''; ?>
    </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:50%;margin-left:5%;font-size:14px;font-weight:100;">  Present Value  </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:30%;">
        <?php
        echo ($calculate_total['PresentValue']!="") ?'$'.number_format($calculate_total['PresentValue'],0): ''; ?>
    </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:12px;font-weight:bold;float:left;margin-top:5%;">Notes :</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;"> 
	<div style="width:3%;min-height:30px;float:left;"> <b> [1]  </b>  </div>
    <div style="float:left;">
        Mortality Adjustment based on the individual’s life expectancy at the valuation date, as set out in the Statistics Canada Life Tables, Canada and Provinces, 2009-2011, Catalogue #84-537, for the individual’s gender and all of Canada. The probabilities are cumulative each year.
     </div>
</div>


<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;">
    <div style="width:3%;min-height:30px;float:left;"> <b> [2]  </b>  </div>
    <div style="float:left;">
        Disability adjustment calculated as the probability the individual will not incur a disability serious enough to permanently be removed from the workforce. This is based on the "Ultimate disability incidence rates" from Table 78 in the Actuarial Report (26th) on the Canada Pension Plan dated November 21, 2013.  The probabilities are cumulative each year.
    </div>
</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;">
    <div style="width:3%;min-height:30px;float:left;"> <b> [3]  </b>  </div>
    <div style="float:left;">
        Unemployment adjustment is based on the number of unemployed persons expressed as a percentage of the labour force by gender and educational attainment level. This is based on the Labour force survey, per Statistics Canada, Table 282-0004.The probabilities are not cumulative each year.
    </div>
</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;">
    <div style="width:3%;min-height:30px;float:left;"> <b> [4]  </b>  </div>
    <div style="float:left;">
        Based on Section 53.09 (1) of the Rules of Civil Procedure, which establishes a discount rate that reflects the difference between estimated investment and price inflation rates. It is assumed that the price inflation rates are representative of the individual annual wage increase.
    </div>
</div>