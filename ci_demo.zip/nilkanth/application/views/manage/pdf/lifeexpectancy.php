<h1 style="font-size:18px;font-weight:bold;"> Life Expectancy Calculation </h1>

<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;">  Claimant : </div>
    <div style="font-size:14px;float:left;"> <?php echo $first_name.'&nbsp;'.$last_name; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;"> 
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Reference number : </div>
    <div style="font-size:14px;float:left;">  <?php echo $reference_no; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Details :</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Gender :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $gender; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Date Of Birth :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo ($appdob!="") ? date('F d, Y',strtotime($appdob)) : ''; ?>  </div>
</div>
<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Valuation Date : </div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo date('F d, Y',strtotime($trialdate)) ?>  </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Life Table :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $table; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;">  Estimated Age at Valuation Date :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $ageest; ?> </div>
</div>

<div style="margin-top:20px;width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;">
	Life Expectancy Calculation Results:
</div>

<div style="padding:2px;">
	<div style="float:left;width:40%;margin-left:5%;font-size:14px;font-weight:100;">  Age :</div>
	<div style="float:left;font-size:14px;font-weight:100;width:50%;">  
 		<div style="width:25%;float:left;text-align:center;">
            <?php echo ($life_expectancy_schedule[0]['Age']!="") ? number_format ($life_expectancy_schedule[0]['Age'],2): '&nbsp;'; ?>
        </div> 
        
   		<div style="width:25%;float:left;text-align:center;">
            <?php echo ($life_expectancy_schedule[1]['Age']!="") ? number_format ($life_expectancy_schedule[1]['Age'],2):'&nbsp;'; ?>
         </div>
          
    	<div style="width:25%;float:left;text-align:center;">
            <?php echo ($life_expectancy_schedule[2]['Age']!="") ? number_format ($life_expectancy_schedule[2]['Age'],2):'&nbsp;'; ?>
        </div> 
        
    	<!--<div style="width:25%;float:left;text-align:center;">
        	<?php /*echo ($API_result->year4!="") ? round ($API_result->year4,2):''; */?> <br />
             <p style="float:left;margin-top:-20px;font-weight:bold;font-size:22px;">______<p>
        </div>-->
    </div>
</div>

<div style="padding:2px;float:left;">
	<div style="float:left;width:40%;margin-left:5%;font-size:14px;font-weight:100;"> Standard Remaining Life Expectancy (years) :</div>
	<div style="float:left;font-size:14px;font-weight:100;width:50%;">  
 		<div style="width:25%;float:left;text-align:center;">
            <?php echo ($life_expectancy_schedule[0]['LifeExpectancy']!="") ? number_format ($life_expectancy_schedule[0]['LifeExpectancy'],2): '&nbsp;'; ?>
        </div> 
    	<div style="width:25%;float:left;text-align:center;">
            <?php echo ($life_expectancy_schedule[1]['LifeExpectancy']!="") ? number_format ($life_expectancy_schedule[1]['LifeExpectancy'],2):'&nbsp;'; ?>
        </div>
        <div style="width:25%;float:left;text-align:center;">
            <?php echo ($life_expectancy_schedule[2]['LifeExpectancy']!="") ? number_format ($life_expectancy_schedule[2]['LifeExpectancy'],2):'&nbsp;'; ?>
        </div>
        <!--<div style="width:25%;float:left;text-align:center;">
        	<?php /*echo ($API_result->standard4!="")?round ($API_result->standard4,2):''; */?>
        </div>-->
	</div>
</div>
<div style="width:100%;float:left;padding:2px;font-size:12px;font-weight:bold;float:left;margin-top:5%;">Notes :</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;"> 
	<b> [1]  </b>  This calculations are based on the Ontario or Canada life 
tables for 2009 - 2011.
</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;"> 
	<b> [2]   </b> The middle column represents the Plaintiff’s age at the valuation date. The Standard Remaining Life Expectancy is estimated based on the values in the surrounding columns.
</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;">
    <b> [3]   </b> This calculation is based on the information provided to ADS Forensics Inc. ADS Forensics Inc. has not validated the accuracy or reasonableness of this data.
</div>