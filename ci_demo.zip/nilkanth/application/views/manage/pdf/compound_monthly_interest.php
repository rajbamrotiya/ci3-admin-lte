<!--- FIRST PAGE --->
<h1 style="font-size:18px;font-weight:bold;"> Interest Calculation - Schedule 1 </h1>
<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>

<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Claimant :</div>
    <div style="font-size:14px;float:left;"> <?php echo $first_name . '&nbsp;' . $last_name; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Reference Number :</div>
    <div style="font-size:14px;float:left;">  <?php echo $refrence_no; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Date Of Incident :</div>
    <div style="font-size:14px;float:left;">  <?php echo ($date_incident != "") ? date('F d, Y', strtotime($date_incident)) : ''; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:14px;font-weight:bold;float:left;"> Details :</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;"> Calculation Type :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $cal_name; ?> </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;"> Interest Settlement Date :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo ($settlement_date != "") ? date('F d, Y', strtotime($settlement_date)) : ''; ?>  </div>
</div>
<div style="padding:2px;">
    <div style="float:left;width:35%;margin-left:5%;font-size:14px;font-weight:100;"> Interest Rate :</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:50%;">  <?php echo $interest_rate; ?>  </div>
</div>

<div style="width:100%;float:left;padding:1px;font-size:14px;font-weight:bold;float:left;margin-top:3%;"> Interest
    Calculation Results :
</div>

<div style="float:left;width:100%;margin-left:5%;font-size:13px;font-weight:800;font-style:italic;"><p
            style="width:55%"> Interest calculations are prepared based on the dates provided. Interest is calculated a
        day after the period ends for amounts owing, the last day of a period for amounts paid, and on the date provided
        for lump sums. No interest is calculated while a negative balance exists.</p></div>

<div style="padding:2px;">
    <div style="float:left;width:20%;margin-left:5%;font-size:14px;font-weight:100;"> Payments Due :</div>
    <div style="float:left;width:7%;font-size:12px;font-weight:100;">&nbsp;</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:20%;text-align:right;">
        <?php if ($pay_interval_amount != "") {
            echo '$' . number_format($CalculationResult['PaymentsDue'], 2);
        } ?>
    </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:20%;margin-left:5%;font-size:14px;font-weight:100;"> Payments Made :</div>
    <div style="float:left;width:7%;font-size:12px;font-weight:100;">Subtract</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:20%;text-align:right;border-bottom:2px solid #000;">
        <?php if ($pay_interval_amount != "") {
            echo '$' . number_format($CalculationResult['PaymentsMade'], 2);
        } ?>
    </div>
</div>
<div style="padding:2px;">
    <div style="float:left;width:20%;margin-left:5%;font-size:14px;font-weight:100;"> Payments Owing:</div>
    <div style="float:left;width:7%;font-size:12px;font-weight:100;">&nbsp;</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:20%;text-align:right;">
        <?php if ($pay_interval_amount != "") {
            echo '$' . number_format($CalculationResult['PaymentsOwing'], 2);
        } ?>
    </div>
</div>
<div style="padding:2px;">
    <div style="float:left;width:20%;margin-left:5%;font-size:14px;font-weight:100;"> Interest Owing :</div>
    <div style="float:left;width:7%;font-size:12px;font-weight:100;">Add</div>
    <div style="float:left;font-size:14px;font-weight:100 !important;width:20%;text-align:right;border-bottom:2px solid #000;">
        <?php if ($pay_interval_amount != "") {
            echo '$' . number_format($CalculationResult['InterestOwing'], 2);
        } ?>
    </div>
</div>

<div style="padding:2px;">
    <div style="float:left;width:20%;margin-left:5%;font-size:16px;font-weight:bold;"> TOTAL OWING :</div>
    <div style="float:left;width:7%;font-size:12px;font-weight:100;">&nbsp;</div>
    <div style="float:left;font-size:16px;font-weight:bold !important;width:20%;text-align:right;border-bottom:3px solid #000;">
        <?php if ($pay_interval_amount != "") {
            echo '$' . number_format($CalculationResult['TotalOwing'], 2);
        } ?>
    </div>
</div>

<div style="width:100%;float:left;padding:2px;font-size:12px;font-weight:bold;float:left;margin-top:5%;">Notes :</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;">
    <div style="width:3%;min-height:30px;float:left;"><b> [1] </b></div>
    <div style="float:left;">
        Calculated in accordance with Ontario Regulations 403/96 and 34/10 (Statutory Accident Benefits Schedules).
    </div>
</div>

<div style="width:100%;float:left;margin-left:2%; font-size:13px;float:left;">
    <div style="width:3%;min-height:30px;float:left;"><b> [2] </b></div>
    <div style="float:left;">
        The TOTAL OWING includes outstanding payments and interest to the Interest Settlement Date. If payment is not
        made by the Interest Settlement Date , additional interest would be owing.
    </div>
</div>
<div style="width:100%;float:left;padding:2px;font-size:12px;font-weight:bold;float:left;margin-top:5%;">The following
    assumptions are applied to the interest calculations presented here in :
</div>
<div style="width:100%;float:left;margin-left:2%; font-size:14px;float:left;">
    <ul>
        <li>The dates and amounts owing, as indicated in the table above, are accurate and complete. ADS Forensics Inc.
            has not been provided documentation from which to validate this information.
        </li>
        <li>For any period in which the calculation results in an overpayment, the interest rate is assumed to be nil.
        </li>
        <li>Interest on outstanding amounts accrues from the day after a payment period ends.</li>
        <li>Interest on lump sum payments accrues from the lump sum date.</li>
        <?php
        $settlement_date = date("Y-m-d", strtotime($settlement_date));
        $dob = date("Y-m-d", strtotime($date_birth));
        $years = round((strtotime($settlement_date) - strtotime($dob)) / (3600 * 24 * 365.25));
        if ($years >= 65) { ?>
            <li>Any impact on the benefit rates as a result of the claimant’s 65th birthday being before the interest
                settlement date, are considered in the table above.
            </li>
        <?php }
        ?>
    </ul>
</div>


<!---- SECOND PAGE  ---->
<h1 style="font-size:18px;font-weight:bold;page-break-before:always"> Interest Calculation - Schedule 2 </h1>
<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>


<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Claimant :</div>
    <div style="font-size:14px;float:left;"> <?php echo $first_name . '&nbsp;' . $last_name; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Reference Number :</div>
    <div style="font-size:14px;float:left;">  <?php echo $refrence_no; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Date Of Incident :</div>
    <div style="font-size:14px;float:left;">  <?php echo ($date_incident != "") ? date('F d, Y', strtotime($date_incident)) : ''; ?>  </div>
</div>

<div style="margin-top:2%;padding:1% 0;font-size:14px;font-weight:bold;"> Payment Details:</div>
<table  class="table_style" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;border: 1px solid #000;
width: 100%;">
    <thead>
    <tr>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;">
            Type
        </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;">
            Interval
        </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;">
            Interval Amount
        </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;">
            Start Date
        </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;"> End
            Date
        </th>
        <th style="width:2%;float:left;border-right:2px solid #000;border-bottom:1px solid #000;text-align:center;">
            Total Amount
        </th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($pay_interval_amount as $key => $val) { ?>
        <?php
        if ($pay_interval_id[$key] == 1)
            $interval = 'Bi-weekly';
        else if ($pay_interval_id[$key] == 2)
            $interval = 'Monthly';
        else if ($pay_interval_id[$key] == 3)
            $interval = 'Lump Sum';
        ?>
        <tr>
            <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo $pay_type[$key]; ?> </th>
            <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo $interval; ?> </th>
            <th style="width:2%;float:left;text-align:right;font-weight:normal;"> <?php echo '$' . number_format($pay_interval_amount[$key], 2); ?> </th>
            <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo $pay_startdate[$key]; ?> </th>
            <th style="width:2%;float:left;text-align:center;font-weight:normal;"> <?php echo $pay_enddate[$key]; ?> </th>
            <th style="width:2%;float:left;text-align:right;font-weight:normal;"> <?php echo '$' . number_format($pay_total_amount[$key], 2); ?> </th>
        </tr>

    <?php } ?>


    </tbody>

</table>


<!---- 3RD PAGE  ---->
<h1 style="font-size:18px;font-weight:bold;page-break-before:always"> Interest Calculation - Schedule 3 </h1>
<div style="width:100%;border:1px solid #000;margin-bottom:10px;"></div>


<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Claimant :</div>
    <div style="font-size:14px;float:left;"> <?php echo $first_name . '&nbsp;' . $last_name; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Reference Number :</div>
    <div style="font-size:14px;float:left;">  <?php echo $refrence_no; ?> </div>
</div>

<div style="width:100%;float:left;padding:2px;">
    <div style="font-size:14px;font-weight:bold;width:40%;float:left;"> Date Of Incident :</div>
    <div style="font-size:14px;float:left;"> <?php echo ($date_incident != "") ? date('F d, Y', strtotime($date_incident)) : ''; ?> </div>
</div>

<div style="margin-top:2%;padding:1% 0;font-size:14px;font-weight:bold;"> Interest Calculation Details:</div>
<table repeat_header="1" class="table_style" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;border: 1px solid #000;
width: 100%;">
    <thead>
    <tr class="table_header">
        <th scope="col"
            style="border-right:2px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;width: 20%;">Date
        </th>
        <th scope="col"
            style="border-right:2px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;width: 20%;">Owed/Paid
        </th>
        <th scope="col"
            style="border-right:2px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;width: 20%;">Interest
            on Prior Month End Balance
        </th>
        <th scope="col"
            style="border-right:2px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;width: 20%;">
            Transaction Interest to Month End
        </th>
        <th scope="col"
            style="border-right:2px solid #000;border-bottom:1px solid #000;font-size:12px;font-weight:bold;width: 20%;">Balance
            Forward to Month End
        </th>
    </tr>
    </thead>
    <tbody>
    <?php if(!empty($SingleDateArray)){
        foreach(@$SingleDateArray as $row){ ?>
            <tr>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:center;"><?php echo date('m/d/Y',strtotime($row['InterestDate'])); ?></td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;"><?php echo ($row['Amount']!="") ? '$'.number_format($row['Amount'],2):''; ?></td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;"><?php echo ($row['InterestonPriorMonthEndBalance']!="") ? '$'.number_format($row['InterestonPriorMonthEndBalance'],2):''; ?></td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;"><?php echo ($row['TransactionInteresttoMonthEnd']!="") ? '$'.number_format($row['TransactionInteresttoMonthEnd'],2):''; ?></td>
                <td scope="col"
                    style="font-size:12px;font-weight:normal;padding:4px;text-align:right;"><?php echo ($row['BalanceForwardtoMonthEnd']!="") ? '$'.number_format($row['BalanceForwardtoMonthEnd'],2):''; ?></td>
            </tr>
        <?php }
    } ?>

    <!----- ONLY ONCE ------>
    <tr>
        <td scope="col" style="border-top:1px solid #000;font-size:12px;font-weight:normal;padding:4px;">Outstanding:</td>
        <td scope="col"
            style="border-top:1px solid #000;font-size:12px;font-weight:normal;padding:4px;text-align:right;">&nbsp;
            <?php echo '$'.number_format(array_sum(array_map(function($item) {
                return $item['Amount'];
            }, $SingleDateArray)),2); ?>
        </td>
        <td scope="col"
            style="border-top:1px solid #000;font-size:12px;font-weight:normal;padding:4px;text-align:right;">&nbsp;
            <?php echo '$'.number_format(array_sum(array_map(function($item) {
                return $item['InterestonPriorMonthEndBalance'];
            }, $SingleDateArray)),2); ?>
        </td>
        <td scope="col"
            style="border-top:1px solid #000;font-size:12px;font-weight:normal;padding:4px;text-align:right;">
            <?php echo '$'.number_format(array_sum(array_map(function($item) {
                    return $item['TransactionInteresttoMonthEnd'];
                }, $SingleDateArray)),2); ?>
        </td>
        <td scope="col"
            style="border-top:1px solid #000;font-size:12px;font-weight:normal;padding:4px;text-align:right;">&nbsp;
        </td>
    </tr>
    <tr>
        <td scope="col" style="font-size:12px;font-weight:normal;padding:4px;" colspan="5"></td>
    </tr>
    <tr>
        <td style="font-size:12px;font-weight:normal;padding:4px;text-align: left;" colspan="1">Interest Owing:</td>
        <td style="font-size:12px;font-weight:normal;padding:4px;text-align:left;" colspan="4">
            <?php
            $InterestOwing = $CalculationResult['InterestOwing'];
            echo '$'.number_format($InterestOwing,2); ?>
        </td>
    </tr>
    </tbody>
</table>

<div style="width:100%;float:left;padding:2px;font-size:12px;font-weight:bold;float:left;margin-top:5%;">The following
    assumptions are applied to the interest calculations presented here in :
</div>
<div style="width:100%;float:left;margin-left:2%; font-size:14px;float:left;">
    <ul>
        <li>The dates and amounts owing, as indicated in the table above, are accurate and complete. ADS Forensics Inc.
            has not been provided documentation from which to validate this information.
        </li>
        <li>For any period in which the calculation results in an overpayment, the interest rate is assumed to be nil.
        </li>
        <li>Interest on outstanding amounts accrues from the day after a payment period ends.</li>
        <li>Interest on lump sum payments accrues from the lump sum date.</li>
        <?php
        $settlement_date = date("Y-m-d", strtotime($settlement_date));
        $dob = date("Y-m-d", strtotime($date_birth));
        $years = round((strtotime($settlement_date) - strtotime($dob)) / (3600 * 24 * 365.25));
        if ($years >= 65) { ?>
            <li>Any impact on the benefit rates as a result of the claimant’s 65th birthday being before the interest
                settlement date, are considered in the table above.
            </li>
        <?php }
        ?>
    </ul>
</div>