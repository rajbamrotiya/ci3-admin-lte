<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> <?php echo @$this->sm->ss->panel_version; ?>
    </div>
    <strong><?php echo @$this->sm->ss->site_copyright; ?></strong> All rights reserved.
</footer>
<div class="modal fade" id="delete_popup">
	<div class="modal-dialog modal-sm">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close closes" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h3 class="modal-title"><i class="icon fa fa-warning"></i> Confirmation Alert</h3>
			</div>
			<div class="modal-body">
				<p>Are you sure you want to delete this record? You cannot recover it back.</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left closes" data-dismiss="modal">No</button>
				<button type="button" class="btn btn-danger confirm">Yes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->