<?php $page_name = $this->router->fetch_class(); ?>
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo $thumb_profile_img_login_user; ?>" class="img-circle"
                     alt="<?php echo html_escape($this->session->userdata('adminfname')); ?>">
            </div>
            <div class="pull-left info">
                <p>
                    <?php echo html_escape($this->session->userdata('adminfname')); ?><br>
                    <small><?php echo html_escape($roles_key_value[$this->session->userdata('admin_type')]); ?></small>
                </p>
            </div>
        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="<?php echo $page_name == "home" ? "active" : "" ?>">
                <a href="<?php echo site_url('home'); ?>">
                    <i class="fa fa-dashboard"></i><span>Dashboard</span>
                </a>
            </li>
            <?php if (is_accessible('admin', 'index')) { ?>
                <li class="<?php echo $page_name == "admin" ? "active" : "" ?>">
                    <a href="<?php echo site_url('admin'); ?>">
                        <i class="fa fa-user"></i> <span>Admins</span>
                    </a>
                </li>
            <?php } ?>

            <?php if (is_accessible('material', 'index')) { ?>
                <li class="<?php echo $page_name == "material" ? "active" : "" ?>">
                    <a href="<?php echo site_url('material'); ?>">
                        <i class="fa fa-medium"></i> <span>Materials</span>
                    </a>
                </li>
            <?php } ?>

            <?php if (is_accessible('seller', 'index')) { ?>
                <li class="<?php echo $page_name == "seller" ? "active" : "" ?>">
                    <a href="<?php echo site_url('seller'); ?>">
                        <i class="fa fa-users"></i> <span>Sellers</span>
                    </a>
                </li>
            <?php } ?>


            <?php if (is_accessible('invoice', 'index')) { ?>
                <li class="<?php echo $page_name == "invoice" ? "active" : "" ?>">
                    <a href="<?php echo site_url('invoice'); ?>">
                        <i class="fa fa-file-text"></i> <span>Invoices</span>
                    </a>
                </li>
            <?php } ?>

            <li class="treeview  <?php echo $page_name == "page_search" ? "active" : "" ?>">
                <a href="#">
                    <i class="fa fa-folder"></i> <span>Examples</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo $page_name == "page_search" ? "active" : "" ?>">
                        <a href="<?php echo site_url('page_search'); ?>">
                            <i class="fa fa-circle-o"></i> <span>Pagination and Serach</span>
                        </a>
                    </li>
                </ul>
            </li>
            <?php if (is_accessible('mail_template', 'index') OR is_accessible('settings', 'index')) { ?>
                <li class="<?php echo $page_name == "mail_template" || $page_name == "settings" ? "active" : "" ?> treeview">
                    <a href="#">
                        <i class="fa fa-gear"></i> <span>General</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if (is_accessible('mail_template', 'index')) { ?>
                            <li class="<?php echo $page_name == "mail_template" ? "active" : "" ?>">
                                <a href="<?php echo site_url('mail_template'); ?>">
                                    <i class="fa fa-circle-o"></i> <span>Mail Template</span></a>
                            </li>
                        <?php } ?>
                        <?php if (is_accessible('settings', 'index')) { ?>
                            <li class="<?php echo $page_name == "settings" ? "active" : "" ?>">
                                <a href="<?php echo site_url('settings'); ?>">
                                    <i class="fa fa-circle-o"></i> <span>Settings</span></a>
                            </li>
                        <?php } ?>
                    </ul>
                </li>
            <?php } ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>