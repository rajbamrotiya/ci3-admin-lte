<script type="application/javascript">
	var baseUrl = '<?php echo base_url();?>';
	var siteUrl = '<?php echo site_url();?>';
</script>
<!--Bootstrap js-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
 
<script type="text/javascript" src="<?php echo site_url()."themes/manage/js/jquery-1.11.1.min.js" ?>"></script> 
<script type="text/javascript" src="<?php echo site_url()."themes/manage/js/bootstrap.min.js" ?>"></script>
<script type="text/javascript" src="<?php echo site_url()."themes/manage/js/validate.min.js" ?>"></script>
<script type="text/javascript" src="<?php echo site_url()."themes/manage/js/validate_init.js" ?>"></script>
<script type="text/javascript" src="<?php echo site_url()."themes/manage/js/functions.js" ?>"></script>	
 
 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
