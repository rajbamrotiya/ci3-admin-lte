<?php if(@$error_msg!=''){?>
	<div class="alert alert-danger alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-ban"></i>Error !</h4>
		<?php echo $error_msg;?>
	</div>
<?php } ?>
<?php if(@$information_msg!=''){?>
	<div class="alert alert-info alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-info"></i>Note:</h4>
		<?php echo $information_msg;?>
	</div>
<?php } ?>
<?php if(@$success_msg!=''){?>
	<div class="alert alert-success alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-check"></i>Success !</h4>
		<?php echo $success_msg; ?>
	</div>
<?php }?>
<?php if(@$warning_msg!=''){?>
	<div class="alert alert-warning alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-warning"></i>Warning !</h4>
		<?php echo $warning_msg;?>
	</div>
<?php } ?>
<?php if($this->session->flashdata('notification')){?>
	<div class="alert alert-success alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-check"></i>Success !</h4>
		<?php echo $this->session->flashdata('notification');?>
	</div>
<?php }

if($this->session->flashdata('warning')){?>
	<div class="alert alert-warning alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-warning"></i>Warning !</h4>
		<?php echo $this->session->flashdata('warning');?>
	</div>
<?php }?>
<?php if($this->session->flashdata('error')){?>
	<div class="alert alert-danger alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-ban"></i>Error !</h4>
		<?php echo $this->session->flashdata('error');?>
	</div>
<?php } ?>
<?php
if(!validation_errors()){
	if(@$csrf_error!=''){?>
		<div class="alert alert-danger alert-dismissible">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<h4><i class="icon fa fa-ban"></i>Error !</h4>
			<?php echo $csrf_error;?>
		</div>
	<?php }
}?>
<?php
if(validation_errors()){ ?>
	<div class="alert alert-danger alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-ban"></i>Following error(s) need your attention:</h4>
		<?php echo validation_errors(); ?>
	</div>
	<?php
}
if(@$upload_error['error']!='') { ?>
	<div class="alert alert-danger alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h4><i class="icon fa fa-ban"></i>Following error(s) need your attention:</h4>
		<?php echo $upload_error['error']; ?>
	</div>
<?php } ?>
