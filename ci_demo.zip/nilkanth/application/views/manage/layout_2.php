<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $title; ?> | <?php echo @$this->sm->ss->site_name; ?></title>
    <link rel="icon" href="<?php echo site_url('themes/manage/images/icons/favicon.ico');?>" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?php echo site_url('themes/manage/css/bootstrap.min.css'); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo site_url('themes/manage/css/AdminLTE.min.css'); ?>">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
        folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo site_url('themes/manage/css/skins/_all-skins.min.css'); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo site_url('themes/manage/plugins/iCheck/square/blue.css'); ?>">
    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo site_url('themes/manage/css/custom.css'); ?>">


    <script type="text/javascript" src="<?php echo site_url()."themes/manage/plugins/jQuery/jquery-2.2.3.min.js" ?>"></script>
    <script type="text/javascript" src="<?php echo site_url()."themes/manage/js/bootstrap.min.js" ?>"></script>
    <script type="text/javascript" src="<?php echo site_url()."themes/manage/plugins/fastclick/fastclick.js" ?>"></script>
    <script type="text/javascript" src="<?php echo site_url()."themes/manage/plugins/iCheck/icheck.min.js" ?>"></script>
    <script type="text/javascript" src="<?php echo site_url()."themes/manage/js/validate.min.js" ?>"></script>
    <script type="text/javascript" src="<?php echo site_url()."themes/manage/js/validate_init.js" ?>"></script>
    <script type="text/javascript">
        window.onload = function() {
            var txtBox = document.getElementById("email");
            if (txtBox != null) {
                txtBox.focus();
            }
        };
    </script>
    <?php /*addTopJs(); */?>
</head>

<body class="hold-transition login-page">
<?php include_once('includes/js_messages.php');?>
<noscript><div class="msg"><div class="msg-warning"><p><?php echo $this->lang->line('error_javascript'); ?></p></div></div></noscript>
<div class="login-box">
    <div class="login-logo">
        <a href="<?php echo site_url('login'); ?>"><b>NILKANTH</b><br>STONE CRUSHER</a>
    </div>
    <!-- /.login-logo -->
        <?php echo $content_section;?>
    <!-- /.login-box-body -->
</div>

<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' // optional
        });
    });
</script>
</body>
</html>