<section class="content">
    <div class="error-page">
        <h2 class="headline text-yellow" style="margin-top: -20px;">404</h2>
        <div class="error-content">
            <h3><i class="fa fa-warning text-yellow"></i> Data Not Found.</h3>
            <p>
                Data not found in this page.<br/>
                Meanwhile, you may <a href="<?php echo site_url('manage/home');?>">return to dashboard</a>.
            </p>

        </div>
        <!-- /.error-content -->
    </div>
    <!-- /.error-page -->
</section>