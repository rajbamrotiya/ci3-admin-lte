<section class="content">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 table-responsive">
            <div class="box box-primary">
                <div class="box-body">
                    <form  id="setting_form" action="<?php echo $action; ?>" method="post" class="form-horizontal">
                        <!--form sub header-->
                        <div class="box-header form-sub-header">
                            <h3 class="box-title">Setting Detail :</h3>
                        </div>
                        <!-- ./form sub header-->
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo $this->lang->line('title'); ?></label>
                            <div class="col-sm-5">
                                <input type="text" name="title" id="title" class="validate[required] form-control <?php if(form_error('value'))echo 'err_red';?>" value="<?php echo set_value('title',$this->form_data->title);?>"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo $this->lang->line('key'); ?></label>
                            <div class="col-sm-5">
                                <input type="text" name="keytext"  <?php if($add=='Yes'): echo " "; else: echo "readonly"; endif;?> class=" form-control validate[required] keyText <?php if(form_error('value'))echo 'err_red';?>" value="<?php echo set_value('keytext',$this->form_data->keytext);?>"/>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo $this->lang->line('setting_type'); ?></label>
                            <div class="col-sm-5">
                                <select name="setting_type"  class="form-control">
                                    <option <?php if(set_value('setting_type',$this->form_data->setting_type)=="General") echo "selected"; ?> value="<?php echo $this->lang->line('general');  ?>"><?php echo $this->lang->line('general');  ?></option>
                                    <option <?php if(set_value('setting_type',$this->form_data->setting_type)=="Social_Seo") echo "selected"; ?> value="<?php echo $this->lang->line('socialseo');  ?>"><?php echo $this->lang->line('socialseo');  ?></option>
                                    <option <?php if(set_value('setting_type',$this->form_data->setting_type)=="Email") echo "selected"; ?> value="<?php echo $this->lang->line('email');  ?>"><?php echo $this->lang->line('mail_setting');  ?></option>
                                    <option <?php if(set_value('setting_type',$this->form_data->setting_type)=="Other") echo "selected"; ?> value="<?php echo $this->lang->line('other');  ?>"><?php echo $this->lang->line('other_setting');  ?></option>
                                </select>
                            </div>
                        </div>
                        <?php if(@$field->Id=='12' || @$field->Id=='36') {?>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Value</label>
                                <div class="col-sm-5"> <textarea class="form-control <?php if(form_error('value'))echo 'err_red';?>" name="value" ><?php echo set_value('value',$this->form_data->value);?></textarea></div>
                            </div>
                            <?php
                        }
                        else{ ?>
                            <div class="form-group">
                                <label class="col-sm-2 control-label"><?php echo $this->lang->line('value'); ?></label>
                                <div class="col-sm-5">
                                    <input type="text" name="value" class="form-control <?php if(form_error('value'))echo 'err_red';?>" value="<?php echo set_value('value',$this->form_data->value);?>"/>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-5">
                                <input type="submit" class="btn btn-success" value="<?php echo $this->lang->line('submit');?>" name="submit" id="submit" />
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
</section>