<section class="content">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="box box-primary">
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped table-responsive">
                        <thead>
                        <tr>
                            <th width="1%">#</th>
                            <th class="no-sort roundimg-col"></th>
                            <th><?php echo $this->lang->line('name'); ?></th>
                            <th><?php echo $this->lang->line('email'); ?></th>
                            <th class="no-sort"><?php echo $this->lang->line('admin_type'); ?></th>
                            <th class="tcenter no-sort"><?php echo $this->lang->line('status'); ?></th>
                            <th class="tcenter no-sort"><?php echo $this->lang->line('action'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if(empty($list_records))
                        { ?>
                            <tr class="data">
                                <td colspan="7" align="center"><?php echo $this->lang->line('no_rec_found'); ?></td>
                            </tr>
                            <?php
                        }
                        else
                        {
                            $i=1;
                            foreach($list_records as $row){ ?>
                                <tr class="data <?php echo $i%2==0 ? "alter" : ""; ?>" id="data-<?php echo $row->Id; ?>">
                                    <td><?php echo ++$j;?></td>
                                    <td class="team-logo roundimg">
                                        <img src="<?php echo check_image($row->Photo,'uploads/admin'); ?>" />
                                    </td>
                                    <td><?php echo $this->cm->filterOutput($row->Name); ?> </td>
                                    <td><a class="permlink" href="mailto:<?php echo $row->Email; ?>"><?php echo $this->cm->filterOutput($row->Email); ?></a></td>
                                    <td>
                                        <?php if($row->UserType == 'SuperAdmin') { echo 'Super Admin'; } else { echo'Sub Admin'; } ?>
                                    </td>
                                    <td class="tcenter">
                                        <?php if($row->UserType != 'SuperAdmin') { ?>
                                            <div class="switch <?php echo $row->Status=="Enable" ? "on" :""; ?>">
                                                <div class="knob"></div>
                                            </div>
                                        <?php } ?>
                                    </td>
                                    <td class="action tcenter three">
                                        <a href="<?php echo $info_link.$row->Id?>" title="<?php echo $this->lang->line('view_detail'); ?>"><span class="fa fa-eye"></span></a>
                                        <a href="<?php echo $edit_link.$row->Id?>" title="<?php echo $this->lang->line('edit'); ?>"><span class="fa fa-edit"></span></a>
                                        <?php if($row->UserType!='SuperAdmin') { ?>
                                            <a href="javascript:" class="delete"
                                               title="<?php echo $this->lang->line('delete'); ?>"><span
                                                        class="fa fa-trash"></span></a>
                                        <?php } ?>
                                    </td>
                                </tr>
                                <?php $i++; }
                        } ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <input type="hidden" id="hdn" value="<?php echo $this->cm->Encryption($tbl); ?>" />
</section>