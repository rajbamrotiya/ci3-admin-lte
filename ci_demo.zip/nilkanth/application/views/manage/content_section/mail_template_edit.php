<section class="content">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 table-responsive">
            <div class="box box-primary">
                <div class="box-body">

                    <form enctype="multipart/form-data" id="<?php  echo $method=="Edit" ? "mailsetting_form1" : "mailsetting_form"; ?>" action="<?php echo $action; ?>" method="post" class="form-horizontal">
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo $this->lang->line('title'); ?></label>
                            <div class="col-sm-5"><input class="form-control" type="text" name="title" id="title" value="<?php echo set_value('title',$this->form_data->title);?>"/></div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo $this->lang->line('from_email'); ?></label>
                            <div class="col-sm-5"><input class="form-control" type="text" name="email" id="email" value="<?php echo set_value('email',$this->form_data->email);?>"/></div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo $this->lang->line('from_text'); ?></label>
                            <div class="col-sm-5"><input class="form-control" type="text" name="from_text" id="from_text" value="<?php echo set_value('from_text',$this->form_data->from_text);?>"/></div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo $this->lang->line('subject'); ?></label>
                            <div class="col-sm-5"><input class="form-control" type="text" name="subject" id="subject" value="<?php echo set_value('subject',$this->form_data->subject);?>"/></div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo 'Slug'; ?></label>
                            <div class="col-sm-5"><input class="form-control" type="text" name="slug" id="slug" <?php if($this->form_data->slug !=''){echo readonly;} ?> value="<?php echo set_value('slug',$this->form_data->slug);?>"/></div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label"><?php echo $this->lang->line('mail_content'); ?></label>
                            <div class="col-sm-9">

								            <textarea id="editor1" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"  name="page_content"><?php echo set_value('page_content',$this->form_data->page_content);?>
								            </textarea>

                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>


                        
                    </form>
                    <input type="hidden" id="hdn" value="<?php echo $this->cm->Encryption($tbl); ?>" />
                    <?php if($hdn_id!=''){ ?>
                        <input type="hidden" id="hdn_id" value="<?php echo $hdn_id; ?>" />
                    <?php } ?>

                </div>
            </div>
        </div>
    </div>
</section>
<script>
    var PAGA_TEMPLATE = 'MAIL_TEMPLATE_EDIT';
</script>