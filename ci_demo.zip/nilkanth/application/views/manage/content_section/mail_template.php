<section class="content">

    <!--<input type="hidden" name="csrf_name" id="csrf_name" value="<?php /*echo htmlspecialchars($unique_form_name);*/?>"/>
    <input type="hidden" name="csrf_token" id="csrf_token" value="<?php /*echo htmlspecialchars($token);*/?>"/>-->

    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">

                        <thead>
                        <tr>
                            <th width="2%">#</th>
                            <th><?php echo $this->lang->line('title'); ?></th>
                            <th class="tcenter no-sort"><?php echo $this->lang->line('action'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if(empty($list_records))
                        { ?>
                            <tr class="data">
                                <td colspan="4" align="center"><?php echo $this->lang->line('no_rec_found'); ?></td>
                            </tr>
                            <?php
                        }
                        else
                        {
                            $i=1;
                            foreach($list_records as $row){ ?>
                                <tr class="data <?php echo $i%2==0 ? "alter" : ""; ?>" id="data-<?php echo $row->Id; ?>">
                                    <td><?php echo ++$j;?></td>
                                    <td><?php echo $this->cm->filterOutput($row->Title); ?></td>

                                    <td class="action tcenter">
                                        <a href="<?php echo $edit_link.$row->Id?>" title="<?php echo $this->lang->line('edit'); ?>"><span class="fa fa-edit"></span></a>

                                    </td>
                                </tr>
                                <?php $i++; }
                        } ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
    <input type="hidden" id="hdn" value="<?php echo $this->cm->Encryption($tbl); ?>" />

</section>