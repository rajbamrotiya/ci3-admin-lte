<div class="login-box-body">
    <p class="login-box-msg">Sign in to continue</p>
    <?php echo @$display_msg; ?>
    <form autocomplete="off" method="post" id="login_form" action="<?php echo site_url('login/check'); ?>">
        <input type="hidden" name="target_url" value="<?= @$target; ?>">
        <div class="form-group has-feedback">
            <input type="email" name="email" id="email" class="form-control" placeholder="Email"
                   value="<?php echo $this->input->post('email'); ?>">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        </div>
        <div class="form-group has-feedback">
            <input type="password" name="password" id="password" class="form-control" placeholder="Password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        </div>
        <div class="row">
            <div class="col-xs-8">
                <div class="checkbox icheck">
                    <label>
                        <input type="checkbox" class="check_right" name="check_right"> Remember Me
                    </label>
                </div>
            </div>
            <!-- /.col -->
            <div class="col-xs-4">
                <input type="submit" name="submit" id="submit" class="btn btn-primary btn-block btn-flat"
                       value="<?php echo $this->lang->line('login'); ?>"/>
            </div>
            <!-- /.col -->
        </div>
    </form>

    <a href="<?php echo site_url('forgot'); ?>" title="<?php echo $this->lang->line('forgot_password'); ?>">
        <?php echo $this->lang->line('forgot_password'); ?>?</a><br>

</div>