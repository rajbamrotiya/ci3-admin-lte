<section class="content">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="box box-primary">
                <div class="box-body">
                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                            <li class="<?php if($_GET['section']=='General' || $_GET['section']=='') echo "active";?>" ><a  data-toggle="tabs" href="<?php echo $link_info;?>?section=General" ><?php echo $this->lang->line('general');  ?></a></li>
                            <li class="<?php if($_GET['section']=='Social_Seo') echo "active";?>"><a data-toggle="tabs" href="<?php echo $link_info;?>?section=Social_Seo"><?php echo $this->lang->line('socialseo');  ?></a></li>
                            <li class="<?php if($_GET['section']=='Email') echo "active";?>"><a data-toggle="tabs" href="<?php echo $link_info;?>?section=Email"  ><?php echo $this->lang->line('mail_setting');  ?></a></li>
                            <li class="<?php if($_GET['section']=='Other') echo "active";?>"><a data-toggle="tabs" href="<?php echo $link_info;?>?section=Other"  ><?php echo $this->lang->line('other_setting');  ?></a></li>
                        </ul>
                    </div>

                    <table width="100%" cellpadding="0" cellspacing="0" border="0" id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th width="1%">#</th>
                            <th><?php echo $this->lang->line('title'); ?></th>
                            <th><?php echo $this->lang->line('key'); ?></th>
                            <th><?php echo $this->lang->line('value'); ?></th>
                            <th class="tcenter no-sort"><?php echo $this->lang->line('action'); ?></th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php
                        if(empty($list_records))
                        { ?>
                            <tr class="data">
                                <td colspan="6" align="center"><?php echo $this->lang->line('no_rec_found'); ?></td>
                            </tr>
                            <?php
                        }
                        else
                        {
                            $i=1;
                            foreach (@$list_records as $row):?>
                                <tr <?php if($i%2==0):?>class="alter"<?php endif;?>>
                                    <td><?php echo ++$j;?></td>
                                    <td><?php echo $this->cm->filterOutput($row->Fieldname);?></td>
                                    <td ><?php echo $this->cm->filterOutput($row->Keytext);?></td>
                                    <td ><?php echo $this->cm->filterOutput($row->Value);?></td>
                                    <td class="action tcenter">
                                        <a href="<?php echo $edit_link.$row->Id;?>"  title="Edit" class="tool-tip"><span class="fa fa-edit"></span></a>
                                    </td>
                                </tr>
                                <?php $i++;endforeach;
                        }?>
                        </tbody>
                    </table>
                    <!--<div class="pagination-wrapper">
									<ul class="pagination">
										<?php /*echo $pagination; */?>
									</ul>
								</div>-->
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->

    <input type="hidden" id="hdn" value="<?php echo $this->cm->Encryption($tbl); ?>" />
</section>