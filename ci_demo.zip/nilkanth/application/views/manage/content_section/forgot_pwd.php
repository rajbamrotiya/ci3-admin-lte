<div class="login-box-body">
    <p class="login-box-msg">Your Email Id is required to Reset Password</p>
    <?php include_once(APPPATH.'views/manage/includes/display_msg.php');?>
    <form autocomplete="off" method="post" id="forgot_form"  action="<?php echo site_url('forgot/check');?>">
        <div class="form-group has-feedback">
            <input type="email" name="forgot_email" id="email" class="form-control" placeholder="Email" value="<?php echo set_value('forgot_email',$this->form_data->forgot_email); ?>">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        </div>

        <div class="row">
            <div class="col-xs-8">
                <a href="<?php echo site_url('login');?>" title="<?php echo $this->lang->line('login_text'); ?>">
                    <?php echo $this->lang->line('login_text'); ?></a>
            </div>
            <!-- /.col -->
            <div class="col-xs-4">
                <input type="submit" name="submit" id="submit"  class="btn btn-primary btn-block btn-flat" value="<?php echo $this->lang->line('send'); ?>" />
            </div>
            <!-- /.col -->
        </div>
    </form>

    <br>

</div>