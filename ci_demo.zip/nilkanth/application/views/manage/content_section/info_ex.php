<section class="content">
    <div class="row">
        <div class="col-md-3">
            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">

                    <img class="profile-user-img img-responsive img-circle" src="<?php echo check_image($company_info->CompanyImage,'uploads/company','big'); ?>" alt="Firm Logo"/>

                    <h3 class="profile-username text-center">
                        <?php echo ucfirst($this->cm->filterOutput($company_info->CompanyName)); ?>
                    </h3>
                    <?php if(is_accessible('company','edit',$accessible_company_id,$company_info->Id)){ ?>
                        <p class="text-center"><a href="<?php echo site_url('manage/company/edit/'.$company_info->Id)?>"><i class="fa fa-fw fa-edit"></i>Edit</a></p>
                    <?php } ?>
                    <ul class="list-group list-group-unbordered">
                        <li class="list-group-item">
                            <b>Company Staff</b> <a class="pull-right"><?php echo $company_staff; ?></a>
                        </li>
                        <?php if(is_accessible('company_staff','add')){ ?>
                            <li class="list-group-item">

                                <a href="<?php echo site_url('manage/company_staff/add/'.$company_info->Id);?>" ><i class="fa fa-fw fa-plus-circle"></i>ADD Company Staff</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

            <!-- About Me Box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">About <?php echo ucfirst($this->cm->filterOutput($company_info->CompanyName)); ?></h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <strong><i class="fa fa-briefcase margin-r-5"></i> RE Firm</strong>
                    <p class="text-muted"><a href="<?php echo site_url('manage/re_firm/information/'.$company_info->Firm_id); ?>"><?php echo $this->cm->filterOutput($company_info->FirmName); ?></a></p>
                    <strong><i class="fa fa-user margin-r-5"></i> Contact Person</strong>
                    <p class="text-muted"><?php echo $this->cm->filterOutput($company_info->ContactName1); ?></p>
                    <p class="text-muted"><?php echo $this->cm->filterOutput($company_info->ContactName2); ?></p>
                    <strong><i class="fa fa-envelope margin-r-5"></i> Contact Email</strong>
                    <p class="text-muted"><a href="mailto:<?php echo $company_info->ContactEmail1; ?>"><?php echo $company_info->ContactEmail1; ?></a></p>
                    <p class="text-muted"><a href="mailto:<?php echo $company_info->ContactEmail2; ?>"><?php echo $company_info->ContactEmail2; ?></a></p>
                    <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
                    <p class="text-muted"><?php echo $this->cm->filterOutput($company_info->CompanyAddress); ?></p>
                    <strong><i class="fa fa-phone margin-r-5"></i> Phone </strong>
                    <p class="text-muted"><?php echo $this->cm->filterOutput($company_info->ContactPhone1); ?></p>
                    <p class="text-muted"><?php echo $this->cm->filterOutput($company_info->ContactPhone2); ?></p>
                    <strong><i class="fa fa-file-text-o margin-r-5"></i> Other Information</strong>
                    <p class="text-muted"><?php echo $this->cm->filterOutput($company_info->OtherDetail); ?></p>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

            <!-- Business Risk/Threats Box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Business Risk/Threats</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <strong>Competition :</strong>
                    <p class="text-muted"><?php echo $cmp_business_risk_threats[$company_info->Competition]; ?></p>
                    <strong>Economy :</strong>
                    <p class="text-muted"><?php echo $cmp_business_risk_threats[$company_info->Economy]; ?></p>
                    <strong>Government Regulation :</strong>
                    <p class="text-muted"><?php echo $cmp_business_risk_threats[$company_info->GovernmentRegulation]; ?></p>
                    <strong>Technology :</strong>
                    <p class="text-muted"><?php echo $cmp_business_risk_threats[$company_info->Technology]; ?></p>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#TabForRecords1" data-toggle="tab">Tab For Records 1</a></li>
                    <li><a href="#TabForRecords2" data-toggle="tab">Tab For Records 2</a></li>
                </ul>

                <div class="tab-content scroll">

                    <div class="active tab-pane custom-tabs" id="TabForRecords1">
                        <?php if(empty($records1)) { ?>
                            <div class="post">
                                <div class="user-block">
                                    <p><?php echo "No Record Found"; ?></p>
                                </div>
                            </div>
                        <?php }
                        else
                        {
                            foreach ($records1 as $key) {  ?>
                                <div class="post">
                                    <div class="user-block">
                                        <img class="img-circle img-bordered-sm" src="<?php echo check_image($key->Photo,'uploads/admin','big'); ?>" alt="RE Advisor"/>
                                        <span class="username">
	                                                <a href="<?php echo site_url('manage/company_admin/information/'.$key->Id);?>"><?php echo ucfirst($this->cm->filterOutput($key->Name)); ?></a>
                                                    <small>[<?php echo ucfirst($key->Email); ?>]</small>
	                                            </span>
                                        <span class="description"><?php if($key->LastLoginDate == 0){echo "Not Yet Logged In";}else{echo "Last Seen On ".date('d M Y', strtotime($key->LastLoginDate));} ?></span>
                                    </div>
                                    <!-- /.user-block -->
                                    <p class="info_style"><?php echo $this->cm->filterOutput($key->OtherInfo); ?></p>

                                </div>
                            <?php }
                        } ?>
                        <!-- /.post -->
                    </div>
                    <!-- /.tab-pane -->

                    <div class="tab-pane custom-tabs" id="TabForRecords2">
                        <?php if(empty($records2)) { ?>
                            <div class="post">
                                <div class="user-block">
                                    <p><?php echo "No Record Found"; ?></p>
                                </div>
                            </div>
                        <?php }
                        else
                        {
                            foreach ($records2 as $key) { ?>
                                <div class="post">
                                    <div class="user-block">
                                        <img class="img-circle img-bordered-sm" src="<?php echo check_image($key->Photo,'uploads/admin','big'); ?>" alt="RE Advisor"/>
                                        <span class="username">
	                                                <a href="<?php echo site_url('manage/company_staff/information/'.$key->Id);?>"><?php echo ucfirst($this->cm->filterOutput($key->Name)); ?></a>
                                                    <small>[<?php echo ucfirst($key->Email); ?>]</small>
	                                            </span>
                                        <span class="description"><?php if($key->LastLoginDate == 0){echo "Not Yet Logged In";}else{echo "Last Seen On ".date('d M Y', strtotime($key->LastLoginDate));} ?></span>
                                    </div>
                                    <!-- /.user-block -->
                                    <p class="info_style"><?php echo $this->cm->filterOutput($key->OtherInfo); ?></p>

                                </div>
                            <?php }
                        } ?>
                        <!-- /.post -->
                    </div>
                    <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

</section>