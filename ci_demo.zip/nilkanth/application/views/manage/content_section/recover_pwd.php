<div class="login-box-body">
    <span class="recover_label" style="width: 100%; display: block; text-align: center; padding: 20px 0 20px; color: #666; font-weight: 700;"><?php echo 'Recover Password';?></span>
    <?php include_once(APPPATH.'views/manage/includes/display_msg.php');?>
    <form autocomplete="off" method="post" id="recover_form"  action="<?php echo $action; ?>">
        <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="New Password" name="recover_pass" id="recover_pass" value="<?php echo set_value('recover_pass',$this->form_data->recover_pass); ?>" />

        </div>
        <div class="form-group has-feedback">
            <input type="password" class="form-control" name="conf_recover_pass" placeholder="Confirm New Password" id="conf_recover_pass" value="<?php echo set_value('conf_recover_pass',$this->form_data->conf_recover_pass); ?>" />

        </div>
        <div class="row">
            <div class="col-xs-8">

            </div>
            <!-- /.col -->
            <div class="col-xs-4">
                <input type="submit" name="submit" id="submit"  class="btn btn-primary btn-block btn-flat" value="<?php echo $this->lang->line('submit'); ?>" /><br/>
                <a href="<?php echo site_url('manage/login');?>" title="<?php echo $this->lang->line('login'); ?>"><?php echo $this->lang->line('login'); ?></a>
            </div>
            <!-- /.col -->
        </div>
        <input type="hidden" name="csrf_name" value="<?php echo htmlspecialchars($unique_form_name);?>"/>
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($token);?>"/>
    </form>

</div>