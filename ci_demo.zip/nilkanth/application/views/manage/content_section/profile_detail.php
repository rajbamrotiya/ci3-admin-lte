<section class="content">
    <div class="row">
        <!-- About Me Box -->
        <div class="col-md-6">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">About <?php echo ucfirst($this->cm->filterOutput($result->Name)); ?></h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-4">
                            <img class="profile-user-img img-responsive img-circle" src="<?php echo check_image($result->Photo,'uploads/admin','big'); ?>" alt="Firm Logo"/>

                            <h3 class="profile-username text-center"><?php echo ucfirst($this->cm->filterOutput($result->Name)); ?></h3>
                            <p class="text-center margin">
                                    <a href="<?php echo site_url('profile/edit'); ?>"><i class="fa fa-fw fa-edit"></i>Edit</a>
                            </p>
                        </div>
                        <div class="col-md-8">
                            <strong><i class="fa fa-envelope margin-r-5"></i> Email Address</strong>
                            <p><a href="mailto:<?php echo html_escape($result->Email); ?>"><?php echo $result->Email; ?></a></p>
                            <strong><i class="fa fa-user margin-r-5"></i>User Type</strong>
                            <p class="text-muted"><?php echo $roles_key_value[$result->UserType]; ?></p>
                            <strong><i class="fa fa-phone margin-r-5"></i> Phone </strong>
                            <p class="text-muted"><?php echo $this->cm->filterOutput($result->Phone_no); ?></p>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.row -->

</section>