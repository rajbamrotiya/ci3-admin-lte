<section class="content">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 table-responsive">
            <div class="box box-primary">
                <div class="box-body">
                    <form class="form-horizontal" id="<?php  echo $method=="Edit" ? "admin_form1" : "admin_form"; ?>" enctype="multipart/form-data" action="<?php echo $action; ?>" method="post">
                        <!--form sub header-->
                        <div class="box-header form-sub-header">
                            <h3 class="box-title">Admin Information :</h3>
                        </div>
                        <!-- ./form sub header-->
                        <div class="form-group">
                            <label for="inputName" class="col-sm-2 control-label">Name<i class="text-danger">*</i></label>

                            <div class="col-sm-5">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo set_value('name',$this->form_data->name);?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputName" class="col-sm-2 control-label"><?php echo 'Phone'; ?></label>

                            <div class="col-sm-5">
                                <input type="text" class="form-control" name="contact" id="contact" value="<?php echo set_value('contact',$this->form_data->contact);?>"  class = "" placeholder="Number">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputSkills" class="col-sm-2 control-label"><?php echo $this->lang->line('display_photo'); ?></label>
                            <div class="col-sm-5">
                                <div class="input-group col-xs-12">
                                    <input type="hidden" name="image" id="image" value="<?php echo set_value('image',$this->form_data->image);?>">
                                    <input type="file" name="file" id="file" class="file-input">
                                    <span class="input-group-addon file-input-img-span">
												<img src="<?php echo check_image(set_value('image',$this->form_data->image),'uploads/admin'); ?>" height="30px">
											</span>
                                    <input type="text" class="form-control" disabled placeholder="Upload Image" value="<?php echo set_value('image',$this->form_data->image); ?>">
                                    <span class="input-group-btn">
												<button class="file-input-browse btn btn-primary" type="button"><i class="glyphicon glyphicon-search"></i> Browse</button>
											</span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputName" class="col-sm-2 control-label"><?php echo $this->lang->line('admin_type'); ?></label>

                            <div class="col-sm-5">
                                <select name="admin_type"  class="form-control">
                                    <option <?php if(set_value('admin_type',$this->form_data->admin_type)=="SuperAdmin") echo "selected"; ?> value="SuperAdmin"><?php echo 'Super Admin';  ?></option>
                                    <option <?php if(set_value('admin_type',$this->form_data->admin_type)=="SubAdmin") echo "selected"; ?> value="SubAdmin"><?php echo 'Sub Admin';  ?></option>
                                </select>
                            </div>
                        </div>

                        <!--form sub header-->
                        <div class="box-header form-sub-header">
                            <h3 class="box-title">Login Information :</h3>
                        </div>
                        <!-- ./form sub header-->
                        <div class="form-group">
                            <label for="inputEmail" class="col-sm-2 control-label">Email<i class="text-danger">*</i></label>
                            <div class="col-sm-5">
                                <input type="email" class="form-control" placeholder="Email" name="email" id="email" <?php if($this->session->userdata('adminid') == $Edit_id) echo 'readonly'; ?>  value="<?php echo set_value('email',$this->form_data->email);?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputName" class="col-sm-2 control-label"><?php echo $this->lang->line('password'); ?><i class="text-danger">*</i></label>

                            <div class="col-sm-5">
                                <input class="form-control" type="password" name="password" id="password" placeholder="password">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputName" class="col-sm-2 control-label"><?php echo $this->lang->line('cnf_password'); ?><i class="text-danger">*</i></label>

                            <div class="col-sm-5">
                                <input class="form-control" type="password" name="confirm_password" id="confirm_password" placeholder="confirm password">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>