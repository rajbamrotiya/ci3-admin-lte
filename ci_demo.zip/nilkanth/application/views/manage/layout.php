<?php
/**
 * Created by PhpStorm.
 * User: Rajesh Bamroteeya
 * Date: 1/12/16
 * Time: 5:21 PM
 */
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $title; ?> | <?php echo @$this->sm->ss->site_name; ?></title>
    <link rel="icon" href="<?php echo site_url('themes/manage/images/icons/favicon.ico'); ?>"/>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php
    /*common js msg define file  */
    include_once('includes/js_messages.php');
    /* This function add the header js and footer which is define in controller via function and some common js  */
    echo put_headers();
    ?>
</head>
<body class="hold-transition sidebar-mini skin-blue sidebar-collapse">
<div class="wrapper">

    <?php include_once('includes/header.php'); ?>
    <!-- Left side column. contains the logo and sidebar -->
    <?php include_once ('includes/left_sidebar.php'); ?>

    <div class="content-wrapper">
        <section class="content-header">
            <div class="row">
                <?php if (@$sub_module == '') { ?>
                    <div class="col-md-6 col-sm-6 col-xs-6">
                        <h3><?php echo $main_module; ?></h3>
                        <ol class="breadcrumb">
                            <li><a href="<?php echo site_url('manage/home'); ?>"><i class="fa fa-dashboard"></i>Dashboard</a>
                            </li>
                            <li class="active"><?php echo $main_module; ?></li>
                        </ol>
                    </div>
                    <?php if ($main_module != 'Dashboard' && $main_module != 'Profile') { ?>
                        <div class="col-md-6 col-sm-6 col-xs-6">
                            <a href="<?php echo $link_add; ?>" class="a_link"><i
                                        class="fa fa-fw fa-plus-circle"></i><?php echo lang('add_new_lbl'); ?></a>
                        </div>
                    <?php } ?>
                <?php } else { ?>
                    <div class="col-md-6 col-sm-6 col-xs-6">
                        <h3><?php echo $sub_module; ?>
                            <small><?php echo $main_module; ?></small>
                        </h3>
                        <ol class="breadcrumb">
                            <li><a href="<?php echo site_url('manage/home'); ?>"><i class="fa fa-dashboard"></i>Dashboard</a>
                            </li>
                            <li><a href="<?php echo $module_base_url; ?>"><?php echo $main_module; ?></a></li>
                            <li class="active"><?php echo $sub_module; ?></li>
                        </ol>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-6">
                        <a href="<?php echo $link_back; ?>" class="a_back"><i
                                    class="fa fa-fw fa-arrow-circle-left"></i><?php echo lang('back_link_lbl'); ?></a>
                    </div>
                <?php } ?>

            </div>
        </section>

        <?php include_once('includes/global_alert.php');?>

        <?php echo $content_section; ?>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include_once('includes/footer.php'); ?>

    <!-- Control Sidebar -->
    <?php include_once('includes/control_sidebar.php'); ?>
    <!-- /.control-sidebar -->

</div>

<!-- ./wrapper -->
<?php echo put_footer(); ?>

<script>
    $(document).ready(function () {
        $.fn.dataTable.ext.errMode = 'none';
        oTable = $('#example1').DataTable({
            "lengthChange": true,
            "order": [],
            "columnDefs": [{
                "targets": 'no-sort',
                "orderable": false,
            }],
        });
        if (PAGA_TEMPLATE == 'MAIL_TEMPLATE_EDIT') {
            CKEDITOR.replace('editor1', {
                fullPage: true,
                allowedContent: true,
                autoGrow_onStartup: true,
                enterMode: CKEDITOR.ENTER_BR
            });
        }
        $('#example1_filter').html('');
        $('#example1_filter').html($('#CustomSearchBoxDataTable').html());
        $('#example1_filter input').keyup(function () {
            oTable.search($(this).val()).draw();
        });

        $('.datepicker').datepicker({
            autoclose: true,
            format: 'dd/mm/yyyy',
            todayHighlight: true,
        });
    });
</script>

<div class="hidden" id="CustomSearchBoxDataTable">
    <div class="input-group input-group-sm col-xs-12 col-sm-6 pull-right">
        <span class="input-group-addon">
            Search
        </span>
        <input type="search" class="form-control input-sm" placeholder="" aria-controls="example1" style="margin: 0;">
        <span class="input-group-addon">
            <i class="glyphicon glyphicon-search"></i>
        </span>
    </div>
</div>

</body>
</html>