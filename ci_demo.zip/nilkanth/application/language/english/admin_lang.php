<?php
/**
 * Created by PhpStorm.
 * User: raj
 * Date: 13/7/17
 * Time: 10:53 PM
 */
$lang['js_required']= "This field is required.";

$lang['js_email'] = "Invalid email address";

$lang['js_pwmismatch'] = "Password mismatch";

$lang['js_passlength']= " Password should have at least 6 characters.";

$lang['js_passmax']= "Password can not exceed 15 characters.";

$lang['name']= "Name";

$lang['email']= "Email";

$lang['password'] = "Password";

$lang['crt_password'] = "Current Password";

$lang['cnf_password']="Confirm password";

$lang['back'] = "Back";

$lang['submit'] = "Submit";

$lang['display_photo'] = "Display Photo";

$lang['browse_pic'] = "Browse Picture";

$lang['overview'] = "Overview";

$lang['status'] = "Status";

$lang['action'] = "Actions";

$lang['edit'] = "Edit";

$lang['delete'] = "Delete";

$lang['admin'] = "Admin";

$lang['re_firm'] = "RE Firm";

$lang['re_staff'] = "RE Staff";

$lang['re_staffs'] = "RE Staff";

$lang['re_advisor'] = "RE Advisor";

$lang['re_advisors'] = "RE Advisors";

$lang['company_staff'] = "Company Staff";

$lang['company_staffs'] = "Company Staff";

$lang['admins'] = "Admins";

$lang['re_firms'] = "RE Firms";

$lang['add_new'] = "Add New";

$lang['search'] = "Search";

$lang['no_rec_found'] = 'No Records Found';

$lang['gen_succ_added'] = 'Record added successfully!';

$lang['profile_succ_modified'] = 'Your profile updated successfully!';

$lang['gen_succ_modified'] = 'Record modified successfully!';

$lang['maxlengths'] = 'Can not exceed %s characters.';

$lang['minlengths'] = 'Minimum %s characters required.';

$lang['js_numeric'] = 'Must be a number.';

$lang['heading'] = 'Heading';

$lang['permalink'] = 'Permalink';

$lang['title'] = 'Title';

$lang['meta_key'] = 'Meta Keywords ';

$lang['meta_desc'] = 'Meta Description';

$lang['page_content'] = 'Page Content';

$lang['webpages'] = 'Webpages';

$lang['webpage'] = 'Webpage';

$lang['from_text'] = 'From Text';

$lang['subject'] = 'Subject';

$lang['mail_content'] = 'Mail Content';

$lang['mail_settings'] = 'Mail Settings';

$lang['mail_setting'] = 'Mail Setting';

$lang['value'] = 'Value';

$lang['key'] = 'Key';

$lang['setting_type'] = 'Setting Type';

$lang['settings'] = 'Settings';

$lang['home'] = 'Home';

$lang['edit_profile'] = "Edit Profile";

$lang['login'] = "Login";

$lang['forgot_password'] = "Forgot Password?";

$lang['forgot_pwd'] = "Forgot Password";

$lang['forg_password'] = "Forgot Password";

$lang['error_javascript'] = "Sorry, your browser does not support JavaScript!";

$lang['new_password']="New password";

$lang['cnf_new_password']="Confirm New password";

$lang['other_setting']="Other Setting";

$lang['socialseo']="Social SEO";

$lang['general']="General";

$lang['dashboard']="Dashboard";

$lang['modified_by']="Modified By";

$lang['ip_address']="IP Address";

$lang['mod_log']="Modified Log";

$lang['creation_info']="Creation Info";

$lang['view_detail']="View Detail";

$lang['hide_detail'] = "Hide detail";

$lang['assign_agents']="Assign agents for next week";

$lang['email_already_exist'] = "This Email is already in our database, Please enter another Email.";

$lang['profile_upd_success']="Profile updated successfully.";

$lang['less_or_equal'] = "%s must be less or equal to";

$lang['only_positive_allow'] = "%s accepts only positive values.";

$lang['gen_link_expierd'] = 'Link in your mail is expierd,Request Again!';

$lang['gen_alrady_recovered'] = 'It seems you have already recovered your password! or link is expired.';

$lang['gen_succ_recover'] = 'You have successfully recovered your password.';

$lang['gen_succ_change'] = 'You Have Successfully Changed Your Password.';

$lang['err_valid_oldpwd'] = 'Enter valid old password.';

$lang['err_valid_pwd'] = 'Enter correct password.';

$lang['err_acc_suspend'] = 'Account is suspended!';

$lang['err_accnot_exist'] = "Your account no more exist.";

$lang['session_expired'] = 'Something goes wrong. Try to login again!';

$lang['err_acc_deleted'] = 'Account has been Deleted!';

$lang['err_acc_notactive'] = 'Account not activated!';

$lang['err_valid_mail'] = 'No account exists with this email or username.';

$lang['forg_valid_mail'] = 'No account exists with this email address.';

$lang['err_acc_notactive'] = 'Account not activated!';

$lang['err_enter_email_password'] = 'Enter email and password.';

$lang['err_confirm_pass']='The confirm new password field does not match with new password field.';

$lang['frgt_mail_sent'] = 'Password reset instruction is sent to your email address.';

$lang['frgt_mail_failed'] = 'Mail sending failed, please try again later.';

$lang['csrf_error'] = 'Something went wrong. Please try again.';

$lang['no_contet_found'] = "No page content found.";

$lang['invalid_date_format'] = "Invalid date format.";

$lang['postive_only']	 = "Enter positive value for %s.";

$lang['number_only_val']	 = "Only number is allowed for %s.";

$lang['max_pst_length'] ='Maximum 10 length number is allowed for %s.';



//__________________________________ admin meesages ____________________________________



$lang['add_new'] = "Add new";

$lang['action'] = "Action";

$lang['admins'] = "Admins";

$lang['admin_login'] = "Admin Login";

$lang['admin_image'] = "Admin Image";

$lang['adminname'] = "Admin Name";

$lang['admin_succ_added'] = "Admin added successfully!";

$lang['admin_succ_modified'] = "Admin modified successfully!";



$lang['browse_pic'] = "Browse Picture";

$lang['both'] = "Both";





$lang['cnf_password'] = "Confirm Password";

$lang['cnf_new_password'] = " Confirm New Password";

$lang['code'] = "Code";

$lang['confirm'] = "Confirm";

$lang['cmpgndtl'] = "Campaign Detail";

$lang['commune'] = "Commune";

$lang['communes'] = "Communes";

$lang['category'] = "Category";

$lang['categories'] = "Categories";

$lang['cat_name'] = "Category Name";

$lang['cat_succ_added'] = "Category added successfully!";

$lang['cat_succ_modified'] = "Category modified successfully!";

$lang['change_pwd_success'] = "You password  changed successfully.";

$lang['wrong_current_pwd'] = "Wrong current password.";

$lang['delete'] = "Delete";

$lang['display_photo'] = "Display Photo";

$lang['dashboard'] = "Dashboard";

$lang['email'] = "Email";

$lang['edit'] = "Edit";

$lang['edit_profile'] = "Edit Profile";

$lang['error_javascript'] = "Sorry, your browser does not support JavaScript!";

$lang['err_try_again'] = "Error occured try again";

$lang['err_valid_pwd'] = "Enter valid password.";

$lang['err_acc_suspend'] = "Account suspended by admin.";

$lang['err_valid_mail'] = "Enter valid email address.";

$lang['err_acc_delete'] = "Account has been deleted.";

$lang['email_exist'] = "Email already exist, please enter another email.";

$lang['email_login'] = "Email is already login.";

$lang['forgot_password'] = "Forgot Password";

$lang['from_email'] = "From Email";

$lang['from_text'] = "From Text";

$lang['facebook'] = "Facebook";

$lang['full_name'] = "Full Name";

$lang['general'] = "General";

$lang['heading'] = 'Heading';

$lang['home'] = 'Home';

$lang['login'] = "Login";

$lang['logout'] = "Logout";

$lang['key'] = "Key";

$lang['mail_setting'] = "Mail Setting";

$lang['meta_key'] = 'Meta Keywords ';

$lang['meta_desc'] = 'Meta Description';

$lang['no_rec_found'] = "No Records Found";

$lang['name'] = "Name";

$lang['not_found']  = "Page Not Found!!";

$lang['new_password'] = "New Password";

$lang['overview'] = "Overview";

$lang['other_setting'] = "Other Setting";

$lang['other'] = "Other";

$lang['password'] = "Password";

$lang['permalink'] = 'Permalink';

$lang['page_content'] = "Page Content";

$lang['processing'] = "Processing...";

$lang['page_type'] = "Page Type";

$lang['photo_gallery'] = "Photo Gallery";

$lang['photo'] = "Photo";

$lang['photo_succ_added'] = "Photo added successfully!";

$lang['photo_succ_modified'] = "Photo gallery modified successfully!";

$lang['region'] = "Region";

$lang['regions'] = "Regions";

$lang['recover_pwd'] = "Recover Password";

$lang['search'] = "Search";

$lang['status'] = "Status";

$lang['subject'] = "Subject";

$lang['submit'] = "Submit";

$lang['shortname'] = "Short Name";

$lang['socialseo'] = "Social SEO";

$lang['setting_type'] = "Setting Type";

$lang['settings'] = "Settings";

$lang['title'] = "Title";

$lang['users'] = "Users";

$lang['user'] = "User";

$lang['value'] = "Value";

$lang['website'] = "Website";

$lang['webpages'] = "Webpages";

$lang['webpage'] = "Webpage";

$lang['web_succ_added'] = "Webpage added successfully!";

$lang['web_succ_modified'] = "Webpage modified successfully!";

$lang['mail_succ_added'] = "Mailsetting added successfully!";

$lang['mail_succ_modified'] = "Mailsetting modified successfully!";

$lang['mail_send_failed']= "Mail sending failed to user.";

$lang['setting_succ_added'] = "Setting added successfully!";

$lang['setting_succ_modified'] = "Setting modified successfully!";

$lang['vacancies_succ_added'] = "Vacancies added successfully!";

$lang['vacancies_succ_modified'] = "Vacancies modified successfully!";

$lang['acc_create_succ'] = "Your account is created successfully, Please confirm your email to start account.";

$lang['alrdy_conf_succ'] = "Your account is already confirmed. Please login to continue.";

$lang['acc_conf_succ'] = "Your account is confirmed successfully. Please login to continue.";

$lang['acc_not_conf'] = "Please verify your email to access account. We sent you mail with instruction.";

$lang['acc_not_approve'] = "Please wait for admin approval of your account.";

$lang['err_token'] = "Invalid token.";

$lang['err_create_acc'] = "Please Create account then try to login.";

$lang['mail_send_succ'] = "Mail sent successfully!, please check your mail.";

$lang['mail_not_send'] = "Mail not sent.";

$lang['profile_create_success'] = "Profile created successfully!.";

$lang['profile_update_success'] = "Profile updated successfully!.";

$lang['token_exp'] = "It seems your token has been expired or already used.";

$lang['acc_not_confirm'] = "Your account is not confirmed yet, please confirmed first.";

$lang['recover_pass'] = "Reset Password";

$lang['pwd_change_succ'] = "You password  changed successfully.";

$lang['link_exp'] = "Link is expired.";

$lang['pwd_recover_succ'] = "Password has been already recovered.";

$lang['already_logged_in'] = "You are already logged in with email";

$lang['fb_denied'] = "You have denied facebook permission.";

$lang['view_profile'] = "View Profile";

$lang['join_on'] = "JOINED ON";

$lang['inquiry_send'] = "Inquiry has been sent.";

$lang['contact_us'] = "Contact Us";

$lang['send'] = "Send";

$lang['login_text'] = "Got password? Login";

$lang['fname'] = "First Name";

$lang['lname'] = "Last Name";

$lang['admin_type'] = "Admin Type";

$lang['subadmin'] = "Subadmin";

$lang['shift1'] = "Shift1";

$lang['shift2'] = "Shift2";

$lang['sub_admin'] = "Sub Admin";

$lang['shift1_admin'] = "Shift 1 Admin";

$lang['shift2_admin'] = "Shift 2 Admin";

$lang['admin'] = "Admin";

$lang['contact_no'] = "Contact Number";

$lang['company_acc_create_succ'] = "Your account has been created successfully. Please login to access your account basic search features.";

$lang['usertype'] = 'UserType';

$lang['candidates'] = 'Candidates';

$lang['fullname'] = 'Full Name';

$lang['company'] = 'Company';

$lang['company_name'] = 'Company Name';

$lang['phone'] = 'Phone Number';

$lang['course_deleted_sucess'] = 'Course deleted successfully.';

$lang['verify_shift1'] = "Candidate verified for shift-1 successfully.";

$lang['verify_shift2'] = "Candidate verified for shift-2 successfully.";

$lang['verify_shift'] = "Candidate Profile has been approved successfully.";

$lang['mail_send_succ_reject'] = "This profile has been rejected successfully and Mail sent successfully to candidate.";

$lang['mail_send_not_succ_reject'] = "This profile has been rejected successfully and Mail sending failed.";

$lang['company_new'] = 'Company - New';

$lang['company_approve'] = 'Company - Approved';

$lang['update_company_profile'] = "Company Profile updated successfully.";

$lang['company_approved'] = "Company has been approved.";

$lang['package_suc_update'] = "Company Package updated successfully.";

$lang['package_add_succ'] = "Company Package added successfully.";

$lang['request_send_succ'] = "Your request send successfully.";

$lang['invalid_id'] = "You have passed invalide id.";

$lang['contact_request'] = "Contact Request";

$lang['message'] = 'Message';

$lang['news'] = 'News';

$lang['vacancies'] = 'Vacancies';

$lang['vacancy'] = 'Vacancy';

$lang['shortdetail'] = 'Short Description';

$lang['description'] = 'Description';

$lang['news_succ_added'] = 'News added successfully!';

$lang['forgot_password_new'] = 'Password reset instruction has been sent on your email. Please check your mail.';

$lang['change_pwd_success_com'] = 'Password updated successfully, Please login with your new password.';

$lang['captcha'] = 'Captcha';

$lang['captcha_error'] = 'You have entered invalid captcha.';

/*Date : 14 Dec 2016*/
$lang['company_title']= 'Companies';

$lang['add_new_lbl']= 'ADD NEW';

$lang['back_link_lbl']= 'BACK';

$lang['status_not_change_lbl']= "You can't change. ";

$lang['re_firm_status_disable']= "Re firm was disabled.";

$lang['re_firm_status_delete']= "Re firm was deleted.";

$lang['cmp_status_disable']= "Company was disabled.";
?>