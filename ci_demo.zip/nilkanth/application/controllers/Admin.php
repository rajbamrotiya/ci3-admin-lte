<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends MY_Controller {
    function __construct()
	{
		parent::__construct();
        has_permission();
        $this->setData('Admins','admin','users');
	}
	function index()
	{
		$data = $this->common_data;
		$data['list_records']=array();
		$select_value= 'users.*,users.Id as UserId';
		$data['list_records']= $this->cm->get_all_records($data['tbl'],$select_value,array('users.Status !='=>'Delete','users.Id !='=>$this->session->userdata('adminid')),'users.Id DESC')->result();
		
        $this->view($data,'admin');
	}
	function add()
	{
        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'insert';
        $data['sub_module']=  'Add';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['method']=  'Add';


        /*******************************
        ||  Common data for all page ||
         *******************************/
        $this->view($data,'admin_edit');
	}
	function insert()
	{
        $PostArray = $this->input->post();

        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'insert';
        $data['sub_module']=  'Add';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['method']=  'Add';

		$this->_set_rules();
		if($this->form_validation->run() === TRUE)
		{
			if($_FILES['file']['name']!='')
			{
				$config['upload_path'] = './uploads/admin/big';
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$config['max_size']	= '10240';
                $config['encrypt_name'] = TRUE;
				$this->load->library('upload', $config);
				if (!$this->upload->do_upload('file'))
				{	
					$error = array('error' => $this->upload->display_errors());
					$data['upload_error'] = $error;

					/*******************************
                    ||  Common data for all page ||
                     *******************************/
                    $this->view($data,'admin_edit');
					return;
				}
				else
				{
					$file_name = $this->upload->file_name;
					$this->logo = $file_name;
					$this->create_thumb($file_name,60,60);
				}
			}
			$this->ip_date = $this->cm->get_date_ip();
			$this->_salt = $this->cm->create_pwd_salt();
			$this->_password =  hash('sha256', $this->_salt . ( hash('sha256',$this->input->post('password')) ) );
			
			$value_array = array(
								 'Email' => $PostArray['email'],
			                     'Password' => $this->_password ,
								 'Salt' => $this->_salt ,
								 'Name' => $PostArray['name'],
								 'Photo' => $file_name!=''? $file_name :'',
								 'UserType' => $PostArray['admin_type'],
								 'CreatedBy' => $this->session->userdata('adminid'),
								 'CreatedDate'=>$this->ip_date->cur_date,
								 'CreatedIp'=>$this->ip_date->ip,
                                'Phone_no' => $PostArray['contact']
							);
            $id = $this->cm->save('users',$value_array);
			$this->session->set_flashdata('notification',$this->lang->line('admin_succ_added'));
            redirect($this->thisModuleBaseUrl);
			die();
		}
		else
		{

            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'admin_edit');
		}
	}
    function edit($id='')
	{
        if(!is_numeric($id))
            $this->add();

        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'update/'.$id;
        $data['sub_module']=  'Edit';
        $data['method']=  'Edit';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['Edit_id']=  $id;
        $select_val = 'users.*';
        $result = $this->cm->get_all_records('users',$select_val,array('users.Status !='=>'Delete','users.Id'=>$id),'users.Id DESC','')->row();
	    if(!empty($result))
		{
			$this->form_data->id = $id;
			$this->form_data->email = $result->Email;
			$this->form_data->password = $result->Password;
			$this->form_data->name = $result->Name;
			$this->form_data->admin_type = $result->UserType;
			$this->form_data->contact = $result->Phone_no;
			$this->form_data->image = $result->Photo;
            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'admin_edit');
		}
		else
		{
			$this->add();
		}
	}
    function update($id)
    {
        $PostArray = $this->input->post();
        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'update/'.$id;
        $data['sub_module']=  'Edit';
        $data['method']=  'Edit';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['Edit_id']=  $id;
        if($this->input->post('password')!=''){
            $check_pwd = "Yes";
        }
        else {
            $check_pwd = "No";
        }
        $this->_set_rules($id,$check_pwd);

        if($this->form_validation->run() === TRUE)
        {
            if($_FILES['file']['name']!='')
            {
                $config['upload_path'] = './uploads/admin/big';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size']	= '10240';
                $config['encrypt_name'] = TRUE;
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('file'))
                {
                    $error = array('error' => $this->upload->display_errors());
                    $data['upload_error'] = $error;
                    
                    $this->view($data,'admin_edit');
                    return;
                }
                else
                {
                    $file_name = $this->upload->file_name;
                    $this->logo = $file_name;
                    $this->create_thumb($file_name,60,60);
                }
            }
            $this->ip_date = $this->cm->get_date_ip();
            $update_array =  array(
                'Name' => $PostArray['name'],
                'Phone_no'=> $PostArray['contact'],
                'ModifiedDate' => $this->ip_date->cur_date,
                'ModifiedIp'=>$this->ip_date->ip,
                'ModifiedBy'=> $this->session->userdata('adminid'),
            );
            $update_array['Email'] =  $PostArray['email'];
            $update_array['UserType'] = $PostArray['admin_type'];
            if($this->input->post('password')!='')
            {
                $this->_salt = $this->cm->create_pwd_salt();
                $this->_password = hash('sha256',$PostArray['password']);
                $this->_password =  hash('sha256', $this->_salt . $this->_password);
                $update_array['Password'] = $this->_password;
                $update_array['Salt'] = $this->_salt;
            }
            if($file_name!='') {$update_array['Photo'] = $file_name;}
            $this->cm->update('users',$update_array,array('Id'=>$id));
            //Insert Modified log
            $value_array = array(
                'TableId' => $id,
                'TableName' => $this->db->dbprefix('users'),
                'ModifiedBy'=> $this->session->userdata('adminid'),
            );
            $this->cm->insert_modified($value_array);
            //REDIRECT
            $this->session->set_flashdata('notification',$this->lang->line('admin_succ_modified'));
            redirect($this->thisModuleBaseUrl);
            die();
        }
        else
        {

            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'admin_edit');

        }
    }
	function information($id)
	{
		//if id is not numeric load listing 
		if(!is_numeric($id)) 
			redirect($this->thisModuleBaseUrl);
        $data = $this->common_data;
        $data['sub_module']=  'Information';
        $data['method']=  'information';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;

	    $val = 'users.*';
	    $data['result'] = $this->cm->get_all_records('users',$val,array('users.Status !='=>'Delete','users.Id'=>$id),'users.Id DESC','', '','')->row();
	    if(is_numeric($data['result']->Id)){
            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'admin_detail');
        }else{
	        data_not_found();
        }
	}
	// validation rules
	function _set_rules($id='',$check_pwd='Yes')
	{
		$this->form_validation->set_rules('name', $this->lang->line('name'), 'trim|required');
		$this->form_validation->set_rules('contact', $this->lang->line('contact'), 'trim');
		$this->form_validation->set_rules('admin_type', $this->lang->line('admin_type'), 'trim');
        $this->form_validation->set_rules('email',$this->lang->line('email'),'trim|required|valid_email|callback_check_exists['.$id.']');
		if($check_pwd=='Yes')
		{
			$this->form_validation->set_rules('password',$this->lang->line('password'),'required|min_length[6]|max_length[15]');
			$this->form_validation->set_rules('confirm_password',$this->lang->line('cnf_password'),'required|matches[password]');
		}
		else
		{
			$this->form_validation->set_rules('password',$this->lang->line('password'),'min_length[6]|max_length[15]');
			$this->form_validation->set_rules('confirm_password',$this->lang->line('cnf_password'),'');
		}
		$this->form_validation->set_rules('image',$this->lang->line(''),'');
	}
    function check_exists($email, $id='')
    {
        $data['result'] = $this->cm->check_record_exist('users','Id',array('Email'=>$email,'Status !='=>'Delete'));
        if (!empty($data['result']))
        {
            if($id !='' && $id==$data['result']['Id'])
            {
                return TRUE;
            }
            else
            {
                $this->form_validation->set_message('check_exists',$this->lang->line('email_already_exist'));
                return FALSE;
            }
        }
        return TRUE;
    }
	function create_thumb($file,$width=60,$height=60,$folder='thumb')
	 {
		$config['image_library'] = 'gd2';
		$config['source_image'] = './uploads/admin/big/'.$file;	
		$config['create_thumb'] = FALSE;
		$config['maintain_ratio'] = FALSE;
		$config['width'] = $width;
		$config['height'] = $height;
		$config['new_image'] = './uploads/admin/'.$folder.'/'.$file;
		$this->load->library('image_lib', $config);
		$this->image_lib->resize();
		if(!$this->image_lib->resize())
		{
		    /*var_dump($this->image_lib->display_errors());die;
			return false;*/
		}
		else{
            $this->image_lib->clear();
        }
		
	 }
}
