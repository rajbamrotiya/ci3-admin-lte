<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Page_search extends MY_Controller {
    function __construct()
	{
		parent::__construct();
        $this->setData('Pagination & Search','page_search','users');
        $this->limit =5;
	}
	function index($offset=0)
	{
        if(!is_numeric($offset))
        {
            $offset = 0;
        }
		$data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl;
        // For Search data
        $suffix_array = array();
        $like_str = '';
        if($this->input->get('q') != ''){
            $suffix_array['q'] = urldecode($this->input->get('q'));
            $like_str = '( Email LIKE "%'.$suffix_array['q'].'%" OR Name LIKE "%'.$suffix_array['q'].'%" )';
        }
		$data['list_records']=array();
		$select_value= 'users.*,users.Id as UserId';
		$query_return= $this->cm->get_all_records($data['tbl'],$select_value,array('users.Status !='=>'Delete','users.Id !='=>$this->session->userdata('adminid')),'users.Id DESC',$this->limit,$offset,$like_str,'','','','','Yes');
        $data['list_records'] = $query_return['result'];
        $data['total_records'] = $query_return['num_rows'];

        // generate pagination
        $this->load->library('pagination');
        if(count($suffix_array) > 0){
            $config['suffix'] = "?".http_build_query($suffix_array);
        }
        $config['base_url'] = $this->thisModuleBaseUrl.'index';
        $config['total_rows'] = $data['total_records'];
        $config['per_page'] = $this->limit;
        $config['uri_segment'] = 3;
        $config['use_page_numbers'] = false;
        $config['num_links'] = 10;
        //config for bootstrap pagination class integration
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Previous';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['next_tag_disable_open'] = '<li class="disabled">';
        $config['prev_tag_disable_open'] = '<li class="disabled">';
        $config['display_prev_link'] = true;
        $config['display_next_link'] = true;
        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $data['j'] = 0 + $offset;
        $data['offset'] = $offset;
        /*******************************
        ||  Common data for all page ||
         *******************************/
        $this->view($data,'page_search');
		
	}

	function information($id)
	{
		//if id is not numeric load listing
		if(!is_numeric($id))
			redirect($this->thisModuleBaseUrl);
        $data = $this->common_data;
        $data['sub_module']=  'Information';
        $data['method']=  'information';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $object = new stdClass();
        $object->Photo ='';
        $object->Name ='Name';
        $object->Email ='a@a.com';
        $object->LastLoginDate = date("Y/m/d");
        $data['records1'][] = $object;
        $data['records1'][] = $object;
        $data['records1'][] = $object;
        $data['records2'] =array();
        /*******************************
        ||  Common data for all page ||
         *******************************/
        $data['content_section'] = $this->load->view('manage/content_section/info_ex', $data,true);
        $this->load->view('manage/layout', $data);
	}
	// validation rules
}
