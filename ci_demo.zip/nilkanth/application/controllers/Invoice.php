<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Invoice extends MY_Controller
{
    var $view_main_dir = 'invoice';
    var $model;

    function __construct()
    {
        parent::__construct();
        has_permission();
        $this->load->model('invoice_model');
        $this->load->model('seller_model');
        $this->load->model('material_model');
        $this->load->model('invoice_item_model');
        $this->model = $this->invoice_model;
        $this->setData('Invoices', 'invoice', $this->model->table_nm);

        $this->common_data['state_table'] = $this->config->item('state_table');
        $this->common_data['gujarat_state_code'] = $this->config->item('gujarat_state_code');
        $this->common_data['country_table'] = $this->config->item('country_table');
        $this->common_data['bill_status_color_class'] = $this->config->item('bill_status_color_class');
        $this->common_data['bill_status_arr'] = $this->config->item('bill_status_arr');
        $this->common_data['seller_info_link'] = site_url('seller/information').'/';

        $this->common_data['print_link'] = $this->thisModuleBaseUrl.'print/';

    }

    function index()
    {
        $data = $this->common_data;
        $data['list_records'] = $this->model->get_all();
        $this->view($data, $this->view_main_dir . '/index');
    }


    /**
     *
     */
    function add()
    {
        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl . 'insert';
        $data['sub_module'] = 'Add';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;
        $data['method'] = 'Add';
        /* load other model data*/
        $data['seller_model'] = $this->seller_model->get_all('Name ASC');
        $data['material_model'] = $this->material_model->get_all('Name ASC');

        /*******************************
         * ||  Common data for all page ||
         *******************************/
        $this->view($data, $this->view_main_dir . '/edit');
    }

    /**
     *
     */
    function insert()
    {
        $PostArray = $this->input->post();

        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl . 'insert';
        $data['sub_module'] = 'Add';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;
        $data['method'] = 'Add';
        /* load other model data*/
        $data['seller_model'] = $this->seller_model->get_all('Name ASC');
        $data['material_model'] = $this->material_model->get_all('Name ASC');
        $this->_set_rules();
        if ($this->form_validation->run() === TRUE) {

            /*Invoice item*/
            $CgstPre = $this->sm->ss->cgst;
            $SgstPre = $this->sm->ss->sgst;
            $IgstPre = $this->sm->ss->igst;
            $CgstAmount = 0;
            $SgstAmount = 0;
            $IgstAmount = 0;
            $TotalQty = 0;
            $Amount = 0;
            $TotalAmount = 0;

            $invoice_item_value_arrays = array();
            foreach ($PostArray['MaterialId'] as $key => $value){
                if($PostArray['QtyOfMaterial'][$key] != '' || $PostArray['PriceOfUnit'][$key] != ''){
                    $invoice_item_value_array = array(
                        $this->invoice_item_model->InvoiceId=>0,
                        $this->invoice_item_model->MaterialId=>$PostArray['MaterialId'][$key],
                        $this->invoice_item_model->QtyOfMaterial=>round($PostArray['QtyOfMaterial'][$key],3),
                        $this->invoice_item_model->PriceOfUnit=>round($PostArray['PriceOfUnit'][$key],2),
                        $this->invoice_item_model->CgstPre =>$CgstPre,
                        $this->invoice_item_model->SgstPre =>$SgstPre,
                        $this->invoice_item_model->IgstPre =>$IgstPre,
                    );
                    $invoice_item_value_array[$this->invoice_item_model->Amount] = round($invoice_item_value_array[$this->invoice_item_model->QtyOfMaterial] * $invoice_item_value_array[$this->invoice_item_model->PriceOfUnit],2);

                    $invoice_item_value_array[$this->invoice_item_model->CgstAmount] = round(($invoice_item_value_array[$this->invoice_item_model->Amount]*$CgstPre/100),2);

                    $invoice_item_value_array[$this->invoice_item_model->SgstAmount] = round(($invoice_item_value_array[$this->invoice_item_model->Amount]*$SgstPre/100),2);

                    $invoice_item_value_array[$this->invoice_item_model->IgstAmount] = round(($invoice_item_value_array[$this->invoice_item_model->Amount]*$IgstPre/100),2);

                    $invoice_item_value_array[$this->invoice_item_model->TotalAmount]=round(($invoice_item_value_array[$this->invoice_item_model->Amount] + $invoice_item_value_array[$this->invoice_item_model->CgstAmount] + $invoice_item_value_array[$this->invoice_item_model->SgstAmount] + $invoice_item_value_array[$this->invoice_item_model->IgstAmount]),2);

                    $CgstAmount += $invoice_item_value_array[$this->invoice_item_model->CgstAmount];
                    $SgstAmount += $invoice_item_value_array[$this->invoice_item_model->SgstAmount];
                    $IgstAmount += $invoice_item_value_array[$this->invoice_item_model->IgstAmount];
                    $Amount += $invoice_item_value_array[$this->invoice_item_model->Amount];
                    $TotalAmount += $invoice_item_value_array[$this->invoice_item_model->TotalAmount];
                    $TotalQty += $invoice_item_value_array[$this->invoice_item_model->QtyOfMaterial];
                    $invoice_item_value_arrays[] = $invoice_item_value_array;
                }
            }

            $CgstAmount = round($CgstAmount,2);
            $SgstAmount = round($SgstAmount,2);
            $IgstAmount = round($IgstAmount,2);
            $TotalQty = round($TotalQty,3);
            $Amount = round($Amount,2);
            $TotalAmount = round($TotalAmount,2);

            $value_array = array(
                $this->model->SellerId => $PostArray['SellerId'],
                $this->model->InvoiceDate => mysql_date_format($PostArray['InvoiceDate']),

                $this->model->SupplyFromDate => mysql_date_format($PostArray['SupplyFromDate']),
                $this->model->SupplyToDate => mysql_date_format($PostArray['SupplyToDate']),
                $this->model->SupplyPlace => $PostArray['SupplyPlace'],

                $this->model->TransportationMode => $PostArray['TransportationMode'],
                $this->model->VehicleNumber => $PostArray['VehicleNumber'],

                $this->model->Remark => $PostArray['Remark'],

                $this->model->CgstPre => $CgstPre,
                $this->model->CgstAmount => $CgstAmount,
                $this->model->SgstPre => $SgstPre,
                $this->model->SgstAmount => $SgstAmount,
                $this->model->IgstPre => $IgstPre,
                $this->model->IgstAmount => $IgstAmount,

                $this->model->TotalQty => $TotalQty,
                $this->model->Amount => $Amount,
                $this->model->TotalAmount => $TotalAmount,
            );
            $invoice_id = $this->model->insert($value_array);

            //Invoice_id generate
            $this->model->update($invoice_id,
                array(
                    $this->model->InvoiceNo=>str_pad($invoice_id,6,0,STR_PAD_LEFT)
                )
            );
            foreach ($invoice_item_value_arrays as $key=>$value){
                $invoice_item_value_arrays[$key][$this->invoice_item_model->InvoiceId] = $invoice_id;
            }
            if(!empty($invoice_item_value_arrays)){
                $this->invoice_item_model->insert_batch($invoice_item_value_arrays);
            }

            $this->session->set_flashdata('notification', $this->lang->line('gen_succ_added'));
            redirect($this->thisModuleBaseUrl);
            die();
        } else {

            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $data['invoice_items'] = array();
            foreach ($PostArray['MaterialId'] as $key => $value){
                if($PostArray['QtyOfMaterial'][$key] != '' || $PostArray['PriceOfUnit'][$key] != ''){
                    $data['invoice_items'][] = $key;
                }
            }
            $data['invoice_items_not_form_db'] = TRUE;
            $this->view($data, $this->view_main_dir . '/edit');
        }
    }

    /**
     * @param string $id
     */
    function edit($id = '')
    {
        if (!is_numeric($id))
            $this->add();

        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl . 'update/' . $id;
        $data['sub_module'] = 'Edit';
        $data['method'] = 'Edit';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;
        $data['Edit_id'] = $id;

        /* load other model data*/
        $data['seller_model'] = $this->seller_model->get_all('Name ASC');
        $data['material_model'] = $this->material_model->get_all('Name ASC');

        $result = $this->model->get($id);
        if (!empty($result)) {

            $this->form_data->Id = $id;
            $this->form_data->SellerId = $result->SellerId;
            $this->form_data->InvoiceNo = $result->InvoiceNo;
            $this->form_data->InvoiceDate = human_date($result->InvoiceDate,DATE_FORMAT);

            $this->form_data->SupplyFromDate = $result->SupplyFromDate!=''? human_date($result->SupplyFromDate,DATE_FORMAT):'';
            $this->form_data->SupplyToDate = $result->SupplyToDate!=''?human_date($result->SupplyToDate,DATE_FORMAT):'';
            $this->form_data->SupplyPlace = $result->SupplyPlace;
            $this->form_data->TransportationMode = $result->TransportationMode;
            $this->form_data->VehicleNumber = $result->VehicleNumber;

            $this->form_data->Remark = $result->Remark;

            $this->form_data->BillStatus = $result->BillStatus;

            $data['invoice_items'] = $this->invoice_item_model->get_all($id,'Id ASC');
            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $this->view($data, $this->view_main_dir . '/edit');
        } else {
            $this->add();
        }
    }


    /**
     * @param $id
     */
    function update($id)
    {
        $PostArray = $this->input->post();
        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl . 'update/' . $id;
        $data['sub_module'] = 'Edit';
        $data['method'] = 'Edit';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;
        $data['Edit_id'] = $id;

        /* load other model data*/
        $data['seller_model'] = $this->seller_model->get_all('Name ASC');
        $data['material_model'] = $this->material_model->get_all('Name ASC');

        $this->_set_rules($id);
        if ($this->form_validation->run() === TRUE) {
            /*Invoice item*/
            $CgstPre = $this->sm->ss->cgst;
            $SgstPre = $this->sm->ss->sgst;
            $IgstPre = $this->sm->ss->igst;
            $CgstAmount = 0;
            $SgstAmount = 0;
            $IgstAmount = 0;
            $TotalQty = 0;
            $Amount = 0;
            $TotalAmount = 0;

            $invoice_item_value_arrays = array();//for insert
            $invoice_item_update_arrays = array();//for update

            foreach ($PostArray['MaterialId'] as $key => $value){
                if($PostArray['QtyOfMaterial'][$key] != '' || $PostArray['PriceOfUnit'][$key] != ''){
                    $invoice_item_value_array = array(
                        $this->invoice_item_model->InvoiceId=>$id,
                        $this->invoice_item_model->MaterialId=>$PostArray['MaterialId'][$key],
                        $this->invoice_item_model->QtyOfMaterial=>round($PostArray['QtyOfMaterial'][$key],3),
                        $this->invoice_item_model->PriceOfUnit=>round($PostArray['PriceOfUnit'][$key],2),
                        $this->invoice_item_model->CgstPre => $CgstPre,
                        $this->invoice_item_model->SgstPre => $SgstPre,
                        $this->invoice_item_model->IgstPre => $IgstPre,
                        $this->invoice_item_model->Status => 'Enable',
                    );
                    $invoice_item_value_array[$this->invoice_item_model->Amount] = round($invoice_item_value_array[$this->invoice_item_model->QtyOfMaterial] * $invoice_item_value_array[$this->invoice_item_model->PriceOfUnit],2);

                    $invoice_item_value_array[$this->invoice_item_model->CgstAmount] = round(($invoice_item_value_array[$this->invoice_item_model->Amount]*$CgstPre/100),2);

                    $invoice_item_value_array[$this->invoice_item_model->SgstAmount] = round(($invoice_item_value_array[$this->invoice_item_model->Amount]*$SgstPre/100),2);

                    $invoice_item_value_array[$this->invoice_item_model->IgstAmount] = round(($invoice_item_value_array[$this->invoice_item_model->Amount]*$IgstPre/100),2);

                    $invoice_item_value_array[$this->invoice_item_model->TotalAmount]=round(($invoice_item_value_array[$this->invoice_item_model->Amount] + $invoice_item_value_array[$this->invoice_item_model->CgstAmount] + $invoice_item_value_array[$this->invoice_item_model->SgstAmount] + $invoice_item_value_array[$this->invoice_item_model->IgstAmount]),2);

                    $CgstAmount += $invoice_item_value_array[$this->invoice_item_model->CgstAmount];
                    $SgstAmount += $invoice_item_value_array[$this->invoice_item_model->SgstAmount];
                    $IgstAmount += $invoice_item_value_array[$this->invoice_item_model->IgstAmount];
                    $Amount += $invoice_item_value_array[$this->invoice_item_model->Amount];
                    $TotalAmount += $invoice_item_value_array[$this->invoice_item_model->TotalAmount];
                    $TotalQty += $invoice_item_value_array[$this->invoice_item_model->QtyOfMaterial];
                    if($PostArray['InvoiceItemId'][$key] != ''){
                        $invoice_item_value_array[$this->invoice_item_model->Id] = $PostArray['InvoiceItemId'][$key];
                        $invoice_item_update_arrays[] = $invoice_item_value_array;
                    }else{
                        $invoice_item_value_arrays[] = $invoice_item_value_array;
                    }
                }
            }

            $CgstAmount = round($CgstAmount,2);
            $SgstAmount = round($SgstAmount,2);
            $IgstAmount = round($IgstAmount,2);
            $TotalQty = round($TotalQty,3);
            $Amount = round($Amount,2);
            $TotalAmount = round($TotalAmount,2);

            $value_array = array(
                $this->model->SellerId => $PostArray['SellerId'],
                $this->model->InvoiceDate => mysql_date_format($PostArray['InvoiceDate']),

                $this->model->SupplyFromDate => mysql_date_format($PostArray['SupplyFromDate']),
                $this->model->SupplyToDate => mysql_date_format($PostArray['SupplyToDate']),
                $this->model->SupplyPlace => $PostArray['SupplyPlace'],

                $this->model->TransportationMode => $PostArray['TransportationMode'],
                $this->model->VehicleNumber => $PostArray['VehicleNumber'],

                $this->model->Remark => $PostArray['Remark'],
                $this->model->BillStatus => $PostArray['BillStatus'],

                $this->model->CgstPre => $CgstPre,
                $this->model->CgstAmount => $CgstAmount,
                $this->model->SgstPre => $SgstPre,
                $this->model->SgstAmount => $SgstAmount,
                $this->model->IgstPre => $IgstPre,
                $this->model->IgstAmount => $IgstAmount,

                $this->model->TotalQty => $TotalQty,
                $this->model->Amount => $Amount,
                $this->model->TotalAmount => $TotalAmount,
            );
            $this->model->update($id,$value_array);

            $this->invoice_item_model->update(array($this->invoice_item_model->InvoiceId=>$id),array($this->invoice_item_model->Status=>'Delete'));

            if(!empty($invoice_item_value_arrays)){
                $this->invoice_item_model->insert_batch($invoice_item_value_arrays);
            }

            if(!empty($invoice_item_update_arrays)){
                $this->invoice_item_model->update_batch($invoice_item_update_arrays);
            }


            //REDIRECT
            $this->session->set_flashdata('notification', $this->lang->line('gen_succ_modified'));
            redirect($this->thisModuleBaseUrl);
            die();
        }
        else
        {
            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $data['invoice_items'] = array();
            foreach ($PostArray['MaterialId'] as $key => $value){
                if($PostArray['QtyOfMaterial'][$key] != '' || $PostArray['PriceOfUnit'][$key] != ''){
                    $data['invoice_items'][] = $key;
                }
            }
            $data['invoice_items_not_form_db'] = TRUE;
            $this->view($data, $this->view_main_dir . '/edit');

        }
    }


    /**
     * @param $id
     */
    function information($id)
    {
        //if id is not numeric load listing
        if (!is_numeric($id)) {
            $this->session->set_flashdata('warning', 'Invalid Id.');
            redirect($this->thisModuleBaseUrl);
        }

        $data = $this->common_data;
        $data['sub_module'] = 'Information';
        $data['method'] = 'information';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;

        $data['result'] = $this->model->get($id);

        if (is_numeric($data['result']->Id)) {
            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $data['invoice_items'] = $this->invoice_item_model->get_all_with_join($id,'invoice_item.Id ASC');
            $this->view($data, $this->view_main_dir . '/detail');
        } else {
            data_not_found();
        }
    }

    function print($id)
    {
        //if id is not numeric load listing
        if (!is_numeric($id)) {
            $this->session->set_flashdata('warning', 'Invalid Id.');
            redirect($this->thisModuleBaseUrl);
        }

        $data = $this->common_data;
        $data['sub_module'] = 'Print';
        $data['method'] = 'print';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;

        $data['result'] = $this->model->get($id);

        if (is_numeric($data['result']->Id)) {

            if($data['result']->BillStatus == 'Pending'){
                $update_array =array(
                    'BillStatus' => 'Print'
                );
                $this->model->update($id,$update_array);
            }

            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $data['invoice_items'] = $this->invoice_item_model->get_all_with_join($id,'invoice_item.Id ASC');
            $this->pdf_create($data);
        } else {
            data_not_found();
        }
    }

    public function pdf_create($data_calc)
    {
        $mpdf= new mPDF('c','A4',12,'',5,5,5,0);
        $mpdf->SetDisplayMode('fullpage');

        $mpdf->SetWatermarkText('NILKANTH');

        $mpdf->showWatermarkText = false;

        /*$mpdf->defaultfooterline=1;*/
        /*$mpdf->defaultfooterfontsize=10;
        $mpdf->defaultfooterfontstyle='B';
        $mpdf->SetFooter('{PAGENO} of {nb}|Printed on {DATE F d, Y}|Prepared using ADS Forensics Inc.');*/
        $html=$this->load->view('manage/pdf/bill_invoice',$data_calc,true);
        $mpdf->WriteHTML($html);

        $html=$this->load->view('manage/pdf/bill_invoice1',$data_calc,true);
        $mpdf->WriteHTML($html);
        /*if($viewfilename==='presentvalue'){
            $html1=$this->load->view('pdf/'.$viewfilename.'1',$data_calc,true); // VIEW('PATH','DATA',BOOLEAN)
            $mpdf->AddPage('L'); // Adds a new page in Landscape orientation
            $mpdf->WriteHTML($html1);
        }*/
        $mpdf->Output();
    }
    // validation rules

    /**
     * @param string $id
     */
    function _set_rules($id = '')
    {

        if($id != ''){
            $this->form_validation->set_rules('BillStatus', 'Bill Status', 'trim|required');
        }

        $this->form_validation->set_rules('SellerId', 'Bill To', 'trim|required|is_natural_no_zero');

        $this->form_validation->set_rules('InvoiceDate', 'Invoice Date', 'trim|required');

        $this->form_validation->set_rules('TransportationMode', 'Transportation Mode', 'trim');
        $this->form_validation->set_rules('VehicleNumber', 'Vehicle Number', 'trim');

        $this->form_validation->set_rules('SupplyFromDate', 'Date of Supply From', 'trim|required');
        $this->form_validation->set_rules('SupplyFromTo', 'Date of Supply To', 'trim');

        $this->form_validation->set_rules('SupplyPlace', 'Place of Supply', 'trim');

        $this->form_validation->set_rules('Remark', 'Remark', 'trim');

        $this->form_validation->set_rules('InvoiceItemId[]', 'Invoice Item Id', 'trim');
        $this->form_validation->set_rules('MaterialId[]', 'Item', 'trim');
        $this->form_validation->set_rules('QtyOfMaterial[]', 'Qty', 'trim|numeric');
        $this->form_validation->set_rules('PriceOfUnit[]', 'Price of Unit', 'trim|numeric');
        $this->form_validation->set_rules('II_Amount[]', 'Amount', 'trim');
    }
}
