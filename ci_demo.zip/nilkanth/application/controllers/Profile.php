<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Profile extends MY_Controller {
    function __construct()
	{  
		parent::__construct();
		has_permission();
		$this->setData('Profile','profile','users');
	}
	function index()
	{
		$id=$this->session->userdata('adminid');
        $data = $this->common_data;
        $values ='users.*';
        $result = $this->cm->get_all_records('users',$values,array('users.Status !='=>'Delete','users.Id '=>$id),'users.Id DESC',1,0)->row();
        $data['result']=$result;
		if(!empty($result))
		{
            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'profile_detail');
		}
		else
		{
			redirect('home');
		}
   	}
	function edit()
	{
		$id = $this->session->userdata('adminid');
		$type=$this->session->userdata('admin_type');
		$data = $this->common_data;
        $data['title']= $this->lang->line('edit_profile');
        $data['action']= $this->thisModuleBaseUrl.'update';
        $data['sub_module']= 'Edit';
        $data['method']="Edit";
        $values ='users.*';
		$result = $this->cm->get_all_records('users',$values,array('users.Status !='=>'Delete','users.Id '=>$id),'users.Id DESC',1,0)->row();
        $data['result']=$result;
        if(!empty($result))
		{
			$this->form_data->id = $id;
			$this->form_data->email = $result->Email;
			$this->form_data->password = $result->Password;
			$this->form_data->name = $result->Name;
			$this->form_data->image = $result->Photo;
			$this->form_data->admin_type = $result->UserType;
            $this->form_data->contact = $result->Phone_no;
            $this->form_data->other_info = $result->OtherInfo;
		}
		else
		{
			redirect('profile');
		}
        /*******************************
        ||  Common data for all page ||
         *******************************/
        $this->view($data,'profile_edit');

	}
    function update()
    {
        $PostArray = $this->input->post();
        $id = $this->session->userdata('adminid');
        $data = $this->common_data;
        $data['title']= $this->lang->line('edit_profile');
        $data['action']= $this->thisModuleBaseUrl.'update';
        $data['sub_module']= 'Edit';
        $data['method']="Edit";
        if($this->input->post('password')!=''){
            $check_pwd = "Yes";
        }
        else {
            $check_pwd = "No";
        }
        $this->set_rules($check_pwd);

        if($this->form_validation->run() === TRUE )
        {
            if($_FILES['file']['name']!='')
            {
                $config['upload_path'] = './uploads/admin/big';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = '10240';
                $config['encrypt_name'] = TRUE;
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('file'))
                {
                    $error = array('error' => $this->upload->display_errors());
                    $data['upload_error'] = $error;


                    $data['content_section'] = $this->load->view('manage/content_section/profile_edit', $data,true);
                    $this->load->view('manage/layout', $data);
                    return;
                }
                else
                {
                    $file_name = $this->upload->file_name;
                    $this->logo = $file_name;
                    $this->create_thumb($file_name,60,60);
                }
            }
            $this->ip_date = $this->cm->get_date_ip();
            $update_array =  array(
                'Name' => $PostArray['name'],
                'Phone_no'=> $PostArray['contact'],
                'ModifiedDate' => $this->ip_date->cur_date,
                'ModifiedIp'=>$this->ip_date->ip,
                'ModifiedBy'=> $this->session->userdata('adminid'),
            );
            if($this->input->post('password')!='')
            {
                $this->_salt = $this->cm->create_pwd_salt();
                $this->_password = hash('sha256',$PostArray['password']);
                $this->_password =  hash('sha256', $this->_salt . $this->_password);
                $update_array['Password'] = $this->_password;
                $update_array['Salt'] = $this->_salt;
            }
            if($file_name!='') {
                $update_array['Photo'] = $file_name;
                $this->session->set_userdata(array(
                    'admin_image'=>$data['login_result']['Photo']
                ));
            }
            $this->session->set_userdata(array(
                'adminfname'=>$PostArray['name']
            ));
            $this->cm->update('users',$update_array,array('Id'=>$id));

            $this->session->set_flashdata('notification','Profile updated successfully');
            redirect(site_url('profile'));
            die();
        }
        else
        {
            $this->view($data,'profile_edit');
        }
    }
    function set_rules($check_pwd='Yes')
    {
        $this->form_validation->set_rules('name', $this->lang->line('name'), 'trim|required');
        $this->form_validation->set_rules('email', $this->lang->line('email'), 'trim');
        if($check_pwd=='Yes')
        {
            $this->form_validation->set_rules('password',$this->lang->line('password'),'min_length[6]|max_length[15]');
            $this->form_validation->set_rules('confirm_password',$this->lang->line('cnf_password'),'matches[password]');
        }
        else
        {
            $this->form_validation->set_rules('password',$this->lang->line('password'),'min_length[6]|max_length[15]');
            $this->form_validation->set_rules('confirm_password',$this->lang->line('cnf_password'),'');
        }
        $this->form_validation->set_rules('contact', $this->lang->line('contact'), 'trim');
        $this->form_validation->set_rules('image',$this->lang->line(''),'');
    }
    function create_thumb($file,$width=60,$height=60,$folder='thumb')
     {
        $config['image_library'] = 'gd2';
        $config['source_image'] = './uploads/admin/big/'.$file; 
        $config['create_thumb'] = FALSE;
        $config['maintain_ratio'] = FALSE;
        $config['width'] = $width;
        $config['height'] = $height;
        $config['new_image'] = './uploads/admin/'.$folder.'/'.$file;
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
        if(!$this->image_lib->resize())
        {
            /*$data['error'] = $this->image_lib->display_errors();

            $this->load->view('manage/user_edit', $data);*/
        }
        else
            $this->image_lib->clear();
        
     }
}
