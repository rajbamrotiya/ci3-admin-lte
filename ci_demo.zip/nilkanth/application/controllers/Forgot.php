<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Forgot extends CI_Controller {
	
	public function __construct() 
	 {
		parent::__construct();
		$this->load->helper('form');
		if($this->session->userdata('admin_logged_in') == TRUE)
		{	
			header('location:'.site_url().'home');}
	    }
	public function index()
	{
		$data = array('title'=>$this->lang->line('forg_password'));

        /*******************************
        ||  Common data for all page ||
         *******************************/
        $data['content_section'] = $this->load->view('manage/content_section/forgot_pwd', $data,true);
        $this->load->view('manage/layout_2', $data);
	}
	public function check()
	{
        $PostArray = $this->input->post();
		$data = array('title'=>$this->lang->line('forg_password'), 'error_msg'=>'');

		$this->form_validation->set_rules('forgot_email', $this->lang->line('email'),'required|valid_email');

		if($this->form_validation->run() === TRUE )
		{
			$data['login_result'] = $this->cm->check_login('users',array('Email'=>$this->input->post('forgot_email'),'Status !='=>'Delete') );
			
			if(empty($data['login_result']))
			{
				$data['error_msg']=$this->lang->line('js_email');
			}
			else
			{
			
				if ($data['login_result']['Status']=='Enable')
				{
					$name=$data['login_result']['Name'];
					$this->_salt = $this->cm->create_pwd_salt();
					$token = hash('sha256', $this->_salt . ( hash('sha256',$data['login_result']['Id']) ) ).time() . rand(1,988);
					$this->ip_date = $this->cm->get_date_ip();
					$value_array=array('UserId' => $data['login_result']['Id'],
									   'Token' => $token,
									   'CreatedDate'=>$this->ip_date->cur_date,
									   'CreatedIp'=>$this->ip_date->ip,
									  );
					$this->cm->replace('forgot_password',$value_array);

                    $mail_temp = $this->cm->get_all_records('mailsettings','*',array('Status !='=>'Delete','Slug'=>'forgot'),'Id DESC',1,0)->row();
                    // parameter for mail template and function to send
                    $to_email = $this->input->post('forgot_email');
                    $from_email = $mail_temp->Email;
                    $from_text = $mail_temp->FromText;
                    $sub_mail = $mail_temp->Subject;
                    $msg = str_replace('[SITE_LINK]', site_url(), $mail_temp->Content);
                    $msg = str_replace('[LOGO_LINK]', site_url('themes/manage/images/logo2.png'), $msg);
                    $msg = str_replace('[SITE_NAME]', $this->sm->ss->site_name, $msg);
                    $msg = str_replace('[SITE_COPYRIGHT]', $this->sm->ss->site_copyright, $msg);
                    $msg = str_replace('[LINK]', site_url('manage/recover_pwd/index/' . $token), $msg);
                    $result = $this->cm->send_mail($to_email,$from_email,$from_text,$sub_mail,$msg);
                    if($result!='')
                    {
                        $this->session->set_flashdata('notification',$this->lang->line('frgt_mail_sent'));
                        redirect(site_url('manage/forgot/'));
                        die();
                    }
                    else
                    {
                        /*$this->email->print_debugger();
                        die;*/
                        $data['error_msg']=$this->lang->line('err_problem');

                    }
				
				}
				else // ACCOUNT SUSPENDED
				{
					$data['error_msg']=$this->lang->line('err_acc_suspend');
					/*$this->session->set_flashdata('error',$this->lang->line('err_acc_suspend'));
					redirect(site_url('manage/forgot_pwd/'));*/
				}
			}
		}
		else  //EMPTY FIELDS
		{
		  	$this->session->unset_userdata(array('adminname'=>'','adminid'=>'', 'logged_in'=>FALSE, 'admin_type'=>''));
			
		}

        /*******************************
        ||  Common data for all page ||
         *******************************/
        $data['content_section'] = $this->load->view('manage/content_section/forgot_pwd', $data,true);
        $this->load->view('manage/layout_2', $data);
	}
}

/* End of file Home.php */
/* Location: ./application/controllers/manage/Home.php */