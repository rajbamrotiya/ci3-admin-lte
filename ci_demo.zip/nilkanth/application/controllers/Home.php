<?php if( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends MY_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->setData('Dashboard','home');
	}
	public function index()
    {
        $data = $this->common_data;
        add_css_page(array('morris.css'));
        $this->config->set_item('footer_js', array());
        add_js_footer(array('jquery-2.2.3.min.js','jquery-ui.min.js','bootstrap.min.js','bootstrap-notify.min.js','pace.min.js','raphael-min.js','jquery.sparkline.min.js','jquery-jvectormap-1.2.2.min.js','jquery-jvectormap-world-mill-en.js','jquery.knob.js','moment.min.js','daterangepicker.js','bootstrap-datepicker.js','bootstrap3-wysihtml5.all.min.js','jquery.slimscroll.min.js','fastclick.js','app.js','dashboard2.js','demo.js','jquery.dataTables.min.js','dataTables.bootstrap.min.js','custom.js','Chart.min.js'));
        $this->view($data,'home');

	}
}

/* End of file Home.php */
/* Location: ./application/controllers/manage/Home.php */