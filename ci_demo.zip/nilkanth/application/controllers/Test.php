<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Test extends CI_Controller {
	var $limit = 10;

    /**
     * Test constructor.
     */
    function __construct()
	{
		parent::__construct();
        $this->load->model('manage/admin_model');
        not_accessible();
        /*$role_that_access_all_data = array('SubAdmin','SuperAdmin');
        if(!in_array($this->session->userdata('admin_type'),$role_that_access_all_data)){
            echo '<pre>';
            var_dump(get_accessable_company());
            var_dump(get_re_firm());
            die;
        }*/
        /*role base data fetch*/
	}
	function index()
	{

	}
	function edit()
	{

	}
	function update()
	{
	}
	function insert()
	{
	}
}
