<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Settings extends MY_Controller {
	function __construct()
	{
		parent::__construct();
        has_permission();
        $this->setData('Settings','settings','setting');
	}
	function index()
	{
		$data = $this->common_data;
		$page_type=$_GET['section']==''?"General":$_GET['section'];
		$this->total = $this->cm->count_all($data['tbl'],array('Status'=>'Enable','setting_type'=>$page_type));
		$data['list_records'] = $this->cm->get_all_records($data['tbl'],'*',array('Status'=>'Enable','Setting_type'=>$page_type))->result();
        /*******************************
        ||  Common data for all page ||
         *******************************/
        $this->view($data,'settings');
	}
    function add()
    {
		 // SET COMMON PROPERTIES
        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'insert';
        $data['sub_module']=  'Add';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['method']=  'Add';
        $data['add']=  'Yes';


        /*******************************
        ||  Common data for all page ||
         *******************************/
        $this->view($data,'settingsedit');
	}
	function insert()
	{
        $PostArray = $this->input->post();
        // SET COMMON PROPERTIES
        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'insert';
        $data['sub_module']=  'Add';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['method']=  'Add';
        $data['add']=  'Yes';
		
		// set validation properties
		$this->_set_rules();

		if($this->form_validation->run() === TRUE )
		{
			$this->ip_date = $this->cm->get_date_ip();
			// save data
			$value_array = array(
								'fieldName' => $this->input->post('title'),
								'keytext' => $this->input->post('keytext') ,
								'value' =>$this->input->post('value'),
								'status'=>'Enable',
								'setting_type'=>$this->input->post('setting_type'),
								'CreatedDate'=> $this->ip_date->cur_date,
								'CreatedIp'=> $this->ip_date->ip,
							);
			$return_id = $this->cm->save($data['tbl'],$value_array);
            $this->session->set_flashdata('notification',$this->lang->line('setting_succ_added'));
            redirect(site_url('settings'));
            die();
		}
		else
		{	

            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'settingsedit');
			
		}
	 
		
	}
    function edit($id='')
    {
        if(!is_numeric($id))
            $this->add();
        $data = $this->common_data;

        $data['action']= $this->thisModuleBaseUrl.'update/'.$id;
        $data['sub_module']=  'Edit';
        $data['method']=  'Edit';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['Edit_id']=  $id;

        $result = $this->cm->get_all_records($data['tbl'],'*',array('Id'=>$id),'',1)->row();

        if(!empty($result)) {
            $this->form_data->keytext = $result->Keytext;
            $this->form_data->title = $result->Fieldname;
            $this->form_data->value = $result->Value;
            $this->form_data->setting_type = $result->Setting_type;
            $data['field'] = $result;
            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'settingsedit');
        }else{
            $this->add();
        }
    }
    function update($id)
    {
        $PostArray = $this->input->post();
        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'update/'.$id;
        $data['sub_module']=  'Edit';
        $data['method']=  'Edit';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['Edit_id']=  $id;

        $this->_set_rules();

        if($this->form_validation->run() === TRUE )
        {
            // save data
            $value_array = array(
                'Value' => $this->input->post('value'),
                'Fieldname' => $this->input->post('title'),
                'Setting_type' => $this->input->post('setting_type'),
            );
            $id = $this->cm->update($data['tbl'],$value_array,array('Id'=>$id));
            $this->session->set_flashdata('notification',$this->lang->line('setting_succ_modified'));
            redirect(site_url('settings/index'));
            die();
        }
        else
        {

            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'settingsedit');
        }
    }
    function _set_fields()
    {
        $this->form_data->value = '';
    }
	// validation rules
	function _set_rules()
	{
		$this->form_validation->set_rules('value',$this->lang->line('value'), 'trim|required');
		$this->form_validation->set_rules('keytext', $this->lang->line('key'), 'trim|required|max_length[200]');
		$this->form_validation->set_rules('setting_type', $this->lang->line('setting_type'), 'trim|required');
		$this->form_validation->set_rules('title', $this->lang->line('title'), 'trim|required|max_length[200]');
    }
}
