<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Recover_pwd extends CI_Controller { 
	public function __construct()
	{
		parent::__construct();
		$this->load->model('manage/admin_model');		
		if($this->session->userdata('admin_logged_in') == TRUE)
			header('location:'.site_url().'manage/home');		
	}
	public function index($Token)
	{
		$data = array('title'=>$this->lang->line('recover_pwd'),'action'=>site_url('manage/recover_pwd/insert/'.$Token),'message'=>'','tbl'=>'users' );
		$value=('users.Status,users.Id,forgot_password.CreatedDate');
		$joins = array
			   (
				  array
					(
					  'table' => 'users',
					  'condition' => 'forgot_password.UserId = users.Id',
					  'jointype' => 'left'
					 ),
				);
		$result = $this->cm->get_joins('forgot_password',$value,$joins,array('forgot_password.Token'=>$Token),'users.Id','asc',1)->row();
		if(empty($result))
		{
			$this->session->set_flashdata('error',$this->lang->line('gen_alrady_recovered'));
			redirect('manage/login');
			die();
		}
		elseif($result->Status=='Disable')
		{
			$this->session->set_flashdata('error',$this->lang->line('err_acc_suspend'));
			redirect('manage/login');
			die();
		}
		else
		{
			$sentdate=strtotime($result->CreatedDate);
			$current_date=strtotime(date('Y-m-d'));
			$diff= abs($sentdate - $current_date);
			$difference=($diff/(60*60*24));
			if($difference > 5)
			{
				$this->cm->delete('forgot_password',array('UserId'=>$result->Id));
				$this->session->set_flashdata('error',$this->lang->line('gen_link_expierd'));
				redirect('manage/login');
				die();
			}
			else
			{
                /*******************************
                ||  Common data for all page ||
                 *******************************/


                $data['content_section'] = $this->load->view('manage/content_section/recover_pwd', $data,true);
                $this->load->view('manage/layout_2', $data);
			}
			
		}
	}
	function insert($Token)
	{
        $PostArray = $this->input->post();
		$data = array(
		    'js_validate'=>'Yes',
            'action'=>site_url('manage/recover_pwd/insert/'.$Token),
            'message'=>'','tbl'=>'users'
        );
		$this->_set_rules();



		if($this->form_validation->run() === TRUE )
		{
			$value=('users.Status,users.Id,forgot_password.CreatedDate');
			$joins = array
				   (
					  array
						(
						  'table' => 'users',
						  'condition' => 'forgot_password.UserId = users.Id',
						  'jointype' => 'left'
						 ),
					);
			$result = $this->cm->get_joins('forgot_password',$value,$joins,array('forgot_password.Token'=>$Token),'users.Id','asc',1)->row();
		
			if(empty($result))
			{
				$this->session->set_flashdata('error',$this->lang->line('gen_alrady_recovered'));
				redirect('manage/login');
				die();
			}
			elseif($result->Status=='Disable')
			{
				$this->session->set_flashdata('error',$this->lang->line('err_acc_suspend'));
				redirect('manage/login');
				die();
			}
			else
			{
				$sentdate=strtotime($result->CreatedDate);
				$current_date=strtotime(date('Y-m-d'));
				$diff= abs($sentdate - $current_date);
				$difference=($diff/(60*60*24));
				if($difference > 5)
				{
					$this->cm->delete('forgot_password',array('UserId'=>$result->Id));
					$this->session->set_flashdata('error',$this->lang->line('gen_link_expierd'));
					redirect('manage/login');
					die();
				}
				else{
					//$result = $this->cm->get_all_records('admin_forgotpassword','*',array('Token'=>$Token),'Id',1)->row();
					$this->ip_date = $this->cm->get_date_ip();
					$this->_salt = $this->cm->create_pwd_salt();
					$this->_password = hash('sha256', $this->_salt . ( hash('sha256',$this->input->post('recover_pass')) ) );
					$value_array = array(
										'Password' => $this->_password ,
										'Salt' => $this->_salt ,
										);
					 $this->cm->update($data['tbl'],$value_array,array('Id'=>$result->Id));
					 $this->cm->delete('forgot_password',array('UserId'=>$result->Id));
					 $this->session->set_flashdata('notification',$this->lang->line('gen_succ_recover'));
					 redirect('manage/login');
					 die();
				}
			}
		}
		else
		{
			if($csrf_check==false) $this->session->set_flashdata('error',$this->lang->line('csrf_error'));
			redirect(site_url('manage/recover_pwd/index/'.$Token));
		}
	}
	//SET FORM DATA
	
	// VALIDATION RULES
	function _set_rules()
	{
		$this->form_validation->set_rules('recover_pass','New password','required|min_length[6]|max_length[15]');
		$this->form_validation->set_rules('conf_recover_pass','The Confirm new password ','required|matches[recover_pass]');
	}
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */