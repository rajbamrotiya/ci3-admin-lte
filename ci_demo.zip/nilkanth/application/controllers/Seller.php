<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Seller extends MY_Controller
{
    var $view_main_dir = 'seller';

    function __construct()
    {
        parent::__construct();
        has_permission();
        $this->load->model('seller_model');
        $this->setData('Sellers', 'seller', $this->seller_model->table_nm);
        $this->common_data['state_table'] = $this->config->item('state_table');
        $this->common_data['gujarat_state_code'] = $this->config->item('gujarat_state_code');
        $this->common_data['country_table'] = $this->config->item('country_table');
    }

    function index()
    {
        $data = $this->common_data;
        $data['list_records'] = $this->seller_model->get_all();
        $this->view($data, $this->view_main_dir . '/index');
    }


    /**
     *
     */
    function add()
    {
        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl . 'insert';
        $data['sub_module'] = 'Add';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;
        $data['method'] = 'Add';

        $this->form_data->StateCode = 16;

        /*******************************
         * ||  Common data for all page ||
         *******************************/
        $this->view($data, $this->view_main_dir . '/edit');
    }

    /**
     *
     */
    function insert()
    {
        $PostArray = $this->input->post();

        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl . 'insert';
        $data['sub_module'] = 'Add';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;
        $data['method'] = 'Add';

        $this->_set_rules();
        if ($this->form_validation->run() === TRUE) {

            $value_array = array(
                $this->seller_model->Name => $PostArray['Name'],
                $this->seller_model->Address => $PostArray['Address'],
                $this->seller_model->GstNo => $PostArray['GstNo'],
                $this->seller_model->PanNo => $PostArray['PanNo'],
                $this->seller_model->Country => $PostArray['Country'],
                $this->seller_model->State => $PostArray['State'],
                $this->seller_model->StateCode => $PostArray['StateCode'],
                $this->seller_model->OtherInfo => $PostArray['OtherInfo'],
            );
            $id = $this->seller_model->insert($value_array);
            $this->session->set_flashdata('notification', $this->lang->line('gen_succ_added'));
            redirect($this->thisModuleBaseUrl);
            die();
        } else {

            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $this->view($data, $this->view_main_dir . '/edit');
        }
    }

    /**
     * @param string $id
     */
    function edit($id = '')
    {
        if (!is_numeric($id))
            $this->add();

        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl . 'update/' . $id;
        $data['sub_module'] = 'Edit';
        $data['method'] = 'Edit';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;
        $data['Edit_id'] = $id;
        $result = $this->seller_model->get($id);
        if (!empty($result)) {

            $this->form_data->Id = $id;
            $this->form_data->Name = $result->Name;
            $this->form_data->Address = $result->Address;
            $this->form_data->GstNo = $result->GstNo;
            $this->form_data->PanNo = $result->PanNo;
            $this->form_data->State = $result->State;
            $this->form_data->StateCode = $result->StateCode;
            $this->form_data->Country = $result->Country;
            $this->form_data->OtherInfo = $result->OtherInfo;

            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $this->view($data, $this->view_main_dir . '/edit');
        } else {
            $this->add();
        }
    }


    /**
     * @param $id
     */
    function update($id)
    {
        $PostArray = $this->input->post();
        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl . 'update/' . $id;
        $data['sub_module'] = 'Edit';
        $data['method'] = 'Edit';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;
        $data['Edit_id'] = $id;

        $this->_set_rules($id);

        if ($this->form_validation->run() === TRUE) {
            $update_array = array(
                $this->seller_model->Name => $PostArray['Name'],
                $this->seller_model->Address => $PostArray['Address'],
                $this->seller_model->GstNo => $PostArray['GstNo'],
                $this->seller_model->PanNo => $PostArray['PanNo'],
                $this->seller_model->Country => $PostArray['Country'],
                $this->seller_model->State => $PostArray['State'],
                $this->seller_model->StateCode => $PostArray['StateCode'],
                $this->seller_model->OtherInfo => $PostArray['OtherInfo'],
            );

            $this->seller_model->update($id, $update_array);

            //REDIRECT
            $this->session->set_flashdata('notification', $this->lang->line('gen_succ_modified'));
            redirect($this->thisModuleBaseUrl);
            die();
        } else {

            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $this->view($data, $this->view_main_dir . '/edit');

        }
    }


    /**
     * @param $id
     */
    function information($id)
    {
        //if id is not numeric load listing
        if (!is_numeric($id)) {
            $this->session->set_flashdata('warning', 'Invalid Id.');
            redirect($this->thisModuleBaseUrl);
        }

        $data = $this->common_data;
        $data['sub_module'] = 'Information';
        $data['method'] = 'information';
        $data['title'] = $data['sub_module'] . ' | ' . $this->thisModuleName;

        $data['result'] = $this->seller_model->get($id);

        if (is_numeric($data['result']->Id)) {
            /*******************************
             * ||  Common data for all page ||
             *******************************/
            $this->view($data, $this->view_main_dir . '/detail');
        } else {
            data_not_found();
        }
    }

    // validation rules

    /**
     * @param string $id
     */
    function _set_rules($id = '')
    {
        $this->form_validation->set_rules('Name', 'Name', 'trim|required|min_length[1]|max_length[255]|callback_check_exists[' . $id . ']');
        $this->form_validation->set_rules('Address', 'Address', 'trim|required|max_length[1000]');

        $this->form_validation->set_rules('GstNo', 'GST Number', 'trim|required|min_length[1]|max_length[255]');
        $this->form_validation->set_rules('PanNo', 'PAN Number', 'trim|required|min_length[1]|max_length[255]');

        $this->form_validation->set_rules('Country', 'Country', 'trim|required|is_natural_no_zero');
        $this->form_validation->set_rules('State', 'State', 'trim|required|is_natural_no_zero');
        $this->form_validation->set_rules('StateCode', 'District', 'trim|required|is_natural_no_zero');

        $this->form_validation->set_rules('OtherInfo', 'Other Information', 'trim|max_length[1000]');
    }

    /**
     * @param $name
     * @param string $id
     * @return bool
     */
    function check_exists($name, $id = '')
    {
        $data['result'] = $this->cm->check_record_exist($this->seller_model->table_nm, 'Id', array('Name' => $name, 'Status !=' => 'Delete'));
        if (!empty($data['result'])) {
            if ($id != '' && $id == $data['result']['Id']) {
                return TRUE;
            } else {
                $this->form_validation->set_message('check_exists', 'This seller name already exist.');
                return FALSE;
            }
        }
        return TRUE;
    }

}
