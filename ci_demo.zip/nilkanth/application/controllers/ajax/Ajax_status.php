<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Ajax_status extends MY_Controller {
	
    public function __construct()
    {
		parent::__construct();
    }
    public function index()
    {
        header('Content-Type: application/json');
        $tbl = $this->cm->Decryption($this->input->post('tbl'));
        $tbl_with_prefix = $this->db->dbprefix($tbl);
        $tbl_id = $this->input->post('id');
        $where_con = 'Id = '.$tbl_id;
        $query = "UPDATE  ".$tbl_with_prefix." SET Status = if(status='Enable','Disable','Enable' ) Where ".$where_con;
        $this->cm->custom_query($query);
        //Insert Modified log
        $value_array = array(
            'TableId' => $tbl_id,
            'TableName' => $tbl_with_prefix,
        );
        $this->cm->insert_modified($value_array);
        $message=array('code'=>1);
        echo json_encode($message);
        die();
    }
}
