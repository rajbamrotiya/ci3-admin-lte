<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Ajax_delete extends MY_Controller {
	public function __construct()
    {
		parent::__construct();
    }
	public function index()
	{
        header('Content-Type: application/json');
        $tbl = $this->cm->Decryption($this->input->post('tbl'));
        $modified_status='Delete';
        $tbl_id = $this->input->post('id');
        $where_con = array('Id' => $tbl_id);
        $this->cm->update($tbl, array('Status' => $modified_status), $where_con);
        //Insert Modified log
        $value_array = array(
            'TableId' => $tbl_id,
            'TableName' => $this->db->dbprefix($tbl),
        );
        $this->cm->insert_modified($value_array);
        $message = array('code' => 1);
        
		echo json_encode($message);
		die();
	}
}

/* End of file Ajax_delete.php */
/* Location: ./application/controllers/manage/Ajax_delete.php */