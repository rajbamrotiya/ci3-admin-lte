<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mail_template extends MY_Controller {
	function __construct()
	{ 
		parent::__construct();
		$this->setData('Mail Templates','mail_template','mailsettings');
		add_css_page(array('bootstrap3-wysihtml5.min.css'));
        add_js_footer(array('ckeditor.js'));
	}
	function index()
	{
		// load data
        $data = $this->common_data;
        $data['action'] = $this->thisModuleBaseUrl;
        $value='Id,Title,Status';
        $data['list_records'] = $this->cm->get_all_records($data['tbl'],$value,array('Status !='=>'Delete'),'Id DESC')->result();
        $this->view($data,'mail_template');
	}
	
	function add()
	{
	    $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'insert';
        $data['sub_module']=  'Add';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['method']=  'Add';
        /*******************************
        ||  Common data for all page ||
         *******************************/
        $this->view($data,'mail_template_edit');
		
	}
	function insert()
	{
        $PostArray = $this->input->post();
        
        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'insert';
        $data['sub_module']=  'Add';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['method']=  'Add';


		$this->_set_rules($PostArray['slug']);
		if($this->form_validation->run() === TRUE)
		{
			$this->ip_date = $this->cm->get_date_ip();
			$value_array = array(
                'Title' => $PostArray['title'],
                'Email' => $PostArray['email'],
                'Slug'=> $PostArray['slug'],
                'FromText' => $PostArray['from_text'] ,
                'Subject' => $PostArray['subject'] ,
                'Content' => $PostArray['page_content'] ,
                'CreatedBy' => $this->session->userdata('adminid'),
                'CreatedDate'=>$this->ip_date->cur_date,
                'CreatedIp'=>$this->ip_date->ip,
            );
			$id = $this->cm->save($data['tbl'],$value_array);
			$this->session->set_flashdata('notification',$this->lang->line('mail_succ_added'));
            redirect($this->thisModuleBaseUrl);
			die();
		}
		else
		{
            $this->view($data,'mail_template_edit');
		}
    }
	function edit($id='')
	{
		if(!is_numeric($id)){
            $this->add();
        }
		// set common properties
        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'update/'.$id;
        $data['sub_module']=  'Edit';
        $data['method']=  'Edit';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['Edit_id']=  $id;
		
		$value='FromText,Email,Title,Subject,Content,Slug';
		$result =  $this->cm->get_all_records($data['tbl'],$value,array('Id'=>$id,'Status !='=>'Delete'),'',1)->row();
		
		if(!empty($result))
		{
			$this->form_data->title = $result->Title;
			$this->form_data->email = $result->Email;
			$this->form_data->from_text = $result->FromText;
			$this->form_data->subject = $result->Subject;
			$this->form_data->slug = $result->Slug;
			$this->form_data->page_content = $result->Content;
            /*******************************
            ||  Common data for all page ||
             *******************************/
            $this->view($data,'mail_template_edit');
		}
		else
		{
			$this->add(); // If id does not exist(no result) load listing
		}
	
	}
	function update($id)
	{
		if(!is_numeric($id)) 
			$this->add();
        $PostArray = $this->input->post();
        $data = $this->common_data;
        $data['action']= $this->thisModuleBaseUrl.'update/'.$id;
        $data['sub_module']=  'Edit';
        $data['method']=  'Edit';
        $data['title']= $data['sub_module'] .' | '. $this->thisModuleName ;
        $data['Edit_id']=  $id;
		// set empty default form field values
		$this->_set_rules();
		if($this->form_validation->run() === TRUE)
		{
			$value_array = array(
                'Title' => $PostArray['title'],
                'Email' => $PostArray['email'],
                'FromText' => $PostArray['from_text'] ,
                'Subject' => $PostArray['subject'] ,
                'Content' => $PostArray['page_content'] ,
                'CreatedBy' => $this->session->userdata('adminid'),
                'CreatedDate'=>$this->ip_date->cur_date,
                'CreatedIp'=>$this->ip_date->ip,
            );
			$this->cm->update($data['tbl'],$value_array,array('Id'=>$id));

			//UPDATE MODIFY LOG TABLE
			$value_array = array(
								'TableId' => $id,
								'TableName' => $this->db->dbprefix($this->common_data['tbl']),
							);
			$this->cm->insert_modified($value_array);
			
		    $this->session->set_flashdata('notification',$this->lang->line('mail_succ_modified'));
            redirect($this->thisModuleBaseUrl);
			die();
		}
		else
		{
            $this->view($data,'mail_template_edit');
		}
	 }
	 
	// validation rules
	function _set_rules($slug='')
	{
		$this->form_validation->set_rules('title', $this->lang->line('title'), 'trim|required|max_length[100]');
		$this->form_validation->set_rules('email', $this->lang->line('from_email'), 'trim|required|valid_email|max_length[100]');
		$this->form_validation->set_rules('from_text', $this->lang->line('from_text'), 'trim|required|max_length[100]');
		$this->form_validation->set_rules('subject', $this->lang->line('subject'), 'trim|required|max_length[100]');
		$this->form_validation->set_rules('page_content', $this->lang->line('mail_content'), '');
		if(!empty($slug)){
		$this->form_validation->set_rules('slug', 'Slug', 'trim|required|callback_check_exists['.$slug.']');
		}
	}
	function check_exists($slug)
  	{
		$data['result'] = $this->cm->check_record_exist('mailsettings','Id',array('Slug'=>$slug,'Status !='=>'Delete'));
	  	if (!empty($data['result']))
		{
			if($slug !='' && $slug==$data['result']['Slug'])
			{
				return TRUE;
			}
			else
			{
				$this->form_validation->set_message('check_exists','Slug already exists');
				return FALSE;
			}
		}		
		return TRUE;
	}
	
}