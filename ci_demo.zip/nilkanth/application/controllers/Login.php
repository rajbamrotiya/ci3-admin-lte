<?php if( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
    }
    public function index()
	{
        if($this->session->userdata('admin_logged_in') == TRUE){
            header('location:'.site_url('home'));
        }
		$data = array('title'=>$this->lang->line('admin')." ". $this->lang->line('login'));

        /*******************************
        ||  Common data for all page ||
         *******************************/
        $data['display_msg'] = $this->load->view('manage/includes/display_msg', $data,true);
        $data['content_section'] = $this->load->view('manage/content_section/login', $data,true);

		$this->load->view('manage/layout_2', $data);
	}

    /**
     *
     */
    public function check()
	{
        if($this->session->userdata('admin_logged_in') == TRUE){
            header('location:'.site_url('home'));
        }
        $PostArray = $this->input->post();
		$data = array(
		    'title'=> $this->lang->line('admin')." ". $this->lang->line('login'),
        );
		$this->form_validation->set_rules('email',  $this->lang->line('email'),'trim|required|valid_email');
		$this->form_validation->set_rules('password',  $this->lang->line('password'),'required');
		$this->_emailID = $this->input->post('email');

		if($this->form_validation->run() === TRUE)
		{
			$data['login_result'] = $this->cm->check_login('users',array('Email'=>$this->input->post('email'),'Status !='=>'Delete') );
			if (!empty($data['login_result']))
			{
				if ($data['login_result']['Status']=='Enable')
				{
					$this->_password = hash('sha256',$this->input->post('password'));
					$this->_password =  hash('sha256',$data['login_result']['Salt'] . $this->_password);
					if($data['login_result']['Password'] == $this->_password)
					{
                        $this->session->sess_regenerate();
						if($this->input->post('check_right')== TRUE )
						{
							$this->input->set_cookie('pavans_demo_session_id',session_id(),(365 * 24 * 60 * 60));
						}
						$this->session->set_userdata(array(
						    'admin_type'=>$data['login_result']['UserType'],
                            'adminfname'=>$data['login_result']['Name'],
                            'adminid'=>$data['login_result']['Id'], 'admin_logged_in'=>TRUE ,
                            'admin_image'=>$data['login_result']['Photo']
                        ));
						$this->session->userdata('admin_logged_in');
						$this->ip_date = $this->cm->get_date_ip();
						$value_array = array(
                            'UserId' => $this->session->userdata('adminid'),
                            'LoginDate'=>$this->ip_date->cur_date,
                            'LoginIp'=>$this->ip_date->ip,
                            'LoginDetail'=> $_SERVER['HTTP_USER_AGENT']
                        );
						//insert in login log table
						$id = $this->cm->save('login_log',$value_array);

						//echo 'hi';die;
                        if ($this->input->post('target_url') != '') {
                            redirect($this->input->post('target_url'));
                        } else {
                            redirect(site_url('home'));
                        }
                        die();
					}
					else  // WRONG PAASWORD
					{
						$this->cm->clean_session();
						$data['error_msg'] = $this->lang->line('err_valid_pwd');
					}
				}
				else // ACCOUNT SUSPENDED
				{
					$this->cm->clean_session();
					$data['error_msg'] = $this->lang->line('err_acc_suspend');	
				}
			}
			else // ACCOUNT SUSPENDED
			{
				$this->cm->clean_session();
				$data['error_msg'] = $this->lang->line('err_valid_mail');
			}
		}

        /*******************************
        ||  Common data for all page ||
         *******************************/
        $data['display_msg'] = $this->load->view('manage/includes/display_msg', $data,true);
        $data['content_section'] = $this->load->view('manage/content_section/login', $data,true);

        $this->load->view('manage/layout_2', $data);
		//$data['error_msg'] = 'Error: Enter email and password';
	}
	public function logout()			//LOGOUT - DESTROY ALL SESSION DATA
	{
		$data = array('title'=>$this->lang->line('admin_login'),'target'=>site_url('manage'), 'error_msg'=>'');
		$this->cm->clean_session();

		/*******************************
        ||  Common data for all page ||
         *******************************/
		$data['content_section'] = $this->load->view('manage/content_section/login', $data,true);
        $this->load->view('manage/layout_2', $data);
        redirect(site_url());
	}
}
