<?php if( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: raj
 * Date: 13/7/17
 * Time: 2:24 AM
 */
class MY_Controller extends CI_Controller {
    var $common_data,$thisModuleName,$thisModuleBaseUrl;
    var $limit=10;
    public function __construct()
    {
        parent::__construct();
        has_permission();
        $this->limit = $this->sm->ss->site_admin_rowperpage;
    }
    protected function view($data,$content_section)
    {
        $data['content_section'] = $this->load->view('manage/content_section/'.$content_section, $data,true);
        $this->load->view('manage/layout', $data);
    }

    /**
     * @param $ModuleName
     * @param $ModuleBaseUrl
     * @internal param mixed $data
     */
    public function setData($ModuleName,$ModuleBaseUrl,$tbl='')
    {
        $this->thisModuleName =$ModuleName;
        $this->thisModuleBaseUrl = site_url($ModuleBaseUrl).'/';
        $this->common_data = array(
            'title' => $this->thisModuleName,
            'link_back' => $this->thisModuleBaseUrl,
            'link_add' => $this->thisModuleBaseUrl.'add/',
            'edit_link' => $this->thisModuleBaseUrl.'edit/',
            'info_link' => $this->thisModuleBaseUrl.'information/',
            'tbl' => $tbl,
            'main_module' => $this->thisModuleName,
            'module_base_url' => $this->thisModuleBaseUrl,
            'roles_key_value' => $this->config->item('roles_key_value'),
            'thumb_profile_img_login_user' => check_image($this->session->userdata('admin_image'),'uploads/admin'),
            'big_profile_img_login_user' => check_image($this->session->userdata('admin_image'),'uploads/admin','big'),
        );
    }
}

/* End of file Home.php */
/* Location: ./application/controllers/manage/Home.php */