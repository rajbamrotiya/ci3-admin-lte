<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: raj
 * Date: 12/7/17
 * Time: 12:16 AM
 */
$config['JS_VERSION'] = '?v=05-01-2017-6:22PM';
$config['CSS_VERSION'] = '?v=05-01-2017-6:22PM';

$config['all_css_with_url'] = array(
    'bootstrap.min.css'=> 'themes/manage/css/bootstrap.min.css',
    'font-awesome.min.css' => 'themes/manage/css/font-awesome.min.css',
    'ionicons.min.css' => 'themes/manage/css/ionicons.min.css',
    /*'font-awesome.min.css'=>'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css',
    'ionicons.min.css'=>'https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css',*/
    'AdminLTE.min.css'=>'themes/manage/css/AdminLTE.min.css',
    '_all-skins.min.css'=>'themes/manage/css/skins/_all-skins.min.css',
    'iCheck/flat/blue.css'=>'themes/manage/plugins/iCheck/flat/blue.css',
    'iCheck/square/blue.css'=>'themes/manage/plugins/iCheck/square/blue.css',
    'iCheck/all.css'=>'themes/manage/plugins/iCheck/all.css',
    'pace.min.css'=>'themes/manage/plugins/pace/pace.min.css',
    'morris.css'=>'themes/manage/plugins/morris/morris.css',
    'jquery-jvectormap-1.2.2.css'=>'themes/manage/plugins/jvectormap/jquery-jvectormap-1.2.2.css',
    'datepicker3.css'=>'themes/manage/plugins/datepicker/datepicker3.css',
    'daterangepicker.css'=>'themes/manage/plugins/daterangepicker/daterangepicker.css',
    'bootstrap3-wysihtml5.min.css'=>'themes/manage/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css',
    'dataTables.bootstrap.css'=>'themes/manage/plugins/datatables/dataTables.bootstrap.css',
    'custom.css'=>'themes/manage/css/custom.css'.$config['CSS_VERSION'],
    'animate.css'=>'themes/manage/css/animate.css'.$config['CSS_VERSION'],
);
$config['all_js_with_url'] = array(
    'jquery-2.2.3.min.js' => "themes/manage/plugins/jQuery/jquery-2.2.3.min.js",
    'jquery-ui.min.js' => "themes/manage/plugins/jQueryUI/jquery-ui.min.js",
    /*'jquery-ui.min.js' => "https://code.jquery.com/ui/1.11.4/jquery-ui.min.js",*/
    'bootstrap.min.js' => "themes/manage/js/bootstrap.min.js",
    'raphael-min.js' => "https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js",
    'morris.min.js' => "themes/manage/plugins/morris/morris.min.js",
    'jquery.sparkline.min.js' => "themes/manage/plugins/sparkline/jquery.sparkline.min.js",
    'jquery-jvectormap-1.2.2.min.js' => "themes/manage/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js",
    'jquery-jvectormap-world-mill-en.js' => "themes/manage/plugins/jvectormap/jquery-jvectormap-world-mill-en.js",
    'jquery.knob.js' => "themes/manage/plugins/knob/jquery.knob.js",
    'moment.min.js' => "https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js",
    'daterangepicker.js' => "themes/manage/plugins/daterangepicker/daterangepicker.js",
    'bootstrap-datepicker.js' => "themes/manage/plugins/datepicker/bootstrap-datepicker.js",
    'bootstrap3-wysihtml5.all.min.js' => "themes/manage/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js",
    'jquery.slimscroll.min.js' => "themes/manage/plugins/slimScroll/jquery.slimscroll.min.js",
    'icheck.min.js' => "themes/manage/plugins/iCheck/icheck.min.js",
    'fastclick.js' => "themes/manage/plugins/fastclick/fastclick.js",
    'Chart.min.js' => "themes/manage/plugins/chartjs/Chart.min.js",
    'pace.min.js' => "themes/manage/plugins/pace/pace.min.js",
    'validate.min.js'=>"themes/manage/js/validate.min.js",
    'jquery.dataTables.min.js'=>'themes/manage/plugins/datatables/jquery.dataTables.min.js',
    'dataTables.bootstrap.min.js'=>'themes/manage/plugins/datatables/dataTables.bootstrap.min.js',
    /*'ckeditor.js'=> 'https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js',*/
    'ckeditor.js' => 'themes/manage/plugins/ckeditor/ckeditor.js',
    'validate_init.js'=>"themes/manage/js/validate_init.js".$config['JS_VERSION'],
    'app.js' => "themes/manage/js/app.js".$config['JS_VERSION'],
    'dashboard.js' => "themes/manage/js/pages/dashboard.js".$config['JS_VERSION'],
    'dashboard2.js' => "themes/manage/js/pages/dashboard2.js".$config['JS_VERSION'],
    'demo.js' => "themes/manage/js/demo.js".$config['JS_VERSION'],
    'custom.js' => "themes/manage/js/custom.js".$config['JS_VERSION'],
    'bootstrap-notify.min.js'=>"themes/manage/js/bootstrap-notify.min.js",
);
$config['header_css'] = array('bootstrap.min.css','font-awesome.min.css','AdminLTE.min.css','_all-skins.min.css','ionicons.min.css','datepicker3.css','pace.min.css','animate.css','custom.css','iCheck/flat/blue.css','dataTables.bootstrap.css'); // here we only pass the key form $config['all_css_with_url']
$config['header_js']  = array(); // here we only pass the key form $config['all_js_with_url']

$config['footer_js']  = array('jquery-2.2.3.min.js','jquery-ui.min.js','bootstrap.min.js','bootstrap-notify.min.js','pace.min.js','bootstrap-datepicker.js','jquery.slimscroll.min.js','fastclick.js','jquery.dataTables.min.js','dataTables.bootstrap.min.js','validate.min.js','validate_init.js','app.js','demo.js','custom.js'); // here we only pass the key form $config['all_js_with_url']

$config['not_found__page_css'] = array('bootstrap.min.css','font-awesome.min.css','AdminLTE.min.css','_all-skins.min.css','ionicons.min.css','pace.min.css','animate.css','custom.css'); // here we only pass the key form

$config['not_found__page_js'] = array('jquery-2.2.3.min.js', 'jquery-ui.min.js', 'bootstrap.min.js', 'jquery.slimscroll.min.js', 'fastclick.js', 'app.js', 'demo.js', 'custom.js'); // here we only pass the key form

$config['permission'] = array(
    'home' =>array(
        'index' => array('SuperAdmin','SubAdmin',),
    ),
    'page_search' =>array(
        'index' => array('SuperAdmin','SubAdmin'),
        'information' => array('SuperAdmin','SubAdmin'),
    ),
    'profile' =>array(
        'index' => array('SuperAdmin','SubAdmin'),
        'edit' => array('SuperAdmin','SubAdmin'),
        'update' => array('SuperAdmin','SubAdmin'),
    ),
    'admin' =>array(
        'index' => array('SuperAdmin'),
        'add' => array('SuperAdmin'),
        'insert' => array('SuperAdmin'),
        'edit' => array('SuperAdmin'),
        'update' => array('SuperAdmin'),
        'information' => array('SuperAdmin','SubAdmin'=>array('own')),
    ),
    'material' => array(
        'index' => array('SuperAdmin'),
        'add' => array('SuperAdmin'),
        'insert' => array('SuperAdmin'),
        'edit' => array('SuperAdmin'),
        'update' => array('SuperAdmin'),
        'information' => array('SuperAdmin', 'SubAdmin' => array('own')),
    ),

    'seller' => array(
        'index' => array('SuperAdmin'),
        'add' => array('SuperAdmin'),
        'insert' => array('SuperAdmin'),
        'edit' => array('SuperAdmin'),
        'update' => array('SuperAdmin'),
        'information' => array('SuperAdmin', 'SubAdmin' => array('own')),
    ),
    'invoice' => array(
        'index' => array('SuperAdmin'),
        'add' => array('SuperAdmin'),
        'insert' => array('SuperAdmin'),
        'edit' => array('SuperAdmin'),
        'update' => array('SuperAdmin'),
        'information' => array('SuperAdmin', 'SubAdmin' => array('own')),
        'print' => array('SuperAdmin'),
    ),
    'mail_template' =>array(
        'index' => array('SuperAdmin'),
        'add' => array('SuperAdmin'),
        'insert' => array('SuperAdmin'),
        'edit' => array('SuperAdmin'),
        'update' => array('SuperAdmin'),
        'information' => array('SuperAdmin'),
        'Status'=> array('SuperAdmin'),
        'Delete'=> array('SuperAdmin'),
    ),
    'settings' =>array(
        'index' => array('SuperAdmin'),
        'add' => array('SuperAdmin'),
        'insert' => array('SuperAdmin'),
        'edit' => array('SuperAdmin'),
        'update' => array('SuperAdmin'),
        'information' => array('SuperAdmin'),
        'Status'=> array('SuperAdmin'),
        'Delete'=> array('SuperAdmin'),
    ),
    'ajax_delete'=>array(
        'index' => array('SuperAdmin','SubAdmin'),
    ),
    'ajax_status'=>array(
        'index' => array('SuperAdmin','SubAdmin'),
    ),
);

$config['roles_key_value'] = array('SuperAdmin'=>'Super Admin','SubAdmin'=>'Sub Admin');

$config['cmp_business_risk_threats'] = array(1=>'1 - Very Low',2=>'2 - Low',3=>'3 - Average',4=>'4 - High',5=>'5 - Very High');


$config['country_table'] = array(
    1 => array('India', 'In')
);

$config['state_table'] = array(
    /*1 => array('Andaman and Nicobar Islands','AN'),
    2 => array('Andhra Pradesh','AP'),
    3 => array('Andaman and Nicobar Islands','AN'),
    4 => array('Andaman and Nicobar Islands','AN'),
    5 => array('Andaman and Nicobar Islands','AN'),*/
    1 => array('Gujarat', 'GJ', '24')
);

// Other state info site url :- http://www.statoids.com/uin.html

$config['gujarat_state_code'] = array(
    1 => ['Ahmedabad', 'GJ-1'],
    2 => ['Mehsana', 'GJ-2'],
    3 => ['Rajkot', 'GJ-3'],
    4 => ['Bhavnagar', 'GJ-4'],
    5 => ['Surat', 'GJ-5'],
    6 => ['Vadodara', 'GJ-6'],
    7 => ['Kheda', 'GJ-7'],
    8 => ['Banas Kantha', 'GJ-8'],
    9 => ['Sabar Kantha', 'GJ-9'],
    10 => ['Jamnagar', 'GJ-10'],
    11 => ['Junagadh', 'GJ-11'],
    12 => ['Kutch / Kachchh', 'GJ-12'],
    13 => ['Surendranagar', 'GJ-13'],
    14 => ['Amreli', 'GJ-14'],
    15 => ['Valsad', 'GJ-15'],
    16 => ['Bharuch', 'GJ-16'],
    17 => ['Panchmahal', 'GJ-17'],
    18 => ['Gandhinagar', 'GJ-18'],
    19 => ['Bardoli', 'GJ-19'],
    20 => ['Dahod', 'GJ-20'],
    21 => ['Navsari', 'GJ-21'],
    22 => ['Narmada', 'GJ-22'],
    23 => ['Anand', 'GJ-23'],
    24 => ['Patan', 'GJ-24'],
    25 => ['Porbandar', 'GJ-25'],
    26 => ['Tapi (Vyara)', 'GJ-26'],
    27 => ['Ahmedabad East', 'GJ-27'],
    28 => ['Surat West (Pal)', 'GJ-28'],
    29 => ['Vadodara Rural', 'GJ-29'],
    30 => ['Dang (Ahwa)', 'GJ-30'],
    31 => ['Gandhidham - Tehsil (Taluko) of Kutch', 'GJ-31'],
    32 => ['Botad', 'GJ-32'],
    33 => ['Arvalli (Modasa)', 'GJ-33'],
    34 => ['Devbhumi Dwarka', 'GJ-34'],
    35 => ['Mahisagar (Lunawada)', 'GJ-35'],
    36 => ['Morbi (Morvi)', 'GJ-36'],
    37 => ['Chhota Udaipur', 'GJ-37'],
    38 => ['Gir Somnath', 'GJ-38'],
);

$config['bill_status_color_class'] = array(
    'Pending'=>'text-warning',
    'Print'=>'text-success',
    'Cancel'=>'text-danger'
);
$config['bill_status_arr'] = array(
    'Pending',
    'Print',
    'Cancel',
);