<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

//Dynamically add Javascript files to header page


if(!function_exists('has_permission')){
    function has_permission($json= false)
    {
        login_check($json);
        $ci = &get_instance();
        $permission  = $ci->config->item('permission');
        $curClass = $ci->router->fetch_class();
        $curMethod = $ci->router->fetch_method();
        $curUserType = $ci->session->userdata('admin_type');
        if(!in_array($curUserType,$permission[$curClass][$curMethod]) AND !key_exists($curUserType,$permission[$curClass][$curMethod])){
            not_accessible($json);
        }
    }
}
if(!function_exists('is_accessible')){
    function is_accessible($curClass,$curMethod,$accessIdArray=array(),$accessId='',$json = false)
    {
        login_check($json);
        $ci = &get_instance();
        $permission  = $ci->config->item('permission');
        $curUserType = $ci->session->userdata('admin_type');
        if(!in_array($curUserType,$permission[$curClass][$curMethod])){
            if(!key_exists($curUserType,$permission[$curClass][$curMethod])) {
                $return = false;
            }else{
                if(in_array('own',$permission[$curClass][$curMethod][$curUserType])){
                    if($accessId !== ''  && in_array($accessId,$accessIdArray)){
                        $return = true;
                    }else{
                        $return = false;
                    }
                }else{
                    $return = false;
                }
            }
        }else{
            $return = true;
        }

        if($return){
            if (!$json) {
                return true;
            }else{
                return array('code'=>1);
            }
        }else{
            if (!$json) {
                return false;
            } else {
                return array('code' => 0, 'msg' => 'Page not accessible');
            }
        }
    }
}
if(!function_exists('not_accessible')) {
    function not_accessible($json = false)
    {
        if (!$json) {
            $ci = &get_instance();
            $ci->config->set_item('footer_js', array());
            $ci->config->set_item('header_css', array());
            add_css_page($ci->config->item('not_found__page_css'));
            add_js_footer($ci->config->item('not_found__page_js'));
            $data = array('title' => '401 Access Denied','roles_key_value' => $ci->config->item('roles_key_value'),
                'main_module' => '401 Access Denied',
                'thumb_profile_img_login_user' => check_image($ci->session->userdata('admin_image'),'uploads/admin'),
                'big_profile_img_login_user' => check_image($ci->session->userdata('admin_image'),'uploads/admin','big'));
            $data['content_section'] = $ci->load->view('manage/content_section/not_accessible', $data,true);
            $ci->load->view('manage/layout', $data);
            echo $ci->output->get_output();
            exit;
        } else {
            return array('code'=>0,'msg'=>'Page not accessible');
        }
    }
}
if(!function_exists('data_not_found')) {
    function data_not_found($json = false)
    {
        if (!$json) {
            $ci = &get_instance();
            $ci->config->set_item('footer_js', array());
            $ci->config->set_item('header_css', array());
            add_css_page($ci->config->item('not_found__page_css'));
            add_js_footer($ci->config->item('not_found__page_js'));

            $data = array('title' => '404 Not Found','roles_key_value' => $ci->config->item('roles_key_value'),
                'main_module' => '404 Not Found',
                'thumb_profile_img_login_user' => check_image($ci->session->userdata('admin_image'),'uploads/admin'),
                'big_profile_img_login_user' => check_image($ci->session->userdata('admin_image'),'uploads/admin','big'));
            $data['content_section'] = $ci->load->view('manage/content_section/data_not_found', $data,true);
            $ci->load->view('manage/layout', $data);
            //$this->load->view('manage/includes/footer');
            echo $ci->output->get_output();
            exit;
        } else {
            return array('code'=>0,'msg'=>'Data not found.');
        }
    }
}
if(!function_exists('login_check')) {
    function login_check($json = false)
    {
        $ci = &get_instance();
        if ($ci->session->userdata('admin_logged_in') == FALSE) {
            if (!$json) {
                $data = array('title' => $ci->lang->line('admin') . " " . $ci->lang->line('login'));
                $data['target'] = current_url();
                $data['content_section'] = $ci->load->view('manage/content_section/login', $data,true);
                $ci->load->view('manage/layout_2', $data);
                echo $ci->output->get_output();
                exit;
            }else{
                return array('code'=>0,'msg'=>'Please login first and try again later.');
            }
        }else{
            //check status
            $result = $ci->db->select('Id,UserType')->from('users')->where('Id', $ci->session->userdata('adminid'))->where('Status', 'Enable')->limit(1)->get()->row();
            if ($result->Id == '' || $ci->session->userdata('admin_type') != $result->UserType) {
                $array_items = array('adminname' => '', 'adminid' => '', 'admin_logged_in' => FALSE,'admin_type'=>'');
                $ci->session->unset_userdata($array_items);
                if(!$json){
                    redirect(site_url('manage/login'));
                }else{
                    return array('code'=>0,'msg'=>'Not login.');
                }
            }else{
                if($json){
                    return array('code'=>1,'msg'=>'');
                }
            }
        }
    }
}
/* ./application/helpers/acl_helper.php */
?>
