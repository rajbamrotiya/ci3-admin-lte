<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

//Dynamically add JS files to footer page
if(!function_exists('check_image')){
    function check_image($name,$dir='uploads/default',$size='thumb')
    {

        if(file_exists(APPPATH."../".$dir."/".$size."/".$name) && is_file(APPPATH."../".$dir."/".$size."/".$name)){
            return (site_url().$dir."/".$size."/".$name);
        }
        elseif (file_exists(APPPATH."../".$dir."/".$size."/default.png") && is_file(APPPATH."../".$dir."/".$size."/default.png")){
            return (site_url().$dir."/".$size."/default.png");
        }
        else{
            if($size != 'thumb')
                return (site_url()."uploads/default/default_big.png");
            else
                return (site_url()."uploads/default/default.png");
        }
    }
}


//pre tag with print_r and var_dump
if (!function_exists('_pre')) {
    /**
     * @param $arr
     * @param bool $print_r
     */
    function _pre($arr, $print_r = TRUE)
    {
        echo '<pre>';
        if ($print_r) {
            print_r($arr);
        } else {
            var_dump($arr);
        }
        die;
    }
}


//
if (!function_exists('human_date')) {
    /**
     * @param $date_time
     * @param string $date_format
     * @return false|string
     */
    function human_date($date_time, string $date_format = 'd F,Y (D) h:i:s A')
    {
        return date($date_format, strtotime($date_time));
    }
}

if (!function_exists('mysql_date_format')) {

    function mysql_date_format($date)
    {
        $date_array = explode('/',$date);
        $date = implode('-',array_reverse($date_array));
        return $date;
    }
}

if (!function_exists('mysql_to_date_format')) {

    function mysql_to_date_format($date)
    {
        $date_array = explode('/',$date);
        $date = implode('-',array_reverse($date_array));
        return $date;
    }
}


if (!function_exists('get_indian_currency')) {
    /**
     * @param $number
     * @return string
     */
    function get_indian_currency($number)
    {
        $decimal = round($number - ($no = floor($number)), 2) * 100;
        $hundred = null;
        $digits_length = strlen($no);
        $i = 0;
        $str = array();
        $words = array(
            0 => '', 1 => 'one', 2 => 'two', 3 => 'three',
            4 => 'four', 5 => 'five', 6 => 'six', 7 => 'seven',
            8 => 'eight', 9 => 'nine', 10 => 'ten', 11 => 'eleven',
            12 => 'twelve', 13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
            16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen', 19 => 'nineteen',
            20 => 'twenty', 30 => 'thirty', 40 => 'forty', 50 => 'fifty',
            60 => 'sixty', 70 => 'seventy', 80 => 'eighty', 90 => 'ninety'
        );
        $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
        while ($i < $digits_length) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? '' : null;
                $str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural . ' ' . $hundred : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural . ' ' . $hundred;
            } else {
                $str[] = null;
            }
        }
        $Rupees = trim('Rs. ' . implode('', array_reverse($str)));

        $digits_length = strlen($decimal);
        $i = 0;
        $str = array();
        while ($i < $digits_length) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($decimal % $divider);
            $decimal = floor($decimal / $divider);
            $i += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? '' : null;
                $str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural . ' ' . $hundred : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural . ' ' . $hundred;
            } else {
                $str[] = null;
            }
        }

        $Paise = trim(implode('', array_reverse($str)));

        $Rupees .= ($Paise ? ' and ' . $Paise . ' paise' : '');
        return ($Rupees ? $Rupees . ' only' : '');
    }
}
/* ./application/helpers/other_helper.php */
?>
